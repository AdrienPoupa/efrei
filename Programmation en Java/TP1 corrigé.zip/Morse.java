package tp1

public class Morse {
	public static void main(String[] args) {
		StringBuilder s = new StringBuilder();

		for(String arg : args){
			s.append(arg).append(" Stop. "); 
		
		System.out.println(s.toString(
		
		String first = args[0];
		String second = args[1];
		String last = args[2];
		
		System.out.println(first + "" + second + "" + last);
	}

}
