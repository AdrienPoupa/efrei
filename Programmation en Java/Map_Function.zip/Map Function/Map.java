interface Map {
	abstract public void map(Function f);
	abstract public Map mapCopy(Function f);
}