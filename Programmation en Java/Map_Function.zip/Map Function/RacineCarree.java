public class RacineCarree implements Function {
	public double applyIt(double n) {
		return Math.sqrt(n);
	}
}