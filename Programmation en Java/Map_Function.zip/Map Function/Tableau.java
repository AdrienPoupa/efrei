import java.util.Arrays;

public class Tableau implements Map {
	double[] a;
	
	Tableau(int n) {
		a = new double[n];
		for (int i = 0; i < n; i++)
			a[i] = i + 1;
	}
	
	public void map(Function f) {
		for (int i = 0; i < a.length; i++)
			a[i] = f.applyIt(a[i]);
	}

	public Map mapCopy(Function f) {
		Tableau b = new Tableau(a.length) ;
		for (int i = 0; i < a.length; i++)
			b.a[i] = f.applyIt(a[i]);
		return b;
	}
	
	@Override
	public String toString() {
		return Arrays.toString(a);
	}
}