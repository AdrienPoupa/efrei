import java.util.Arrays;

public class TestMap {
	public static void main(String args[]) {
		
		TestMap.testIntrusif();
		TestMap.testCopie();
	}
	
	static void testIntrusif()
	{
		System.out.println("\n *****************TEST INTRUSIF ==> tableau original modifi�\n");
		Map t = new Tableau(10);
		System.out.println("tableau initial\t t = " + t);
		
		Function square = new Carre();
		t.map(square);
		System.out.println("les carr�s\t t = " + t);
	
		Function cube = new Cube();
		t.map(cube);
		System.out.println("les cubes\t t = " + t);
		
		Function squareRoot = new RacineCarree();
		t.map(squareRoot);
		System.out.println("les racines carre�s\t t = " + t);
		
		System.out.println("Tableau initial modifi�: t = " + t);
	}
	
	static void testCopie()
	{
		System.out.println("\n *****************TEST COPIE ==> tableau original non modifi�\n");
		Map t = new Tableau(10);
		System.out.println("tableau initial\t t = " + t);
		
		Function square = new Carre();
		Map t2 = t.mapCopy(square);
		System.out.println("les carr�s\t t2 = " + t2);
	
		Function cube = new Cube();
		Map  t3 = t.mapCopy(cube);
		System.out.println("les cubes\t t3 = " + t3);
		
		Function squareRoot = new RacineCarree();
		Map  t4 = t.mapCopy(squareRoot);
		System.out.println("les racines carre�s\t t4 = " + t4);
		
		System.out.println("Tableau initial non modifi�: t = " + t);
	}
}