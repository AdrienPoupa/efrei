public class Carre implements Function {
	public double applyIt(double n) {
		return n*n;
	}
}