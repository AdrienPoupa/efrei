
interface Function {
	abstract public double applyIt(double n);
}