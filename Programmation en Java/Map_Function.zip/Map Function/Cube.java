
public class Cube implements Function {
	public double applyIt(double n) {
		return n*n*n;
	}
}