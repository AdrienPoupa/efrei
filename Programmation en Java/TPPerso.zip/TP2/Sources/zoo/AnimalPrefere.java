package zoo;
import java.util.HashMap;

/**
 * Retourne l'animal préféré de bob, alice et june, on passe le nom en paramètre.
 * Utilise deux méthodes : if/else... et table de hachage.
 */
public class AnimalPrefere {

    /**
     * Test d'une table de hachage
     * On retourne le nom de l'animal préféré de la personne passée en argument
     * @param args Nom de la personne dont on veut afficher l'animal préféré
     */
    public static void main (String args[]){
        // Affichage avec if/elseif/else
        System.out.println("if/elseif/else");
        if (args[0].equals("bob")) {
            System.out.println("L'animal préféré de bob est izard le chamoix");
        }
        else if (args[0].equals("alice")) {
            System.out.println("L'animal préféré de alice est edith le singe");
        }
        else if (args[0].equals("june")) {
            System.out.println("L'animal préféré de june est gold le poisson rouge");
        }
        else {
            System.out.println("Le nom que vous avez saisi n'est pas reconnu");
        }


        HashMap<String,String> animauxPreferes = new HashMap<String, String>();

        animauxPreferes.put("june", "gold le poisson rouge");
        animauxPreferes.put("alice", "edith le singe");
        animauxPreferes.put("bob", "izard le chamoix");

        // Affichage en hashtable
        System.out.println("Hashtable");
        // Vérification du nom
        if (animauxPreferes.get(args[0]) != null) {
            System.out.println("L'animal prefere de " + args[0] + " est " + animauxPreferes.get(args[0]));
        }
        else {
            System.out.println("Le nom que vous avez saisi n'est pas reconnu");
        }

    }

}
