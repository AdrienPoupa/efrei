package zoo;

/**
 * Classe utilisée pour tester la PolyLine.
 */
public class PolyLineTest {

    public static void main(String[] args) {
        System.out.println("PolyLine");
        PolyLine test = new PolyLine(5);

        test.add(new Point(1, 2));
        test.add(new Point(1, 5));
        test.add(null);
        test.add(new Point(47, 2));
        test.add(new Point(25, 48));
        test.add(new Point(2, 2));
        test.add(new Point(1, 5));
        test.add(new Point(31, 2));
        test.add(new Point(1, 2));

        System.out.println("Capacite : " + test.pointCapacity());
        System.out.println("Nombre de points entres : " + test.pointCount());
        System.out.println(test.toString());

        System.out.println("Contient 99,99 ? : " + test.contains(new Point(99, 99))); // false
        System.out.println("Contient 1,2 ? : " + test.contains(new Point(1, 2))); // true
        System.out.println("Contient null ? : " + test.contains(null)); // false

        System.out.println("FreePolyLine");
        FreePolyLine test2 = new FreePolyLine();

        test2.add(new Point(1, 2));
        test2.add(new Point(1, 5));
        test2.add(null);
        test2.add(new Point(47, 2));
        test2.add(new Point(25, 48));
        test2.add(new Point(2, 2));
        test2.add(new Point(1, 5));
        test2.add(new Point(31, 2));
        test2.add(new Point(1, 2));

        System.out.println("Capacite : " + test2.pointCapacity());
        System.out.println("Nombre de points entres : " + test2.pointCount());
        System.out.println(test2.toString());

        System.out.println("Contient 99,99 ? : " + test2.contains(new Point(99, 99))); // false
        System.out.println("Contient 1,2 ? : " + test2.contains(new Point(1, 2))); // true
        System.out.println("Contient null ? : " + test2.contains(null)); // false
    }

}
