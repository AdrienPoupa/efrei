package automobile;

/**
 * Interface permettant l'implémentation d'une fonction applyIt pour des transformations de masse
 * @author Adrien Poupa
 */
interface Function {
    /**
     * Fonction pour des transformations de masse
     * @param v véhicule sur lequel appliquer la transformation
     * @return véhicule transformé
     */
    abstract public Vehicule applyIt(Vehicule v);
}
