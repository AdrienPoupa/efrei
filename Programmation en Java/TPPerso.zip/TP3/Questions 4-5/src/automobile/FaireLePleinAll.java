package automobile;

/**
 * Implémente applyIt de Function pour faire le plein du véhicule donné
 */
public class FaireLePleinAll implements Function {
    /**
     * Faire le plein du véhicule
     * @param v véhicule à remplir
     * @return le véhicule rempli
     */
    public Vehicule applyIt(Vehicule v) {
        if (v.getJauge() < 10) {
            v.faireLePlein();
        }
        return v;
    }
}
