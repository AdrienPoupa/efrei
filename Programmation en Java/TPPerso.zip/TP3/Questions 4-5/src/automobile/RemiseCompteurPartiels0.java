package automobile;

/**
 * Implémente applyIt de Function pour remettre à zéro le compteur partiel du véhicule donné
 * @author Adrien Poupa
 */
public class RemiseCompteurPartiels0 implements Function {
    /**
     * Remettre le compteur partiel du véhicule à zéro
     * @param v véhicule à réinitialiser
     * @return le véhicule réinitialisé
     */
    public Vehicule applyIt(Vehicule v) {
        v.getCompteur().resetPartiel();
        return v;
    }
}
