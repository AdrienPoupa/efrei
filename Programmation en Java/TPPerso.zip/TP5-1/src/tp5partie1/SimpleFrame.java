package tp5partie1;

import javax.swing.*;
import java.awt.*;

/**
 * Frame Simple, fenêtre simple avec labels et boutons
 * @author Adrien Poupa
 */
public class SimpleFrame {
    /**
     * Création d'une fenêtre avec des blocs centrés
     * @param args arguments par défaut
     */
    public static void main(String[] args)
    {
        // Création de la fenêtre
        JFrame fenetre = new JFrame();
        fenetre.setTitle("Première fenêtre");
        fenetre.setSize(500, 200);;

        JLabel label = new JLabel("Test");
        //label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton button = new JButton("OK");
        //button.setHorizontalAlignment(SwingConstants.CENTER);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);

        // On utilise un container pour rentrer tous les blocs
        Container contentPane = fenetre.getContentPane();
        // puis un BoxLayout pour tout centrer sur l'axe des y
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        contentPane.add(button);
        contentPane.add(label);
        fenetre.setLocationRelativeTo(null);
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenetre.setVisible(true);
    }
}
