package tp6;

/**
 * Première classe avec des threads
 */
public class HelloThread implements Runnable {
    /**
     * Action effectuée par les threads: boucle de 5000 itérations affichant le thread actuel et
     * le niveau du compteur
     */
    public void run() {
        for(int i=0;i<5000;i++)
            System.out.println("hello " + Thread.currentThread().getName() + " " + i);
    }

    /**
     * Lancement de 4 threads effectuant la tâche définie plus haut
     * @param args Arguments par défaut
     */
    public static void main(String args[]) {
        Thread t0 = new Thread(new HelloThread());
        t0.setName("0");

        Thread t1 = new Thread(new HelloThread());
        t1.setName("1");

        Thread t2 = new Thread(new HelloThread());
        t2.setName("2");

        Thread t3 = new Thread(new HelloThread());
        t3.setName("3");

        t0.start();
        t1.start();
        t2.start();
        t3.start();
    }
}
