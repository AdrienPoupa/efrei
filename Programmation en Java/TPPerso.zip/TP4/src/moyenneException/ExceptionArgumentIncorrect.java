package moyenneException;

/**
 * Exception jetée en cas de paramètre incorrect
 * @author Adrien Poupa
 */
public class ExceptionArgumentIncorrect extends Exception {
    /**
     * Constructeur de la classe
     * @param message message à affichers
     */
    public ExceptionArgumentIncorrect(String message) {
        super(message);
    }
}
