package football;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

/**
 * Test d'un joueur et d'un arbitre
 * @author Adrien Poupa
 */
public class TestJoueurActeur {
    /**
     * On crée des joueurs, un arbitre et on les affiche
     * @param argv arguments par défaut
     */
    public static void main(String[] argv) {
        ArrayList<Acteur> knysa = new ArrayList<>();
        Joueur quiEstLaTaupe = new Joueur("Evra", "Patrice", 34, 48418741);
        Joueur frankenstein = new Joueur("Ribery", "Franck", 32, 48418741);
        Joueur fragile = new Joueur("Gourcuff", "Yoann", 29, 48418741);

        knysa.add(quiEstLaTaupe);
        knysa.add(frankenstein);
        knysa.add(fragile);

        Arbitre kivoitou = new Arbitre("Kivoitou", "Kantantou", 45, 3);

        knysa.add(kivoitou);

        StringBuilder returnString = new StringBuilder();

        for (Acteur acteur : knysa) {
            returnString.append(acteur.toString());
            returnString.append(System.getProperty("line.separator"));
        }

        System.out.println(returnString.toString());
    }
}
