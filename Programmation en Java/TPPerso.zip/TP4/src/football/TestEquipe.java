package football;

/**
 * Test d'une équipe
 * @author Adrien Poupa
 */
public class TestEquipe {
    /**
     * On (essaie) de créer une équipe pour tester le bon fonctionnement de nos exceptions
     * @param argv arguments par défaut
     */
    public static void main(String[] argv) {
        Joueur quiEstLaTaupe = new Joueur("Evra", "Patrice", 34, 48418741, "Equipe de France");
        Joueur frankenstein = new Joueur("Ribery", "Franck", 32, 48418741, "Equipe de France");
        Joueur fragile = new Joueur("Gourcuff", "Yoann", 29, 48418741, "Equipe de France");
        Joueur fragile2 = new Joueur("Diaby", "Abou", 29, 48418741, "Equipe de France");
        Joueur mcDo = new Joueur("Gignac", "André-Pierre", 30, 48418741, "Equipe de France");
        Joueur manoDeDios = new Joueur("Henry", "Thierry", 38, 48418741, "Equipe de France");
        Joueur dieudonne = new Joueur("Anelka", "Nicolas", 36, 48418741, "Equipe de France");
        Joueur sextape = new Joueur("Benzema", "Karim", 28, 48418741, "Equipe de France");
        Joueur dallas = new Joueur("Gallas", "William", 38, 48418741, "Equipe de France");
        Joueur passoire = new Joueur("Lloris", "Hugo", 29, 48418741, "Equipe de France");
        Joueur mauvaiseEquipe = new Joueur("test", "test", 99, 14976, "Equipe de Norvège"); // Pas la bonne équipe
        Joueur bicyclette = new Joueur("Valbuena", "Mathieu", 31, 48418741, "Equipe de France");
        Joueur douxiemeHomme = new Joueur("Test", "Test", 31, 48418741, "Equipe de France"); // Joueur en trop

        System.out.println("Test mauvaise équipe");
        try {
            Equipe equipeDeFrance = new Equipe("Equipe de France");
            equipeDeFrance.ajout(mauvaiseEquipe);
            System.out.println(equipeDeFrance.toString());
        } catch (EquipePleineException|JoueurHorsClubEquipeException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Test 12 joueurs");
        try {
            Equipe equipeDeFrance = new Equipe("Equipe de France");
            equipeDeFrance.ajout(quiEstLaTaupe);
            equipeDeFrance.ajout(frankenstein);
            equipeDeFrance.ajout(fragile);
            equipeDeFrance.ajout(fragile2);
            equipeDeFrance.ajout(mcDo);
            equipeDeFrance.ajout(manoDeDios);
            equipeDeFrance.ajout(dieudonne);
            equipeDeFrance.ajout(sextape);
            equipeDeFrance.ajout(dallas);
            equipeDeFrance.ajout(passoire);
            equipeDeFrance.ajout(bicyclette);
            equipeDeFrance.ajout(douxiemeHomme);
            System.out.println(equipeDeFrance.toString());
        } catch (EquipePleineException|JoueurHorsClubEquipeException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Test bonne équipe");
        try {
            Equipe equipeDeFrance = new Equipe("Equipe de France");
            equipeDeFrance.ajout(quiEstLaTaupe);
            equipeDeFrance.ajout(frankenstein);
            equipeDeFrance.ajout(fragile);
            equipeDeFrance.ajout(fragile2);
            equipeDeFrance.ajout(mcDo);
            equipeDeFrance.ajout(manoDeDios);
            equipeDeFrance.ajout(dieudonne);
            equipeDeFrance.ajout(sextape);
            equipeDeFrance.ajout(dallas);
            equipeDeFrance.ajout(passoire);
            equipeDeFrance.ajout(bicyclette);
            System.out.println(equipeDeFrance.toString());
        } catch (EquipePleineException|JoueurHorsClubEquipeException e) {
            System.out.println(e.getMessage());
        }
    }
}
