package football;

/**
 * Exception Equipe Pleine
 * @author Adrien Poupa
 */
public class EquipePleineException extends Exception {
    /**
     * Retourne l'exception affichée si l'équipe est pleine
     * @param message message à afficher
     */
    public EquipePleineException(String message) {
        super(message);
    }
}
