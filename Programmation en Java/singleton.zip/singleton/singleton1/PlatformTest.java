package singleton1;

import singleton2.Platform;

public class PlatformTest {

	public static final void main(String [] args){
		Platform platform1 = Platform.getDefaultPlatform();
		Platform platform2 = Platform.getDefaultPlatform();
		System.out.println(platform1);
		System.out.println(platform2);

		if (platform1 == platform2){
			System.out.println("EGALITE DE REFERENCES ==> UNIQUE INSTANCE!");
		}


		// NE COMPILE PAS : constructeur priv�
		// Platform platform2 = new Platform("Java 5");
	}
}
