/**
 * BASE DE DONNEES CoffeeBreak
 * CREATION DE LA TABLE Coffees_Singleton 
 * EN UTILISANT LE DESIGN PATTERN SINGLETON
 * 
 * INSERTION DES DONNEES DANS LA TABLE
 * ATTENTION: si le programme est relanc�, la table est d�truite avant d'�tre repeupl�e
 */
package coffees;
import java.sql.*;

public class CoffeesSingletonTable 
{
	public static void main(String[] args) 
	{
		Statement stmt = null;
		Connection connexion = null;
		ResultSet rs = null;

		CreationTable.loadDriver();
			
		try 
		{
			// pour ne pas repeupler la table avec les m�mes donn�es si le programme est relanc�
			CreationTable.sql_dropTable = new String("DROP TABLE  IF EXISTS COFFEES_SINGLETON");

			CreationTable.sql_createTable = new String("CREATE TABLE COFFEES_SINGLETON" + "(NOM_CAFE VARCHAR(32),FO_ID INTEGER,"
					+ "PRIX FLOAT, VENTES INTEGER, TOTAL INTEGER)");

			connexion = CreationTable.getConnexion();
			connexion = CreationTable.getConnexion();
			connexion = CreationTable.getConnexion();
			connexion = CreationTable.getConnexion();
			connexion = CreationTable.getConnexion();
			connexion = CreationTable.getConnexion();
			connexion = CreationTable.getConnexion();
			connexion = CreationTable.getConnexion();
			
			
			// Requ�te SQL de cr�ation de la table ex�cut�e une et une seule fois gr�ce � la mise en oeuvre du pattern Singleton
			CreationTable.getTable();


			// peuplement de la table
			CreationTable.getTable().insertEntree("INSERT INTO COFFEES_SINGLETON VALUES ('Colombian', 101, 7.99, 0, 0)");
			CreationTable.getTable().insertEntree("INSERT INTO COFFEES_SINGLETON VALUES ('French_Roast', 49, 8.99, 0, 0)");
			CreationTable.getTable().insertEntree("INSERT INTO COFFEES_SINGLETON VALUES ('Espresso', 150, 9.99, 0, 0)");
			CreationTable.getTable().insertEntree("INSERT INTO COFFEES_SINGLETON VALUES ('Colombian_Decaf', 101, 8.99, 0, 0)");
			CreationTable.getTable().insertEntree("INSERT INTO COFFEES_SINGLETON VALUES ('French_Roast_Decaf', 49, 9.99, 0, 0)");

			stmt = connexion.createStatement();
			// r�cup�ration du r�sultat
			rs = stmt.executeQuery("SELECT NOM_CAFE,PRIX FROM COFFEES_SINGLETON");
			// affichage des r�sultats
			while(rs.next()){
				String s = rs.getString("NOM_CAFE");
				float n = rs.getFloat("PRIX");
				System.out.println(s + " " + n);
			}


			// mise � jour de la table COFFEES
			stmt.executeUpdate("UPDATE COFFEES_SINGLETON SET VENTES = 75 WHERE NOM_CAFE LIKE 'Colombian'");

			// r�cup�ration du r�sultat
			rs = stmt.executeQuery("SELECT NOM_CAFE, VENTES FROM COFFEES_SINGLETON WHERE NOM_CAFE LIKE 'Colombian'");
			// affichage des r�sultats
			while(rs.next()){
				String s = rs.getString("NOM_CAFE");
				int n = rs.getInt("VENTES");
				System.out.println(n + " livres de" + s + " vendu cette semaine.");
			}


			stmt.executeUpdate("UPDATE COFFEES_SINGLETON SET TOTAL = TOTAL + 75 WHERE NOM_CAFE LIKE 'Colombian'");
			rs = stmt.executeQuery("SELECT NOM_CAFE, TOTAL FROM COFFEES_SINGLETON WHERE NOM_CAFE LIKE 'Colombian'");
			while(rs.next()){
				String s = rs.getString(1);
				int n = rs.getInt(2); 
				System.out.println(n+" livres de" + s + " vendu jusqu'� maintenant.");
			}

		}
		catch (SQLException ex){
			// handle any errors
			System.err.println("SQLException: " + ex.getMessage());
		}
		finally {
			// it is a good idea to release
			// resources in a finally{} block
			// in reverse-order of their creation
			// if they are no-longer needed
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlEx) { } // ignore
				rs = null;
			}
			
			CreationTable.closeAll();
		}
	}
}





