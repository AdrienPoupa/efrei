package coffees;

public interface IDatabase {
	public static final String SQL_DRIVER = "com.mysql.jdbc.Driver";
	public static final String SQL_CONNEXION = "jdbc:mysql://localhost/COFFEEBREAK?user=root&password=";
	public static final String DATABASE_URL = "jdbc:mysql://localhost/COFFEESBREAK";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "";

	// la requ�te par d�faut qui retrouvent toutes les entr�es de la table NOM_CAFE
	public static final String DEFAULT_QUERY = "SELECT * FROM NOM_CAFE";
}
