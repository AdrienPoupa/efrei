package coffees;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

//Classe bas�e sur le pattern Singleton qui permet :
//1) la cr�ation d'une connexion unique � la base
//2) la cr�ation d'une table unique; afin de ne pas la recr�er 
public class CreationTable 
{
	private static Connection uniqueConnexion = null;
	private static CreationTable uniqueTable = null;// Stockage de l'unique instance de cette classe.
	
	public static String sql_dropTable = null;
	public static String sql_createTable = null;
	
	public static void loadDriver()
	{
		try 
		{
			Class.forName(IDatabase.SQL_DRIVER);
			System.err.println("Succ�s chargement du driver") ;
		}
		catch(ClassNotFoundException e) 
		{
			System.err.println("Erreur de chargement du driver :" + e) ;
		}
	}
	
	public static synchronized Connection getConnexion()
	{
		if(uniqueConnexion  == null)
		{
			System.out.println("DESIGN PATTERN SINGLETON");
			try 
			{
				uniqueConnexion =	DriverManager.getConnection(IDatabase.SQL_CONNEXION);
				System.err.println("Succ�s connexion � la base") ;
			} catch (SQLException ex)
			{
				// handle any errors
				System.err.println("SQLException: " + ex.getMessage());
				System.err.println("SQLState: " + ex.getSQLState());
				System.err.println("VendorError: " + ex.getErrorCode());
			}
		}
		return uniqueConnexion;
	}
	
	// Constructeur en priv� (donc inaccessible � l'ext�rieur de la classe).
	// � executer une seule fois
	private CreationTable()
	{
		try
		{
			Statement stmt = null;
			stmt = uniqueConnexion.createStatement();
			stmt.executeUpdate(sql_dropTable);
			stmt.executeUpdate(sql_createTable);
		}
		catch (SQLException ex)
		{
			// handle any errors
			System.err.println("SQLException: " + ex.getMessage());
		}

	}

	// M�thode statique qui sert de pseudo-constructeur 
	// utilisation du mot clef "synchronized" pour le multithread).
	public static synchronized CreationTable getTable()
	{
		if(uniqueTable == null)
		{
			uniqueTable = new CreationTable();
			System.err.println("Table cr�ee : " + sql_createTable);
		}
		return uniqueTable;
	}  

	

	public void insertEntree (String sql_insertTable)
	{
		try
		{
			Statement stmt = null;
			stmt = uniqueConnexion.createStatement();
			stmt.executeUpdate(sql_insertTable);

			System.err.println(sql_insertTable);
		}
		catch (SQLException ex)
		{
			// handle any errors
			System.err.println("SQLException: " + ex.getMessage());
		}
	}
	
	public static void closeAll()
	{
		if (uniqueConnexion != null) {
			try {
				uniqueConnexion.close();
			} catch (SQLException sqlEx) { } // ignore
		uniqueConnexion = null;
		}
	}
}




