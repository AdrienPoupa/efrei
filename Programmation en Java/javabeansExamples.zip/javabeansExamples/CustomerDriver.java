import java.io.*;

public class CustomerDriver
{
   public static void main(String arg[])
   {

		Customer customerA;
		Customer customerB;

		customerA = new Customer("Janine", 24);

		try {
			// save customerA	
			customerA.save("foo.bar");
			System.out.println("Customer A");
			System.out.println(customerA);

			// load customer object from file foo.bar
			customerB = null;
			customerB = Customer.load("foo.bar");
			System.out.println("Customer B");
			System.out.println(customerB);
		}

		catch (IOException exc)
		{
			System.out.println(exc); 
		}
		catch (ClassNotFoundException exc)
		{
			System.out.println(exc);  
		}

   }
}

/*
Customer A
Name: Janine
Age:  24
Customer B
Name: Janine
Age:  24
*/
