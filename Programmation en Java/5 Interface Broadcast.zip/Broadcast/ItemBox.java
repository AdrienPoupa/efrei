package broadcast;

public class ItemBox implements VisualItem {
    public void Draw() {
        System.out.println("Draw a box");
    }
}
