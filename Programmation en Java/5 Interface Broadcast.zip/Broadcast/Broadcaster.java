package broadcast;

import java.util.List;
import java.util.ArrayList;

public class Broadcaster {
    private List<VisualItem> visualItems = new ArrayList<VisualItem> ();

    public void addItem(VisualItem visualItem) {
        items.add(visualItem);
    }
    
    public void drawAllItems() {
        for (VisualItem visualItem : visualItems)
	  {
     			visualItem.draw();  
	 }
    }
}