package broadcast;

public interface VisualItem  {
    abstract public void Draw();
    abstract public void Eat();
}