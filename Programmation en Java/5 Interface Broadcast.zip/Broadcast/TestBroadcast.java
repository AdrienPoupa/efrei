package broadcast;

public class TestBroadcast {
    public static void main(String args[]) {
		test();
	}

     public static void test() {

        Broadcaster b = new Broadcaster();
        
         
        b.addItem(new ItemBox());
                
        b.addItem(new ItemCircle());
       
        System.out.println("TOUT LE MONDE DESSINE!");
        b.drawAllItems();
        
     }
}




