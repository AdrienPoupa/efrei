package broadcast;

public class ItemCircle implements VisualItem {
    public void Draw() {
        System.out.println("Draw a circle");
    }
 }
