/**
 * TP6 exercice 4 questions 3:
 * QUESTION 3
 * Comment doit on corriger le probl�me ?
 * Modifier la classe CounterBug en cons�quence.
 * REPONSE
 * on utilise un verrou pour synchroniser
 */

package concurrent;

public class CounterSync implements Runnable {
  private boolean stop;
  private final Object lock = new Object();
  
  public void run() {
    int localCounter = 0;
    for(;;) {
      synchronized(lock) {
        if (stop) {
          break;
        }
        localCounter++;
      }
    }
    System.out.println(localCounter);
  }
  
  public void stop() {
    synchronized(lock) {
      stop = true;
    }
  }
  
  public static void main(String[] args) throws InterruptedException {
    CounterSync counter = new CounterSync();
    Thread thread = new Thread(counter);
    thread.start();
    Thread.sleep(100);
    counter.stop();
    thread.join();
  }
}