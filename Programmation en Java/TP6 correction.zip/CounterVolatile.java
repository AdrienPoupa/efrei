/**
 * TP6 exercice 4 questions 4:
 * QUESTION 4
 * On cherche maintenant a accel�rer le code en utilisant le mot cl�volatile�au lieu des blocs�synchronized.�
 * Comment appelle t-on les implantations qui n'ont ni blocs synchronized ni lock ?�
 * REPONSE
 * On dit qu'elles sont lock-free.
 */

package concurrent;

public class CounterVolatile implements Runnable {
  private volatile boolean stop;
 
  
  public void run() {
    int localCounter = 0;
    for(;;) {
        if (stop)
          break;
        localCounter++;
      }
    System.out.println(localCounter);
  }
  
  public void stop() {
      stop = true;
  }
  
  public static void main(String[] args) throws InterruptedException {
    CounterVolatile counter = new CounterVolatile();
    Thread thread = new Thread(counter);
    thread.start();
    Thread.sleep(100);
    counter.stop();
    thread.join();
  }
}