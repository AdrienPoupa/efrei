/**
 * TP6 exercice 4 questions 1 et 2 :
 * On cherche � savoir combien d'it�rations d'une boucle on peut faire en 100 millisecondes, le code suivant est donn� : 
 * 
 * QUESTION 1
 * Sans ex�cuter le code, que fait ce programme ?
* REPONSE
* Le programme d�marre un thread qui incr�mente un compteur en boucle tant que le boolean stop est faux. 
* Le thread�main�attend 100 millisecondes et positionne le boolean � true. 
* Le comportement voulu est l'arr�t du thread secondaire. 
* Cependant comme il n'y a aucune synchronisation, le thread secondaire peut garder une valeur locale de stop 
* et ne jamais voir le passage �true. 
* Il est possible que le thread secondaire boucle ind�finiment.
* 
* QUESTION 2
* V�rifier en ex�cutant le programme (plusieurs fois) si vous avez vu juste.
* REPONSE
* Effectivement, dans certain cas, le thread secondaire boucle � l'infini.
*/

package concurrent;

public class CounterBug implements Runnable {
	private boolean stop;

	public void run() {
		int localCounter = 0;
		for(;;) {
			if (stop) {
				break;
			}
			localCounter++;
		}
		System.out.println(localCounter);
	}

	public void stop() {
		stop = true;
	}

	public static void main(String[] args) throws InterruptedException {
		CounterBug counter = new CounterBug ();
		Thread thread = new Thread(counter);
		thread.start();
		Thread.sleep(100);
		counter.stop();
		thread.join();
	}
}

