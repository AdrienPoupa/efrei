package concurrent;

import java.util.stream.IntStream;
import java.util.function.IntConsumer;

import java.util.ArrayList;
import java.util.List;



public class HelloThreadTest {
	public static void main(String[] args) {
		//exo1();
		//exo2();
		exo3();
		exo3bis();
		exo3ter();
	}

	/**
	 * TP6 exercice 1 :
	 */
	public static void exo1(){
		int nbThreads = 4;
		for(int i = 0; i < nbThreads; i++){
			HelloThread helloThread = new HelloThread(i);
		}

		// Avec Java 1.8
		HelloThreadLambda helloThreadLambda = new HelloThreadLambda();
		HelloThreadStream helloThreadStream = new HelloThreadStream();
	}

	/**
	 * TP6 exercice 2 : la m�thode join
	 * la m�thode join attend la terminaison du thread
	 */
	public static void exo2(){
		int nbThreads = 4;

		// on attend tous les threads
		HelloThreadJoin [] helloThreadJoins = new HelloThreadJoin[nbThreads];
		for(int i = 0; i < nbThreads; i++){
			helloThreadJoins[i] = new HelloThreadJoin(i);
		}

		// on attend la terminaison de tous les threads
		for(HelloThreadJoin helloThreadJoin : helloThreadJoins){
			try {
				helloThreadJoin.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Tous les threads sont termin�s.");

		// Pour BIEN COMPRENDRE la m�thode join!
		// on attend uniquement la terminaison du thread 1
		for(int i = 0; i < nbThreads; i++){
			helloThreadJoins[i] = new HelloThreadJoin(i);
			if (i == 2)
				try {
					helloThreadJoins[i-1].join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		}
		System.out.println("FIN DU PROGRAMME!.");
	}

	/**
	 * TP6 exercice 3 : l'ArrayList bugg�e questions 1 et 2
	 */
	public static void exo3(){
		int nbThreads = 4;

		HelloThreadJoinListBug [] helloThreadJoinListBugs = new HelloThreadJoinListBug[nbThreads];
		for(int i = 0; i < nbThreads; i++){
			helloThreadJoinListBugs[i] = new HelloThreadJoinListBug(i);
		}

		// on attend la terminaison de tous les threads
		for(HelloThreadJoinListBug helloThreadJoinListBug : helloThreadJoinListBugs){
			try {
				helloThreadJoinListBug.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Tous les threads sont termin�s.");
		System.out.println("Taille de la liste : " + HelloThreadJoinListBug.size());
	}
	
	/**
	 * TP6 exercice 3 : l'ArrayList bugg�e question 3
	 */
	public static void exo3bis(){
		int nbThreads = 4;

		HelloThreadJoinListBug2 [] helloThreadJoinListBugs = new HelloThreadJoinListBug2[nbThreads];
		for(int i = 0; i < nbThreads; i++){
			helloThreadJoinListBugs[i] = new HelloThreadJoinListBug2(i);
		}

		// on attend la terminaison de tous les threads
		for(HelloThreadJoinListBug2 helloThreadJoinListBug : helloThreadJoinListBugs){
			try {
				helloThreadJoinListBug.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Tous les threads sont termin�s.");
		System.out.println("Taille de la liste : " + HelloThreadJoinListBug2.size());
	}
	
	
	/**
	 * TP6 exercice 3 : l'ArrayList non bugg�e question 4
	 */
	public static void exo3ter(){
		int nbThreads = 4;

		HelloThreadJoinList [] helloThreadJoinLists = new HelloThreadJoinList[nbThreads];
		for(int i = 0; i < nbThreads; i++){
			helloThreadJoinLists[i] = new HelloThreadJoinList(i);
		}

		// on attend la terminaison de tous les threads
		for(HelloThreadJoinList helloThreadJoinList : helloThreadJoinLists){
			try {
				helloThreadJoinList.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Tous les threads sont termin�s.");
		System.out.println("Taille de la liste : " + HelloThreadJoinList.size());
	}
}


/**
 * TP6 exercice 1
 */

/**
 * 1.Rappeler � quoi sert un�Runnable�?�
 * 
 * A sp�cifier du code (qui sera �x�cut� par une ou des threads).  
 * L'avantage de Runnable est que la classe peut alors �tendre une autre classe au choix.
 * En effet, Java ne permettant pas l'h�ritage multiple, si on d�finit une classe qui �tend la classe�Thread,cela interdit 
 * d'�tendre une autre classe. 
 * D'autre part, cela peut permettre de faire ex�cuter un m�me Runnable � plusieurs threads.
 */

/**
 * 3.Ex�cutez le programme plusieurs fois, que remarque t'on ?�
 * Puis, en regardant l'affichage (scroller au besoin), qu'y-a-t'il de bizarre ?�
 * Est-ce que tout ceci est bien normal ?�
 * 
 * A priori, on ne contr�le rien. Le scheduler est pr�emptif et interrompt quand il veut. 
 * Deux instructions de deux threads distincts n'ont a priori pas d'ordre d'ex�cution � respecter (entre eux).
 * C'est la machine virtuelle Java qui assure l'ordonnancement (la concurrence).
 */
class HelloThread implements Runnable {
	private static final int TOURS = 500;
	private String name;
	private Thread t;

	HelloThread(int i){
		name = i + "";
		t = new Thread(this);
		t.start();
	}

	public void run(){
		for(int index = 0; index < TOURS; index++) {
			System.out.println("hello thread " + name + ' ' + index);
		}
	}
}

/**
 *  TP6 exercice 1 en JAVA 8
 */
class HelloThreadLambda {
	public HelloThreadLambda(){ 
		final int nbThreads = 4;
		final int tours = 500;
		for(int i = 0; i < nbThreads; i++){
			int id = i; // pas besoin du final, il suffit d'�tre effectively final
			Runnable runnable = () -> {
				for(int index = 0; index < tours; index++) {
					System.out.println("hello thread lambda " + id + ' ' + index);
				}
			};
			new Thread(runnable).start();
		}
	}
}

/**
 *  TP6 exercice 1 en JAVA 8
 */
class HelloThreadStream {
	public HelloThreadStream(){ 
		final int nbThreads = 4;
		final int tours = 500;
		for(int i = 0; i < nbThreads; i++){
			int id = i; // pas besoin du final, il suffit d'�tre effectively final
			Runnable runnable = () -> {
				IntConsumer ic =  (index)-> System.out.println("hello thread stream " + id + ' ' + index);
				IntStream.range(0,tours).forEach(ic);
			};
			new Thread(runnable).start();
		}
	}
}

/**
 * TP6 exercice 2 : la m�thode join
 * la m�thode join attend la terminaison du thread
 */
class HelloThreadJoin implements Runnable {
	private static final int TOURS = 500;
	private String name;
	private Thread t;

	HelloThreadJoin(int i){
		name = i + "";
		t = new Thread(this);
		t.start();
	}

	public void run(){
		for(int index = 0; index < TOURS; index++) {
			System.out.println("hello thread join " + name + ' ' + index);
		}
	}	

	public void join() throws InterruptedException{
		t.join();
		System.out.println("hello thread join " + name + " termin�");
	}
}


/**
 * TP6 exercice 3 Questions 1 et 2
 * On souhaite modifier le programme pr�c�dent pour qu'au lieu d'afficher les nombres, on les stocke dans une unique�ArrayList�
 * (une seule liste pour toutes les threads) dont on affichera la taille � la fin du programme.
 * 
 * QUESTION 1
 * Recopiez la classe�HelloThreadJoin�dans une nouvelle classe�HelloListBug�puis modifiez la pour ajouter les nombres au lieu 
 * de les afficher et pour afficher la taille finale une fois toutes les threads termin�es.�
 * Ex�cuter le programme plusieurs fois et noter les diff�rents affichages (oui, m�me les exceptions).�
 *
 * OBSERVATIONS
 * Une ou plusieurs exceptions�ArrayOutOfBoundException�lev�es par l'appel �ArrayList.add.
 * Une taille totale inf�rieure � la valeur m�me lorsqu'il n'y a pas eu d'exception.
 * Rarement on observe le comportement attendu.
 * 
 * EXEMPLE DE BUG : 
 * at concurrent.HelloThreadJoinListBug.add(HelloThreadTest.java:229)
 * at concurrent.HelloThreadJoinListBug.run(HelloThreadTest.java:219)
 * at java.lang.Thread.run(Unknown Source)
 * hello thread join list bug 0 termin�
 * hello thread join list bug 1 termin�
 * hello thread join list bug 2 termin�
 * hello thread join list bug 3 termin�
 * Tous les threads sont termin�s.
 * Taille de la liste : 15010
 * 
 * QUESTION 2
 * Expliquer quel est le probl�me lorsqu'une exception est lev�e. 
 * Pour comprendre, il faut regarder le code de la m�thode�ArrayList.add.�
 * EXPLICATIONS :
 * L'appel �ArrayList.add�correspond:
 * On teste si size+1 > la capacit� courante.
 * Si ce n'est pas le cas, on augmente la capacit�.
 * Dans tous les cas, on augmente size et on rajoute l'�l�ment.
 * L'exception arrive quand la taille est �gale � la capacit�-1. 
 * Deux threads t1 et t2 veulent ajouter un �l�ment. Les deux font le test 1 et le passe donc personne n'augmente la capacit�. 
 * Puis le thread t1 augmente size et ajoute l'�l�ment. A ce moment size == capacity. 
 * Le thread t2 augmente size et ajoute element. 
 * Par suite, la taille est sup�rieure � la capacit� et on �crit en dehors du tableau.
 */
class HelloThreadJoinListBug implements Runnable {
	private static final int TOURS = 5000;
	private String name;
	private Thread t;
	private static List<Integer> results = new ArrayList<>();

	HelloThreadJoinListBug(int i){
		name = i + "";
		t = new Thread(this);
		t.start();
	}

	public void run(){
		for(int index = 0; index < TOURS; index++) {
			this.add(index);
		}
	}	

	public void join() throws InterruptedException{
		t.join();
		System.out.println("hello thread join list bug " + name + " termin�");
	}

	public boolean add(int n){
		return results.add(n);
	}
	
	public static int size(){
		return results.size();
	}
}


/**
 * TP6 exercice 3 en JAVA 8 questions 1 et 2
 * Avec une seule classe et la m�thode main
 */
class HelloListBug {
	public static void main(String[] args) throws InterruptedException {
		int nbThreads = 4;
		Thread[] threads = new Thread[nbThreads];
		List<Integer> results = new ArrayList<>();

		for(int i = 0; i < nbThreads; i++) {
			int id = i; // pas besoin du final, il suffit d'�tre effectively final
			Runnable runnable= () -> {
				for(int index = 0; index < 500; index++) {
					results.add(index);
				}
			};
			threads[i] = new Thread(runnable);
		}

		for(Thread t: threads) {
			t.start();
		}
		for(Thread t: threads) {
			t.join();
		}
		System.out.println("Taille de la liste : " + results.size());
	}
}


/**
* TP6 exercice 3 questions 3
* QUESTION 3
* Puisque l'exception se produit lorsque l'on agrandit l'ArrayList, on peut essayer de la cr�er avec la bonne taille.
*         ArrayList list = new ArrayList(5_000*4);
*             
* Ex�cuter le programme plusieurs fois et noter les diff�rents affichages.�
* Expliquer quel est le probl�me.�
* 
* EXPLICATIONS
* La taille de la liste est inf�rieure � 20000. 
* Le test 1 est vrai car on a mis la capacit� � 20000. 
* Le probl�me vient du fait que�size++�n'est pas une instruction atomique. 
* On lit d'abord la valeur de size puis on �crit size+1. 
* Si deux threads t1 et t2 veulent tous les deux ex�cuter size++, il se peut que t1 lise la valeur de size (disons 5) 
* et que t2 lise aussi la valeur de size juste apr�s (encore 5 donc). 
* Puis t1 �crit 6 et t2 �crit 6. 
* Donc deux size++ en parall�le vont r�sulter en un incr�ment de 1 seulement.
* 
* EXEMPLE DE BUG : 
* hello thread join list bug 0 termin�
* hello thread join list bug 1 termin�
* hello thread join list bug 2 termin�
* hello thread join list bug 3 termin�
* Tous les threads sont termin�s.
* Taille de la liste : 19997
*/
class HelloThreadJoinListBug2 implements Runnable {
	private static final int TOURS = 5000;
	private String name;
	private Thread t;
	private static List<Integer> results = new ArrayList<>(5_000*4);

	HelloThreadJoinListBug2(int i){
		name = i + "";
		t = new Thread(this);
		t.start();
	}

	public void run(){
		for(int index = 0; index < TOURS; index++) {
			this.add(index);
		}
	}	

	public void join() throws InterruptedException{
		t.join();
		System.out.println("hello thread join list bug " + name + " termin�");
	}

	public boolean add(int n){
		return results.add(n);
	}
	
	public static int size(){
		return results.size();
	}
}


/**
* TP6 exercice 3 question 4
* QUESTION 4
* Corriger le probl�me et v�rifier que la correction que vous avez effectu�e, ex�cute bien les threads en parall�le 
* et non pas les uns derri�re les autres.
* 
* REPONSE
* Il suffit de mettre un acc�s synchronis� pour l'ajout dans la liste!
* 
*  EXEMPLE :
*  hello thread join list bug 0 termin�
*  hello thread join list bug 1 termin�
*  hello thread join list bug 2 termin�
*  hello thread join list bug 3 termin�
*  Tous les threads sont termin�s.
*  Taille de la liste : 20000
*/
class HelloThreadJoinList implements Runnable {
	private static final int TOURS = 5000;
	private String name;
	private Thread t;
	private static List<Integer> results = new ArrayList<>();

	HelloThreadJoinList(int i){
		name = i + "";
		t = new Thread(this);
		t.start();
	}

	public void run(){
		for(int index = 0; index < TOURS; index++) {
			this.add(index);
		}
	}	

	public void join() throws InterruptedException{
		t.join();
		System.out.println("hello thread join list bug " + name + " termin�");
	}

	public boolean add(int n){
		synchronized(results){
			return results.add(n);
		}
	}
	
	public static int size(){
		return results.size();
	}
}


