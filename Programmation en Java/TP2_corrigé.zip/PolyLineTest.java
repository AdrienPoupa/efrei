package tp2;

import java.util.ArrayList;

public class PolyLineTest
{
	public static void main(String[] args)
	{
		System.out.println("1. PolyLine") ;
	
		PolyLine p = new PolyLine(3) ;
		
		p.addDebutant(new Point(1F, 0F)) ;
		p.addDebutant(new Point(2F, 1F)) ;
	//	p.addDebutant(new Point(2F, 2F)) ;
	//	p.addDebutant(new Point(2F, 3F)) ;
	
		try {
			p.add(new Point(2F, 3F)) ;
		}
		catch(IllegalStateException e) {
			System.out.println(e) ;
		}
		
		System.out.println(p.pointCount()) ;
		
		Point point = new Point(2F, 2F) ;
		System.out.println(p.contains(point)) ;
		
		PolyLine q = null ;
		System.out.println(q.contains(point)) ;
		try {
			System.out.println(q.contains(point)) ;
		}
		catch(NullPointerException e)
		{
			System.out.println(e) ;
		}
		
		q = new PolyLine(10) ;
		q.add(new Point(1F, 0F)) ;
		q.add(new Point(2F, 1F)) ;
		
		try
		{
			q.add(null) ;
		}
		catch(NullPointerException e)
		{
			System.out.println(e) ;
		}	
		
		// si l'instruction q.add(null) reussit, le point nul occupe
		// une place et contains() appliquera equals() a null
		try {
			System.out.println(q.contains(point)) ;
		}
		catch(NullPointerException e)
		{
			System.out.println(e) ;
		}
		
		System.out.println("2. FreePolyLine") ;
		FreePolyLine f = new FreePolyLine() ;
	
		try
		{
			f.add(new Point(1F, 0F)) ;
			f.add(new Point(2F, 1F)) ;
			f.add(new Point(2F, 2F)) ;
			f.add(new Point(1F, 0F)) ;
		}
		catch(UnsupportedOperationException e)
		{
			System.out.println(e) ;
		}
		
		System.out.println(f.pointCount()) ;
		System.out.println(f.contains(point)) ;
	}
}