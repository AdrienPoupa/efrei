package zoo;

import java.util.List;
import java.util.ArrayList;

public class Zoo {
	private List<Animal> animaux;

	public Zoo(){
		animaux = new ArrayList<Animal>();
	}
	
	public void ajouter(Animal e){
		animaux.add(e);
	}
	
	@Override
	public String toString() {
		return animaux.toString();
	}
}