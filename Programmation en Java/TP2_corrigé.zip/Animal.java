package zoo;


public abstract class Animal {

    private int poids;
    private String nom;

    public Animal(int poids, String nom) {
        this.poids = poids;
        this.nom = nom;
    }

    public abstract void mange();
    
    public String getNom() {
        return nom;
    }

    public int getPoids() {
        return poids;
    }

    @Override
    public String toString(){
		return getNom() + "_" + getPoids();
	}
}
