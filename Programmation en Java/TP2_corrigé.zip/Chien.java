package zoo;


public class Chien extends Animal {

	private String maitre;

	public Chien(int poids, String nom, String maitre) {
		super(poids, nom);
		this.maitre = maitre;
	}

	 public void mange()
	 {
		 System.out.println("Le chien mange du Pal");
	 }
	 
	public String getMaitre() {
		return maitre;
	}

	@Override
	public String toString(){
		return super.toString() + ":" + getMaitre();
	}
}
