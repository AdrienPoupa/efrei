package tp2;

import java.util.HashMap;

public class AnimalH
{
	private static HashMap<String, String> table = new HashMap<String, String>();
	
	public AnimalH()
	{
		table.put("Alice", "Edith le singe") ;
		table.put("Bob", "Izard le chamois") ;
		table.put("June", "Gold le poisson rouge") ;
	}

	public static void main(String[] args)
	{
		AnimalH animaux = new AnimalH() ;
	
		if (args.length != 1) 
		{
			System.out.println(">Vous devez rentrer un seul param�tre � votre programme!");
			return;
		}
		
		if (table.containsKey(args[0]))
				System.out.println("L'animal pr�f�r� de " + args[0]
				                              + " est " + table.get(args[0])) ;
	}
}
