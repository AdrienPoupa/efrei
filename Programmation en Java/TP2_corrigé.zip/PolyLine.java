package tp2;

public class PolyLine
{
	private final Point[] points;
	private int current;

	public PolyLine(int capacity)
	{
		points = new Point[capacity];
		current = 0; // inutile en Java
	}	

	public void addDebutant(Point p)
	{	
		if (p == null)
		{
			return;
		}
		points[current++] = p;	
	}

	// avec les exceptions
	public void add(Point p)
	{	
		if (p == null)
		{
			throw new NullPointerException("add null point") ;
		}

		try
		{
			points[current++] = p;
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			current -- ; //on r�pare les d�g�ts
			throw new IllegalStateException("run over maximum number of points: "
					+ pointCapacity()) ;
		}
	}

	public int pointCapacity() { return points.length; }

	public int pointCount() { return current; }

	public boolean contains(final Point p) 
	{
		for(int i=0; i < pointCount(); i++)
		{
			if (points[i].equals(p))
				return true;
		}

		return false;
	}
}
