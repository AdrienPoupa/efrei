package tp2;

public class AnimalPrefere
{	
	private static final String[] enfants = {"Alice", "Bob", "June"};
	
	private static final String[] animaux = {"Edith le singe", "Izard le chamois", "Gold le poisson rouge"};

	public static void main(String[] args)
	{
		if (args.length != 1) 
		{
			System.out.println(">Vous devez rentrer un seul param�tre � votre programme!");
			return;
		}
		
		for (int i = 0 ; i < enfants.length ; i ++)
		{
			if (args[0].compareToIgnoreCase(enfants[i]) == 0)
			{
				System.out.println("L'animal pr�f�r� de " + enfants[i] 
				                                       + " est " + animaux[i]);
				return;
			}
		}
	}
}
