package zoo;

public class Chat extends Animal {
	private String race;

	public Chat(int poids, String nom, String race) {
		super(poids, nom);
		this.race = race;
	}

	 public void mange()
	 {
		 System.out.println("Le chat mange du Ronron");
	 }
	 
	public String getRace() {
		return race;
	}
	
	@Override
	public String toString(){
		return super.toString() + ":" + getRace();
	}
}
