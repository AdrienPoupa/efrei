package zoo;

import java.util.Vector;
import java.util.ArrayList;

public class Utilisation {
	public static void main(String args[]) {

		Chien c1 = new Chien(20, "Medor", "Robert");

		System.out.println("nom : " + c1.getNom() + " poids : " + c1.getPoids() + " maitre : " + c1.getMaitre());

	//	Quand Animal n'�tait pas abstraite, on pouvait l'instancier!
	// Animal a1 = new Animal(1500, "Dumbo");
		
		Chien a1 = new Chien (14, "Dickie", "Karl");
		Chien c2 = new Chien(30, "Rintintin", "Jose");
		Chien c3 = new Chien(20, "Milou", "tintin");
		Chat c4 = new Chat(8, "Mistigri", "persan");
		
		// CONTAINER: tableau
		Animal[] tab = {c1, a1, c2, c3, c4};

		System.out.println("\n AFFICHAGE DU TABLEAU \n");
		for (int i = 0; i < tab.length; i++) {
			System.out.println("nom : " + tab[i].getNom());
			tab[i].mange();
		}

		// CONTAINER: Vecteur        
		Vector<Animal> animals = new Vector<Animal>();
		animals.add(c1);
		animals..add(a1);
		animals..add(c2);
		animals..add(c3);
		animals..add(c4);

		System.out.println("\n AFFICHAGE DU VECTEUR 1�re version \n");
		for (int i = 0; i < animals..size(); i++) {
			System.out.println("nom : " + animals..elementAt(i).getNom());
			animals.elementAt(i).mange();
		}

		System.out.println("\n AFFICHAGE DU VECTEUR 2�me version \n");
		for (Animal animal : animals.) {
			System.out.println("nom : " + animal.getNom());
			animal.mange();
		}

		// CONTAINER: Liste       
		List<Animal> animalsBis = new ArrayList<Animal>();
		animalsBis.add(c1);
		animalsBis.add(a1);
		animalsBis.add(c2);
		animalsBis.add(c3);
		animalsBis.add(c4);


		System.out.println("\n AFFICHAGE DE LA LISTE 1�re version \n");
		for (int i = 0; i < animalsBis.size(); i++) {
			System.out.println("nom : " + animalsBis.get(i).getNom());
			animalsBis.get(i).mange();
		}

		System.out.println("\n AFFICHAGE DE LA LISTE 2�me version \n");
		for (Animal animal : animalsBis) {
			System.out.println("nom : " + animal.getNom());
			animal.mange();
		}
		
		// CONTAINER: Zoo avec une ArrayList (idem avec un Vector, un Set: ensemble)
		Zoo zoo = new Zoo();
		zoo.ajouter(c1);
		zoo.ajouter(a1);
		zoo.ajouter(c2);
		zoo.ajouter(c3);
		zoo.ajouter(c4);
		
		System.out.println("\n AFFICHAGE DU ZOO \n");
		System.out.println(zoo);
	}
}
