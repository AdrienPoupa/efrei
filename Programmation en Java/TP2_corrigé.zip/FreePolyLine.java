package tp2;

import java.util.List;
import java.util.LinkedList;

public class FreePolyLine 
{
	private final List<Point> points;

	public FreePolyLine()
	{
		points = new LinkedList<Point>();
	}	

	public void add(Point p)
	{
		points.add(p);	
	}

	// public int pointCapacity() : inutile
	
	public int pointCount() { return points.size(); }

	public boolean contains(Point p)
	{
		return points.contains(p);
	}
}
