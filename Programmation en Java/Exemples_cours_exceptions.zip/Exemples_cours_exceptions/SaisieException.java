package Exceptions;

public class SaisieException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public SaisieException() {
		super();
	}  
	
	public SaisieException(String message) {  
		super(message); 
	}  
	 
	public SaisieException(Throwable cause) {  
		super(cause); 
	}  
	
	public SaisieException(String message, Throwable cause) {  
		super(message, cause); 
	} 
	
}
