package Exceptions;

public class Personne {


	private int numDep;
	
	public Personne(int numDep){
		try {
			setNumDep(numDep);
		}
		catch (SaisieException e) {
			e.printStackTrace();
		}
	}

	public void setNumDep(int numDep) throws SaisieException {
		if(numDep>99){
			throw new SaisieException("Le numéro de département est supérieur à 100");
		}
		if(numDep<1){
			throw new SaisieException("Le numéro de département est inférieur à 0");
		}
		this.numDep = numDep;
	}




	public static void main(String[] args) {
		

	}

}
