package Exceptions;

import java.util.List;

public class ClasseExemple2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> l = null;
		try{
			// On essaye de parser s
			l.add("");
			System.out.println("instruction 1");
		}
		catch(NullPointerException e){
			// Si le parse échoue, on met n à 0
			System.out.println("instruction 2");
		}
		

	}

}
