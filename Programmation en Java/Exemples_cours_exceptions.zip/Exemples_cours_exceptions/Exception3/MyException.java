package exception;

public class MyException extends Exception {

    private static final long serialVersionUID = 6086055989754264855L;

    public MyException() {
        super();
    }

    public MyException(String s) {
        super(s);
    }
}
