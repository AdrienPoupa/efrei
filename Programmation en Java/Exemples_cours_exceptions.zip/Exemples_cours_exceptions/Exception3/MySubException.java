
package exception;


public class MySubException extends MyException {

    private static final long serialVersionUID = -1676485992809484022L;

    public MySubException() {
        super();
    }

    public MySubException(String s) {
        super(s);
    }
}
