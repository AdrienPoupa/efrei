
package exception;


public class MyOtherException extends Exception {

    private static final long serialVersionUID = -818536999972187715L;

    public MyOtherException() {
        super();
    }

    public MyOtherException(String s) {
        super(s);
    }
}
