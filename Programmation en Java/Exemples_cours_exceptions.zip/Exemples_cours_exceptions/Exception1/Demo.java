package Exception;

import java.io.*;

public class Demo {

    public static void main(String arg[]) {
        BufferedReader s = new BufferedReader(new InputStreamReader(System.in));
        do {
            System.out.print(" age: ");
            System.out.flush();
            try {
                String str = s.readLine();
                int age = Integer.parseInt(str);
                if (age > 130) {
                    throw new AgeOver(age++ + " ans trop grand ");
                }
                if (age == 0) {
                    throw new AgeLess(" pas né ");
                }
            } catch (IOException ioc) {
                System.out.println(ioc.getMessage() + "\n erreur d’E/S ");
                System.exit(1);
            } catch (AgeOver a) {
                System.out.println(a.getMessage());
                continue;
            } catch (AgeLess a) {
                System.out.println(a.getMessage());
                System.exit(2);
            } catch (NumberFormatException nbe) {
                System.out.println(nbe.getMessage() + " il faut saisir une valeur entière ! ");
                continue;
            } finally {
                System.out.println(" Saisie effectuée ");
            }
        } while (true);
    }
}