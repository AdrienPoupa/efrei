/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Exception2;

/**
 *
 * @author anthony
 */
public class DivisionParZeroException extends Exception {

    private static final long serialVersionUID = -6015478299923798559L;
}
