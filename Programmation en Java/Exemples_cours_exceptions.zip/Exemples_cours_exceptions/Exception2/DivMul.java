/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Exception2;

/**
 *
 * @author anthony
 */
public class DivMul {

    private static int execOperation(int operande1, String operation, int operande2)
            throws DivisionParZeroException, OperationInconnueException {
        if ("*".equals(operation)) {
            return operande1 * operande2;
        }
        if ("/".equals(operation)) {
            if (operande2 == 0) {
                throw new DivisionParZeroException();
            }
            return operande1 / operande2;
        } else {
            throw new OperationInconnueException(operation);
        }

    }

    public static void main(String args[]) {
        System.out.println("exemple de traitement d'exceptions");

        int operande1[] = {3, 56, 33, 25};
        String operation[] = {"*", "/", "+", "/"};
        int operande2[] = {5, 4, 5, 0};

        for (int n = 0; n < operande1.length; n++) {
            try {
                System.out.println("Calcul de " + operande1[n] + operation[n] +
                        operande2[n]);
                System.out.println("Resultat" + execOperation(operande1[n], operation[n], operande2[n]));
            } catch (DivisionParZeroException e) {
                System.out.println("Division par zero.");
            } catch (OperationInconnueException e) {
                System.out.println("Operation inconnue " + e.getMessage());
            } catch (Exception e) {
                System.out.println("une autre exception est survenue.");
            } finally {
                System.out.println("clause finally appellee");
            }
        }
    }
}
