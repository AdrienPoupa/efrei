/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Exception2;

/**
 *
 * @author anthony
 */
public class OperationInconnueException extends Exception {

    private static final long serialVersionUID = 8883297007654137690L;

    public OperationInconnueException(String s) {
        super(s);
    }
}
