package Exceptions;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClasseExemple4 {
	
	public static void main(String[] arg0){
		String s = "abc";
		double d=0;
		try{
			d=Double.parseDouble(s);
		}
		catch(NumberFormatException exc){
			exc.printStackTrace();
		}
		finally{
			System.out.println("Traitement terminé");
		}
	}
}
