package Exceptions;

public class ClasseExemple1 {

	
	public static void main(String[] args) {
		String s = "";
		int n;
		try{
			// On essaye de parser s
			n=Integer.parseInt(s);
		}
		catch(NumberFormatException e){
			// Si le parse échoue, on met n à 0
			n=0;
		}
		System.out.println(n);

	}

}
