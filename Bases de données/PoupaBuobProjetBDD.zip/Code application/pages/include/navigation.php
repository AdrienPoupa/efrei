<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">Gestion académique des élèves - EFREI</a>
    </div>
    <!-- /.navbar-header -->

    <ul class="nav navbar-top-links navbar-right">
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-user">
                <li>
                    <a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Déconnexion</a>
                </li>
            </ul>
            <!-- /.dropdown-user -->
        </li>
        <!-- /.dropdown -->
    </ul>
    <!-- /.navbar-top-links -->

    <div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse">
            <ul class="nav" id="side-menu">
                <li>
                    <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Accueil</a>
                </li>
                <?php if ($_SESSION['role'] == 'eleve') : ?>
                    <li>
                        <a href="bulletin.php"><i class="fa fa-dashboard fa-fw"></i> Bulletin</a>
                    </li>
                <?php endif; ?>
                <?php if ($_SESSION['role'] == 'prof') : ?>
                    <li>
                        <a href="notes.php"><i class="fa fa-table fa-fw"></i> Notes</a>
                    </li>
                    <li>
                        <a href="cours.php"><i class="fa fa-table fa-fw"></i> Cours</a>
                    </li>
                <?php endif; ?>
                <?php if ($_SESSION['role'] == 'admin') : ?>
                <li>
                    <a href="eleves.php"><i class="fa fa-table fa-fw"></i> Élèves <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="eleves.php">Liste des élèves</a>
                        </li>
                        <li>
                            <a href="nouvel-eleve.php">Ajouter un élève</a>
                        </li>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                    <a href="responsables.php"><i class="fa fa-table fa-fw"></i> Responsables <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="responsables.php">Liste des responsables</a>
                        </li>
                        <li>
                            <a href="nouveau-responsable.php">Ajouter un responsable</a>
                        </li>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                    <a href="professeurs.php"><i class="fa fa-table fa-fw"></i> Professeurs <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="professeurs.php">Liste des professeurs</a>
                        </li>
                        <li>
                            <a href="nouveau-professeur.php">Ajouter un professeur</a>
                        </li>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                    <a href="groupes.php"><i class="fa fa-table fa-fw"></i> Groupes <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="groupes.php">Liste des groupes et élèves</a>
                        </li>
                        <li>
                            <a href="nouveau-groupe.php">Ajouter un groupe</a>
                        </li>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                    <a href="cours.php"><i class="fa fa-table fa-fw"></i> Cours<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="cours.php">Liste des cours</a>
                        </li>
                        <li>
                            <a href="nouveau-cours.php">Ajouter un cours</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="notes.php"><i class="fa fa-table fa-fw"></i> Notes</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- /.sidebar-collapse -->
    </div>
    <!-- /.navbar-static-side -->
</nav>