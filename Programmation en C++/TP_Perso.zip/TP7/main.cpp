#include <iostream>
#include "Expression.h"

using namespace std;

int main() {

    cout << "Premiere partie" << endl;
    Cos *c = new Cos(new Constante(M_PI/3.0));
    cout << *c << " = " << c->eval() << endl;
    Expression::toutLiberer();

    return 0;
}
