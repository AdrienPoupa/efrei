POUPA Adrien
BUOB Edgar
Efrei L'3

_Introduction_

* Quel mécanisme important des langages de programmation objet va-t-on utiliser et comment peut-on le
mettre en œuvre en C++ ?

On va utiliser des templates pour gérer des types génériques.

_Première partie_

__Classe "Expression"__

* Que peut-on dire de la méthode  eval de la classe "Expression" ?

Cette méthode est virtuelle pure car "= 0" à la fin de la déclaration de la méthode.

* Qu’est-ce que cela implique pour la classe "Expression" ?

On ne peut pas instancier la classe "Expression"; seulement utiliser des pointeurs ou des références vers elle.

* Comment appelle-t-on ce genre de classe ?

Une classe qui comporte au moins une méthode virtuelle pure est dite "classe abstraite".

* Expliquez ce que permet de faire l’attribut  _pool ?

Le pool est un gestionnaire de ressources rudimentaire; il permet de
- compter et enregistrer les adresses de toutes les instances "en vie"
- retrouver l’adresse d’une instance par son nom
- libérer toutes les instances qui ne l’ont pas été à la fin du programme

* Est-ce un attribut d’instance ou un attribut de classe ?

C'est un attribut de classe.

* Que fait le constructeur de la classe "Expression" ?

Expression(const string& nom) enregistre dans le pool l'instance actuelle.

* Que fait son destructeur ?

virtual ~Expression() libère l'instance actuelle du pool.

* Pourquoi le destructeur de la classe "Expression" est-il  virtual ?

Puisque la classe ne peut être instanciée, étant donnée qu'elle est abstraite, elle est
destinée à être utilisée polymorphiquement, c'est-à-dire utilisée en place d'un objet de la classe mère.

On veut utiliser le destructeur de la classe instanciée.

Il faut donc être sûr que le bon destructeur sera appelé, d'où le "virtual".

* De quel type est la méthode "toutLiberer" ?

static void toutLiberer() : fonction statique ne retournant rien, pas liée à un objet.
Elle ne peut donc accéder à d'autres membres d'instances de la classe sinon les membres statiques.

* Quel est son rôle ?

Elle applique itérativement l'operateur delete au premier élément du pool tant que le pool n’est pas vide.

* Quand sera-t-elle certainement appelée dans le programme principal ?

Elle sera sûrement appelée à la fin du programme principal.

* La fonction "friend ostream& operator<<(ostream&, const Expression&)" est-elle une méthode de la
classe "Expression" ?

La fonction est amie: sans faire partie directement de la classe "Expression", elle a accès
à tous ses attributs.

* Cette dernière ne pouvant pas être instanciée, à quoi sert cette fonction ?



* Quel est le nom ( _nom ) donné à une instance de la classe "Constante" ?

On aura _nom = val avec Constante(double val) puisque "Constante" hérite de "Expression"
C'est à dire Constante(3.0) => _nom = 3.0

__Classe "Unaire"__

* Décrire exactement ce que fait la méthode "str()" de la classe "Unaire".

str() retourne une chaîne telle que "cos(exp)" ou "exp(sin)" à partir des deux
arguments pris par le constructeur.

* Dessiner le diagramme de classes du fichier "expression.h". Faites ressortir les classes abstraites.

Expression abstraite
	Constante
	Unaire abstraite
		Cos
		Sin

Une tabulation = héritage de la classe au-dessus

__Synthèse__

* Quelle est la sortie standard obtenue par l’exécution du programme principal suivant ?

Premiere partie
enregistrer 1.0472
enregistrer cos
cos(1.0472) = 0.5
