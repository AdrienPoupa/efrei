#include <iostream>

using namespace std;

class Livre {
    string _title, _author, _published, _price;

    // Les getters et setters sont publics
    public:
        void setTitle(const string title);
        string getTitle();
        void setAuthor(const string author);
        string getAuthor();
        void setPublished(const string published);
        string getPublished();
        void setPrice(const string price);
        string getPrice();
        ~Livre();
};
