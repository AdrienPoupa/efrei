#include <iostream>
#include "livre.h"

using namespace std;

int main()
{
    // Initialisation de notre instance
    Livre *premierLivre = new Livre;

    // Initialisation des chaines qu'on va saisir
    string title, author, published, price;

    cout << "[Votre livre]" << endl;

    cout << "Veuillez indiquer les information de votre livre" << endl << endl;

    // Ici, on va utiliser getline pour r�cup�rer plusieurs mots
    cout << "Nom du livre: ";
    getline(cin, title);

    // Et on fait appel au setter pour rentrer notre chaine dans la classe
    premierLivre->setTitle(title);

    cout << "Auteur du livre: ";
    getline(cin, author);

    premierLivre->setAuthor(author);

    cout << "Publication: ";
    getline(cin, published);

    premierLivre->setPublished(published);

    cout << "Prix: ";
    getline(cin, price);

    premierLivre->setPrice(price);

    cout << endl << "[Classe]" << endl;

    // R�cup�ration et affichage des �l�ments de la classe
    cout << "Titre: " << premierLivre->getTitle() << endl;
    cout << "Auteur: " << premierLivre->getAuthor() << endl;
    cout << "Publie: " << premierLivre->getPublished() << endl;
    cout << "Prix: " << premierLivre->getPrice() << endl;

    // Inutile mais bonne pratique: suppression de notre instance
    delete premierLivre;

    return 0;
}
