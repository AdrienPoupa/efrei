#include <iostream>
#include "livre.h"

using namespace std;

int main()
{
    int nombreLivres, i;
    int choixUtilisateur = 0;

    // Initialisation des chaines qu'on va saisir
    string title, author, published, price;

    cout << "Combien de livres voulez-vous rentrer ?" << endl;
    cin >> nombreLivres;
    cin.ignore();

    // On initialise un tableau d'objets
    Livre *livre[nombreLivres];

    // On remplit le tableau d'objet case par case
    for (i = 0; i < nombreLivres; i++) {
        livre[i] = new Livre;

        cout << endl << "[Votre livre " << i + 1 << "]" << endl;

        cout << "Veuillez indiquer les information de votre livre" << endl << endl;

        // Ici, on va utiliser getline pour r�cup�rer plusieurs mots
        cout << "Nom du livre: ";
        getline(cin, title);

        // Et on fait appel au setter pour rentrer notre chaine dans la classe
        livre[i]->setTitle(title);

        cout << "Auteur du livre: ";
        getline(cin, author);

        livre[i]->setAuthor(author);

        cout << "Publication: ";
        getline(cin, published);

        livre[i]->setPublished(published);

        cout << "Prix: ";
        getline(cin, price);

        livre[i]->setPrice(price);
    }

    // Affichage du menu
    cout << endl << "[Menu]" << endl;

    for (i = 0; i < nombreLivres; i++) {
        cout << i + 1 << ". " << livre[i]->getTitle() << endl;
    }
    cout << nombreLivres + 1 << ". " << "Quitter" << endl;

    // Boucle d'affichage des livres
    do {
        cout << endl << "Quel livre voulez-vous afficher ? ";
        cin >> choixUtilisateur;
        cin.ignore();

        // On n'affiche pas les livres si on veut sortir
        if (choixUtilisateur != (nombreLivres + 1)) {
            // Ici on utilise choixUtilisateur - 1 car le tableau est initialis� � z�ro
            cout << endl << "Titre: " << livre[choixUtilisateur - 1]->getTitle() << endl;
            cout << "Auteur: " << livre[choixUtilisateur - 1]->getAuthor() << endl;
            cout << "Publie: " << livre[choixUtilisateur - 1]->getPublished() << endl;
            cout << "Prix: " << livre[choixUtilisateur - 1]->getPrice() << endl;
        }

    } while (choixUtilisateur != (nombreLivres + 1));

    // Inutile mais bonne pratique: suppression de notre instance, une par une
    for (i = 0; i < nombreLivres; i++) {
        delete livre[i];
    }

    return 0;
}
