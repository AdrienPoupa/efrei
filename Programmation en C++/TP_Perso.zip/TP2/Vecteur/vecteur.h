class Vector3 {
    double _coeff[3];

    public:
        void initVector(double *coeff); // C
        void init(Vector3& v); // C++
        void print();
        void saisie();
        Vector3 product(double s);
        void multiply(const Vector3& v);
        double& coeff(unsigned i) { return _coeff[i]; }
        double coeff(unsigned i) const { return _coeff[i]; }
        Vector3(double x = 0, double y = 0, double z = 0);
        //Vector3(const Vector3 & v);
        double get(int x);
        void homotethie(double k);
        void produitScalaire(Vector3 v1, Vector3 v2);
        void produitVectoriel(Vector3 v1, Vector3 v2);
};
