#include <iostream>
#include "vecteur.h"

using namespace std;

void Vector3::initVector(double *coeff) {
    int i;

    for (i = 0; i < 3; i++) {
        _coeff[i] = coeff[i];
    }
}

void Vector3::init(Vector3& v) {
    int i;

    for (i = 0; i < 3; i++) {
        v.coeff(i) = 0.0;
    }
}

void Vector3::saisie() {
    int i;

    for (i = 0; i < 3; i++) {
        cin >> _coeff[i];
        cin.ignore();
    }
}

void Vector3::print() {
    int i;

    for (i = 0; i < 3; i++) {
        cout << _coeff[i] << endl;
    }
    cout << endl;
}

Vector3::Vector3(double x, double y, double z) {
    _coeff[0] = x;
    _coeff[1] = y;
    _coeff[2] = z;
}

double Vector3::get(int x) {
    return _coeff[x];
}

void Vector3::homotethie(double k) {
    _coeff[0] = _coeff[0]*k;
    _coeff[1] = _coeff[1]*k;
    _coeff[2] = _coeff[2]*k;
}

void Vector3::produitScalaire(Vector3 v1, Vector3 v2) {
    _coeff[0] = v1.get(0)*v2.get(0);
    _coeff[1] = v1.get(1)*v2.get(1);
    _coeff[2] = v1.get(2)*v2.get(2);
}

void Vector3::produitVectoriel(Vector3 v1, Vector3 v2) {
    _coeff[0] = v1.get(1)*v2.get(2) - v1.get(2)*v2.get(1);
    _coeff[1] = - v1.get(0)*v2.get(2) + v1.get(2)*v2.get(0);
    _coeff[2] = v1.get(0)*v2.get(1) - v1.get(1)*v2.get(0);
}
