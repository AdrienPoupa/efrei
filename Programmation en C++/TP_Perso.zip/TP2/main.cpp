#include <iostream>
#include "vecteur.h"

using namespace std;

int main()
{
    // Init en C
    cout << "En C" << endl;
    Vector3 v1 = Vector3(47, 28, 49);
    v1.print();

    double coeff[3] = {1, 2, 45};
    v1.initVector(coeff);
    cout << "V1" << endl;
    v1.print();

    // En C++
    cout << "En C++" << endl;
    Vector3 v2 = Vector3(3, 456, 23);
    v2.print();

    v2.init(v2);
    v2.print();

    Vector3 v3 = Vector3();
    cout << "Saisie du vecteur" << endl;
    v3.saisie();
    cout << "Affichage du vecteur " << endl;
    v3.print();

    cout << "Homotethie avec k = 3" << endl;
    v3.homotethie(3);
    cout << "V3" << endl;
    v3.print();

    cout << "Produit scalaire V1*V3" << endl;
    Vector3 v4;
    v4.produitScalaire(v1, v3);
    v4.print();

    cout << "Produit vectoriel V1^V3" << endl;
    Vector3 v5;
    v5.produitVectoriel(v1, v3);
    v5.print();

    return 0;
}
