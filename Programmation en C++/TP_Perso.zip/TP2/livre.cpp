#include <iostream>
#include "livre.h"

using namespace std;

void Livre::setTitle(const string title) {
    _title = title;
}

string Livre::getTitle() {
    return _title;
}

void Livre::setAuthor(const string author) {
    _author = author;
}

string Livre::getAuthor() {
    return _author;
}

void Livre::setPublished(const string published) {
    _published = published;
}

string Livre::getPublished() {
    return _published;
}

void Livre::setPrice(const string price) {
    _price = price;
}

string Livre::getPrice() {
    return _price;
}

Livre::~Livre() {
}
