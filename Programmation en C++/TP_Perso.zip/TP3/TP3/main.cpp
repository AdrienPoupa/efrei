#include <iostream>
#include "etudiant.h"

using namespace std;

int main()
{
    int nombreNotes, i, note, id;

    string nom, prenom;

    cout << "Quel est l'identifiant ?" << endl;
    cin >> id;
    cin.ignore();

    cout << "Quel est votre prenom ?" << endl;
    cin >> prenom;
    cin.ignore();

    cout << "Quel est votre nom ?" << endl;
    cin >> nom;
    cin.ignore();

    cout << "Combien de notes voulez-vous rentrer ?" << endl;
    cin >> nombreNotes;
    cin.ignore();

    // Pas besoin d'utiliser les setters/getters: on initialise directement la classe
    Etudiant etudiant(id, prenom, nom, nombreNotes);

    // Boucle pour l'ajout de notes au tableau
    for (i = 0; i < nombreNotes; i++) {
        cout << "Note " << i+1 << endl;
        cin >> note;
        etudiant.ajouterNote(note);
        cin.ignore();
    }

    // Affichage des notes
    etudiant.afficherNotes();

    // Duplication de l'instance actuelle
    cout << "Duplication..." << endl;
    Etudiant etudiant2;
    etudiant2 = etudiant;

    etudiant2.afficherNotes();

    return 0;
}
