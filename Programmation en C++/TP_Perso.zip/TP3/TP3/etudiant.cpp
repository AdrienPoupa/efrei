#include "etudiant.h"

using namespace std;

Etudiant::Etudiant(unsigned int id, string prenom, string nom, int nombreNotes) {
    _notes = new float[nombreNotes];
    _nombreNotes = nombreNotes;
    _id = id;
    _prenom = prenom;
    _nom = nom;
    _derniereNote = 0;
}

void Etudiant::setPrenom(string prenom) {
    _prenom = prenom;
}

Etudiant::~Etudiant() {
    // Il ne faudrait pas mettre de cout, mais pour la premi�re fois on peut le voir � l'action :-)
    cout << "Destruction de l'instance actuelle..." << endl;
    delete _notes;
}

void Etudiant::setNom(string nom) {
    _nom = nom;
}

void Etudiant::setId(unsigned int id) {
    _id = id;
}

string Etudiant::getPrenom() {
    return _prenom;
}

string Etudiant::getNom() {
    return _nom;
}

unsigned int Etudiant::getId() {
    return _id;
}

// Ajout des notes en faisant attention � la limite du tableau
void Etudiant::ajouterNote(float note) {
    if (_derniereNote < _nombreNotes) {
        _notes[_derniereNote] = note;
    }

    ++_derniereNote;
}

void Etudiant::afficherNotes() {
    int i;

    cout << _prenom << " " << _nom << " (ID " << _id << ") voici vos notes:" << endl;

    for (i = 0; i < _nombreNotes; i++) {
        cout << "Note " << i+1 << ": " << _notes[i] << endl;
    }
}
