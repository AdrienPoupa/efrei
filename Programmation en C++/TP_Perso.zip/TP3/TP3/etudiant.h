#include <iostream>

using namespace std;

class Etudiant {
    string _nom, _prenom;
    unsigned int _id;
    int _derniereNote, _nombreNotes;
    float *_notes;

    public:
        Etudiant(unsigned int id = 1, string prenom = "", string nom = "", int nombreNotes = 5);
        Etudiant(Etudiant const& etudiantCopie); // Constructeur de copie
        ~Etudiant();
        void setNom(string nom);
        void setPrenom(string prenom);
        void setId(unsigned int id);
        string getNom();
        string getPrenom();
        unsigned int getId();
        void ajouterNote(float note);
        void afficherNotes();
};
