#include <iostream>
#include <iomanip>
#include <math.h>

// On pourrait faire un algorithme plus efficace en utilisant le crible d'Eratosth�ne,
// mais ce n'est pas demand� par le sujet

using namespace std;

int EstPremier(int nombre);
void Lecture(int tableau[], int taille);

int main()
{
    int n(0), i(0), retour(0), compteurPremiers(0);

    cout << "Jusqu'ou voulez-vous afficher les nombres premiers?" << endl;
    cin >> n;
    cin.ignore();

    int tableauPremiers[n];

    // On remplit le tableau avec les "n" premiers entiers
    while (compteurPremiers < n) {
        retour = EstPremier(i);

        if (retour == 1) {
            tableauPremiers[compteurPremiers] = i;
            ++compteurPremiers;
        }
        ++i;
    }

    // Affichage des entiers jusqu'� "n"
    Lecture(tableauPremiers, n);

    return 0;
}

void Lecture(int tableau[], int taille)
{
    int i;

    for (i = 0; i < taille; i++){
        // On n'affiche que si le contenu du tableau parcouru est inf�rieur ou �gal � ce qu'on veut afficher
        if (tableau[i] <= taille) {
            cout << tableau[i] << " ";
        }
    }
}

int EstPremier(int nombre)
{
    int i;

    // 0 et 1 ne sont pas premiers
    if (nombre == 0 || nombre == 1) {
        return 0;
    }

    // 2 est premier
    if (nombre == 2) {
        return 1;
    }

    // Au dessus de 2, on boucle
    for (i = 2; i < nombre; i++) {
        if (nombre % i == 0) {
            return 0;
        }
    }

    // Si on ne s'est pas arr�t� dans la boucle, alors le nombre est premier
    return 1;
}
