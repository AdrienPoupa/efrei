#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float noteFilm(0), noteFilm100(0), noteFilm5(0);

    // Saisie de la note sur 20
    cout << "Votre note au film \"Forrest Gump\" sur 20:" << endl;
    cin >> noteFilm;

    // Validation de la note
    if (noteFilm < 0 || noteFilm > 20) {
        cout << "Veuillez rentrer une note entre 0 et 20" << endl;
    }
    // Calcul et affichage des notes sur 5 et 20
    else {
        noteFilm100 = noteFilm * 5;
        noteFilm5 = noteFilm100 / 20;

        // On affiche avec une pr�cision de 2 chiffres apr�s la virgule
        cout << "Note sur 100: " << setprecision(4) << noteFilm100 << endl;
        cout << "Note sur 5: " << setprecision(3) << noteFilm5 << endl;
    }

    return 0;
}
