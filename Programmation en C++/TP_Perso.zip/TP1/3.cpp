#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

void afficherMenu() {
    cout << "Les operations suivantes sont possibles:" << endl;
    cout << "1. Plus grand nombre " << endl;
    cout << "2. Moyenne et variance des nombres " << endl;
    cout << "3. Plus petit nombre et sa position " << endl;
    cout << "4. Recherche un nombre x dans le tableau " << endl;
    cout << "5. Quitter " << endl;
}

void saisieOperateur(int *operateur) {
    cin >> *operateur;
    cin.ignore();
}

/*void addition(float *operande1, float *operande2) {
    cout << "Addition" << endl;
    saisieOperandes(operande1, operande2);
    cout << *operande1 << " + " << *operande2 << " = " << *operande1 + *operande2 << setprecision(5) << endl;
}*/

void saisieTailleTableau(int *tailleTableau) {
    cout << "Saisie de la taille du tableau: " << endl;
    cin >> *tailleTableau;
    cin.ignore();
}

void saisieTableau(int tableau[], int *tailleTableau){
    int i(0);
    for (i = 0; i < *tailleTableau; i++) {
        cout << "Saisie de l'element " << i + 1 << endl;
        cin >> tableau[i];
        cin.ignore();
    }
}

void plusGrandNombre(int tableau[], int tailleTableau) {
    int i(0), plusGrand(0);

    for (i = 0; i < tailleTableau; i++) {
        if (tableau[i] > plusGrand) {
            plusGrand = tableau[i];
        }
    }

    cout << "L'element le plus grand est " << plusGrand << endl;
}

void plusPetitNombre(int tableau[], int tailleTableau) {
    int i(0), plusPetit(0), position(0);

    // On initialise le plus petit �l�ment � la prem�re case
    plusPetit = tableau[0];

    for (i = 0; i < tailleTableau; i++) {
        if (tableau[i] < plusPetit) {
            plusPetit = tableau[i];

            // On note et on incr�mente sa position de 1 pour la lecture
            position = i + 1;
        }
    }

    cout << "L'element le plus petit est " << plusPetit << " sa position est " << position << endl;
}

void moyenneEtVariance(int tableau[], int tailleTableau) {
    int i(0);
    float somme(0), sommeCarree(0), moyenne(0), variance(0);

    for (i = 0; i < tailleTableau; i++) {
        // Somme pour la moyenne
        somme += tableau[i];

        // Somme carr�e pour la variance
        sommeCarree += tableau[i]*tableau[i];
    }

    moyenne = somme / tailleTableau;

    // Pour calculer la variance, on utilise le th�or�me de K�nig-Huygens
    // https://fr.wikipedia.org/wiki/Variance_(statistiques_et_probabilit�s)
    variance = ((1/tailleTableau)*sommeCarree) - moyenne*moyenne;

    cout << "La moyenne est " << setprecision(3) << moyenne << endl;
    cout << "La variance est " << setprecision(3) << variance << endl;
}

void recherche(int tableau[], int tailleTableau) {
    int i(0), plusGrand(0), nombreCherche(0);

    cout << "Quel element recherchez-vous ?" << endl;
    cin >> nombreCherche;
    cin.ignore();

    for (i = 0; i < tailleTableau; i++) {
        if (tableau[i] == nombreCherche) {
            cout << "L'element recherche a ete trouve en position " << i + 1 << endl;
            return;
        }
    }

    cout << "L'element recherche n'a pas ete trouve" << endl;
}

int main()
{
    int *operateur(0);
    operateur = new int;

    int *tailleTableau(0);
    tailleTableau = new int;

    int i(0);

    saisieTailleTableau(tailleTableau);

    int tableau[*tailleTableau];

    saisieTableau(tableau, tailleTableau);

    do {
        afficherMenu();

        saisieOperateur(operateur);

        if (*operateur == 5) {
            return 0;
        }

        if (*operateur > 5 || *operateur < 1) {
            cout << "Votre selection est incorrecte" << endl;
        }
        else {
            switch (*operateur) {
                case 1:
                    plusGrandNombre(tableau, *tailleTableau);
                    break;
                case 2:
                    moyenneEtVariance(tableau, *tailleTableau);
                    break;
                case 3:
                    plusPetitNombre(tableau, *tailleTableau);
                    break;
                case 4:
                    recherche(tableau, *tailleTableau);
                    break;
            }
        }
    } while (*operateur != 5);

    delete operateur;
    delete tailleTableau;

    return 0;
}
