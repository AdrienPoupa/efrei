#include <iostream>
#include <iomanip>

using namespace std;

int main(){
    int taille(0), i(0), j(0);

    cout << "Sens dessus dessous" << endl;
    cout << "Entrez la taille de votre tableau" << endl;

    cin >> taille;
    cin.ignore();

    // D�claration dynamique du tableau
    // http://stackoverflow.com/questions/936687/how-do-i-declare-a-2d-array-in-c-using-new
    int** tableau = new int*[taille];
    for(int i = 0; i < taille; ++i) {
        tableau[i] = new int[taille];
    }

    cout << "Entrez les valeurs de votre tableau" << endl;

    for (i=0;i<taille;i++){
        for(j=0;j<taille;j++){
            // Aide � la saisie: on incr�mente les num�ros de ligne et colonne
            cout << "Ligne " << i + 1 << " Colonne " << j + 1 << endl;

            cin >> tableau[i][j];
            cin.ignore();
        }
    }

    cout << "Tableau original" << endl;

    for (i = 0; i < taille; i++){
        for (j = 0; j < taille; j++){
            cout << tableau[i][j] << " ";
        }
        cout << endl;
    }

    cout << "Tableau apres rotation de 90 degres" << endl;

    for (i = 0; i < taille ;i++){
        for (j = 0; j < taille ;j++){
            // On fait tourner le tableau de 90�
            // Source: http://stackoverflow.com/questions/42519/how-do-you-rotate-a-two-dimensional-array
            cout << tableau[taille - j - 1][i] << " ";
        }
        cout << endl;
    }

    // Suppression de tableau de la m�moire
    delete tableau;

    return 0;
}

