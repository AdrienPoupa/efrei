#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float tableauFilms[5], sommeNotes(0), moyenne;
    int i;

    // Saisie des notes sur 20
    for (i = 0; i < 5; i++) {
        cout << "Votre note au film " << i + 1 << " (sur 20):" << endl;
        cin >> tableauFilms[i];

        // Validation de la note: on sort du programme si la note est mauvaise
        if (tableauFilms[i] < 0 || tableauFilms[i] > 20) {
            cout << "Erreur: Veuillez rentrer une note entre 0 et 20" << endl;
            return 0;
        }

        // Ajout de la note � la somme de notes
        sommeNotes += tableauFilms[i];

        // Nettoyage du buffer
        cin.ignore();
    }

    // Calcul et affichage des notes sur 5 et 20
    moyenne = sommeNotes / 5;
    cout << "Moyenne des 5 films: " << setprecision(3) << moyenne << endl;

    return 0;
}
