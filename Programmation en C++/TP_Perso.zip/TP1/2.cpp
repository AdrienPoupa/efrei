#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

void afficherMenu() {
    cout << "Les operations suivantes sont possibles:" << endl;
    cout << "1. Addition " << endl;
    cout << "2. Soustraction " << endl;
    cout << "3. Multiplication " << endl;
    cout << "4. Division " << endl;
    cout << "5. Puissance " << endl;
    cout << "6. Quitter " << endl;
}

void saisieOperateur(int *operateur) {
    cin >> *operateur;
    cin.ignore();
}

void saisieOperandes(float *operande1, float *operande2) {
    cin >> *operande1;
    cin.ignore();
    cin >> *operande2;
    cin.ignore();
}

void addition(float *operande1, float *operande2) {
    cout << "Addition" << endl;
    saisieOperandes(operande1, operande2);
    cout << *operande1 << " + " << *operande2 << " = " << *operande1 + *operande2 << setprecision(5) << endl;
}

void soustraction(float *operande1, float *operande2) {
    cout << "Soustraction" << endl;
    saisieOperandes(operande1, operande2);
    cout << *operande1 << " - " << *operande2 << " = " << *operande1 - *operande2 << setprecision(5) << endl;
}

void multiplication(float *operande1, float *operande2) {
    cout << "Multiplication" << endl;
    saisieOperandes(operande1, operande2);
    cout << *operande1 << " * " << *operande2 << " = " << (*operande1) * (*operande2) << setprecision(5) << endl;
}

void division(float *operande1, float *operande2) {
    cout << "Division" << endl;
    saisieOperandes(operande1, operande2);

    // Pas de division par z�ro
    if (*operande2 != 0) {
        cout << *operande1 << " / " << *operande2 << " = " << *operande1 / *operande2 << setprecision(5) << endl;
    }
    else {
        cout << "Erreur: division par zero" << endl;
    }
}

void puissance(float *operande1, float *operande2) {
    cout << "Puissance" << endl;
    saisieOperandes(operande1, operande2);
    cout << *operande1 << " ^ " << *operande2 << " = " << pow(*operande1, *operande2) << setprecision(5) << endl;
}


int main()
{
    int *operateur(0);
    operateur = new int;

    float *operande1(0);
    operande1 = new float;

    float *operande2(0);
    operande2 = new float;

    cout << "Bienvenue dans la calculatrice." << endl;

    do {
        // Affichage du menu
        afficherMenu();

        // Saisie de l'op�rateur
        saisieOperateur(operateur);

        // On sort si n�cessaire
        if (*operateur == 6) {
            return 0;
        }

        // On s'assure que l'op�rateur est valide
        if (*operateur > 6 || *operateur < 1) {
            cout << "Votre selection est incorrecte" << endl;
        }
        else {
            // Switch case pour faire les op�rations
            switch (*operateur) {
                case 1:
                    addition(operande1, operande2);
                    break;
                case 2:
                    soustraction(operande1, operande2);
                    break;
                case 3:
                    multiplication(operande1, operande2);
                    break;
                case 4:
                    division(operande1, operande2);
                    break;
                case 5:
                    puissance(operande1, operande2);
                    break;
            }
        }
    } while (*operateur != 6);

    // On supprime la m�moire allou�e plus haut
    delete operateur;
    delete operande1;
    delete operande2;

    return 0;
}
