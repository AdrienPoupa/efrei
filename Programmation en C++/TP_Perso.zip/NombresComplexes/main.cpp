
#include <iostream>
#include <string>
#include <cmath>
#include "complexe.h"
#include "complexe.cpp"

using namespace std;

int main() {
    /*
        M�thodes 1 et 2:
        n1, n2 et resultat sont des complexes
    */
    //complexe n1, n2, resultat;

    // M�thode 1
    /*
    cout << "Pour le premier nombre complexe:" << endl;
    n1 = lectureSimple();

    cout << "Pour le second nombre complexe:" << endl;
    n2 = lectureSimple();
    */

    // M�thode 2
    /*
    cout << "Pour le premier nombre complexe:" << endl;
    lecture1(n1);

    cout << "Pour le second nombre complexe:" << endl;
    lecture1(n2);
    */

    // M�thodes 1 et 2 sans pointeurs:
    /*
    resultat = sommeSimple(n1,n2);
    cout << "Somme: " << resultat.reel << " + " << resultat.im << "i";
    */

    /*
        M�thode 3
        On initialise d�sormais des pointeurs
    */
    complexe *n1(0);
    n1 = new complexe;

    complexe *n2(0);
    n2 = new complexe;

    complexe *resultat(0);
    resultat = new complexe;

    cout << "Pour le premier nombre complexe:" << endl;
    lecture2(n1);

    cout << "Pour le second nombre complexe:" << endl;
    lecture2(n2);

    sommePointeurs(n1, n2, resultat);

    cout << "Somme: " << resultat->reel << " + " << resultat->im << "i" << endl;

    soustractionPointeurs(n1, n2, resultat);

    cout << "Soustraction: " << resultat->reel << " + " << resultat->im << "i" << endl;

    divisionPointeurs(n1, n2, resultat);

    cout << "Division: " << resultat->reel << " + " << resultat->im << "i" << endl;

    argumentPointeurs(n1, resultat);

    cout << "Argument du premier complexe: " << resultat->reel << " rd" << endl;

    argumentPointeurs(n2, resultat);

    cout << "Argument du second complexe: " << resultat->reel << " rd" << endl;

    modulePointeurs(n1, resultat);

    cout << "Module du premier complexe: " << resultat->reel << endl;

    modulePointeurs(n2, resultat);

    cout << "Module du second complexe: " << resultat->reel << endl;

    secondDegre();

    delete n1;
    delete n2;
    delete resultat;

    return 0;
}
