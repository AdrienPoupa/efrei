typedef struct complexe{
    double reel;
    double im;
} complexe;

complexe somme(complexe n1, complexe n2);
void sommePointeurs(complexe *n1, complexe *n2, complexe *resultat);
void soustractionPointeurs(complexe *n1, complexe *n2, complexe *resultat);
void divisionPointeurs(complexe *n1, complexe *n2, complexe *resultat);
void argumentPointeurs(complexe *n1, complexe *resultat);
void modulePointeurs(complexe *n1, complexe *resultat);
complexe lectureSimple();
void lecture1(complexe &retour);
void lecture2(complexe *retour);
void secondDegre();
