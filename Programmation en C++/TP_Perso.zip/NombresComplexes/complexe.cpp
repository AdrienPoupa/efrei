#include <iostream>
#include <string>
#include <cmath>

using namespace std;

complexe lectureSimple() {
    complexe retour;

    cout << "Entrez le reel puis l'imaginaire:" << endl;
    cin >> retour.reel >> retour.im;
    cin.ignore();

    return retour;
}

void lecture1(complexe& retour) {
    cout << "Entrez le reel puis l'imaginaire:" << endl;
    cin >> retour.reel >> retour.im;
    cin.ignore();
}

void lecture2(complexe *retour) {
    cout << "Entrez le reel puis l'imaginaire:" << endl;
    cin >> retour->reel >> retour->im;
    cin.ignore();
}

complexe somme(complexe n1, complexe n2) {
    complexe resultat;

    resultat.reel = n1.reel + n2.reel;
    resultat.im = n1.im + n2.im;

    return resultat;
}

void sommePointeurs(complexe *n1, complexe *n2, complexe *resultat) {

    resultat->reel = n1->reel + n2->reel;
    resultat->im = n1->im + n2->im;
}

void soustractionPointeurs(complexe *n1, complexe *n2, complexe *resultat) {

    resultat->reel = n1->reel - n2->reel;
    resultat->im = n1->im - n2->im;
}

void divisionPointeurs(complexe *n1, complexe *n2, complexe *resultat) {

    resultat->reel = ((n1->reel * n2->reel) + (n1->im * n2->im)) / ((n2->reel * n2->reel) + (n2->im * n2->im));
    resultat->im = ((n1->im * n2->reel) - (n2->im * n1->reel)) / ((n1->im * n1->im) + (n2->im * n2->im));
}

void argumentPointeurs(complexe *n1, complexe *resultat) {

    resultat->reel = atan(n1->im / n1->reel);
}

void modulePointeurs(complexe *n1, complexe *resultat) {

    resultat->reel = sqrt((n1->reel * n1->reel) + (n1->im * n1->im));
}

void secondDegre() {
    float a, b, c, x1, x2, delta, reel, im;

    cout << "Entrez les coefficients a, b et c: ";
    cin >> a >> b >> c;
    delta = b*b - 4*a*c;

    if (delta > 0) {
        x1 = (-b + sqrt(delta)) / (2*a);
        x2 = (-b - sqrt(delta)) / (2*a);
        cout << "Les racines sont reelles et distinctes." << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    }
    else if (delta == 0) {
        cout << "Les racines sont egales et reelles." << endl;
        x1 = (-b + sqrt(delta)) / (2*a);
        cout << "x1 = x2 =" << x1 << endl;
    }
    else {
        reel = -b / (2*a);
        im = sqrt(-delta) / (2*a);
        cout << "Les racines sont complexes et differentes."  << endl;
        cout << "x1 = " << reel << " + " << im << " i" << endl;
        cout << "x2 = " << reel << " - " << im << " i" << endl;
    }
}
