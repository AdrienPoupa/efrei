#include "Cercle.h"

#include <iostream>

using namespace std;

int Cercle::compteur = 0;

Cercle::Cercle()
{
    // Si on veut avoir un _nombrePoints de type int et non string, on ne peut pas stocker "une infinit�" en toutes lettres
    _nombrePoints = 999999;

    _centre.setX(0);
    _centre.setY(0);

    _rayon = 0;

    ++compteur;
}

Cercle::Cercle(Point centre, int rayon)
{
    // Si on veut avoir un _nombrePoints de type int et non string, on ne peut pas stocker "une infinit�" en toutes lettres
    _nombrePoints = 999999;

    _centre = centre;
    _rayon = rayon;

    ++compteur;
}

Cercle::~Cercle()
{
    --compteur;
}

void Cercle::zoomer()
{
    // Zoom du Cercle: on applique abitrairement un facteur 2 au rayon

    _rayon *= 2;
}

void Cercle::translation()
{
    // Translation du Cercle: on applique abitrairement un +2 au centre

    _centre.setX(_centre.getX()+2);
    _centre.setY(_centre.getY()+2);
}

void Cercle::rotation()
{
    // Rotation du Cercle: on ne fait rien
}

void Cercle::afficher()
{
    cout << "Centre: x=" << _centre.getX() << " y=" << _centre.getY() << endl;
    cout << "Rayon: " << _rayon << endl;
}

int Cercle::nombreInstances()
{
    return compteur;
}
