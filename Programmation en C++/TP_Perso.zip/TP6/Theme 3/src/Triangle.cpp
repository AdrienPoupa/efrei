#include "Triangle.h"

#include <iostream>

using namespace std;

int Triangle::compteur = 0;

Triangle::Triangle()
{
    _nombrePoints = 3;

    _a.setX(0);
    _a.setY(0);

    _b.setX(0);
    _b.setY(0);

    _c.setX(0);
    _c.setY(0);

    ++compteur;
}

Triangle::Triangle(Point a, Point b, Point c)
{
    _nombrePoints = 3;

    _a = a;
    _b = b;
    _c = c;

    ++compteur;
}

Triangle::~Triangle()
{
    --compteur;
}

void Triangle::zoomer()
{
    // Zoom du triangle: on applique abitrairement un facteur 2 aux points, on retourne un nouveau triangle

    _a.setX(_a.getX()*2);
    _a.setY(_a.getY()*2);

    _b.setX(_b.getX()*2);
    _b.setY(_b.getY()*2);

    _c.setX(_c.getX()*2);
    _c.setY(_c.getY()*2);
}

void Triangle::translation()
{
    // Translation du triangle: on applique abitrairement un +2 aux points, on retourne un nouveau triangle

    _a.setX(_a.getX()+2);
    _a.setY(_a.getY()+2);

    _b.setX(_b.getX()+2);
    _b.setY(_b.getY()+2);

    _c.setX(_c.getX()+2);
    _c.setY(_c.getY()+2);
}

void Triangle::rotation()
{
    // Rotation du triangle

    Point a_tmp = _a;
    Point b_tmp = _b;
    Point c_tmp = _c;

    _a = c_tmp;
    _b = a_tmp;
    _c = b_tmp;
}

void Triangle::afficher()
{
    cout << "A: x=" << _a.getX() << " y=" << _a.getY() << endl;
    cout << "B: x=" << _b.getX() << " y=" << _b.getY() << endl;
    cout << "C: x=" << _c.getX() << " y=" << _c.getY() << endl;
}

int Triangle::nombreInstances()
{
    return compteur;
}
