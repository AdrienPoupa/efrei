#include "Ellipse.h"

#include <iostream>

using namespace std;

int Ellipse::compteur = 0;

Ellipse::Ellipse()
{
    // Si on veut avoir un _nombrePoints de type int et non string, on ne peut pas stocker "une infinit�" en toutes lettres
    _nombrePoints = 999999;

    _centre.setX(0);
    _centre.setY(0);

    _demiGrandAxe = 0;
    _demiPetitAxe = 0;

    ++compteur;
}

Ellipse::Ellipse(Point centre, int demiGrandAxe, int demiPetitAxe)
{
    // Si on veut avoir un _nombrePoints de type int et non string, on ne peut pas stocker "une infinit�" en toutes lettres
    _nombrePoints = 999999;

    _centre = centre;
    _demiGrandAxe = demiGrandAxe;
    _demiPetitAxe = demiPetitAxe;

    ++compteur;
}

Ellipse::~Ellipse()
{
    --compteur;
}

void Ellipse::zoomer()
{
    // Zoom du Ellipse: on applique abitrairement un facteur 2 au rayon

    _demiGrandAxe *= 2;
    _demiPetitAxe *= 2;
}

void Ellipse::translation()
{
    // Translation du Ellipse: on applique abitrairement un +2 au centre

    _centre.setX(_centre.getX()+2);
    _centre.setY(_centre.getY()+2);
}

void Ellipse::rotation()
{
    // Rotation du Ellipse: on ne fait rien
}

void Ellipse::afficher()
{
    cout << "Centre: x=" << _centre.getX() << " y=" << _centre.getY() << endl;
    cout << "Demi grand-axe: " << _demiGrandAxe << endl;
    cout << "Demi petit-axe: " << _demiPetitAxe << endl;
}

int Ellipse::nombreInstances()
{
    return compteur;
}
