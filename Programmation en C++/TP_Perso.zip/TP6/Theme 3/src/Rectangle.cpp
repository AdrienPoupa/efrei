#include "Rectangle.h"

#include <iostream>

using namespace std;

int Rectangle::compteur = 0;

Rectangle::Rectangle()
{
    _nombrePoints = 4;

    _a.setX(0);
    _a.setY(0);

    _b.setX(0);
    _b.setY(0);

    _c.setX(0);
    _c.setY(0);

    _d.setX(0);
    _d.setY(0);

    ++compteur;
}

Rectangle::Rectangle(Point a, Point b, Point c, Point d)
{
    _nombrePoints = 4;

    _a = a;
    _b = b;
    _c = c;
    _d = d;

    ++compteur;
}

Rectangle::~Rectangle()
{
    --compteur;
}

void Rectangle::zoomer()
{
    // Zoom du Rectangle: on applique abitrairement un facteur 2 aux points, on retourne un nouveau Rectangle

    _a.setX(_a.getX()*2);
    _a.setY(_a.getY()*2);

    _b.setX(_b.getX()*2);
    _b.setY(_b.getY()*2);

    _c.setX(_c.getX()*2);
    _c.setY(_c.getY()*2);

    _d.setX(_d.getX()*2);
    _d.setY(_d.getY()*2);
}

void Rectangle::translation()
{
    // Translation du Rectangle: on applique abitrairement un +2 aux points, on retourne un nouveau Rectangle

    _a.setX(_a.getX()+2);
    _a.setY(_a.getY()+2);

    _b.setX(_b.getX()+2);
    _b.setY(_b.getY()+2);

    _c.setX(_c.getX()+2);
    _c.setY(_c.getY()+2);

    _d.setX(_d.getX()+2);
    _d.setY(_d.getY()+2);
}

void Rectangle::rotation()
{
    // Rotation du Rectangle

    Point a_tmp = _a;
    Point b_tmp = _b;
    Point c_tmp = _c;
    Point d_tmp = _d;

    _a = b_tmp;
    _b = c_tmp;
    _c = d_tmp;
    _d = a_tmp;
}

void Rectangle::afficher()
{
    cout << "A: x=" << _a.getX() << " y=" << _a.getY() << endl;
    cout << "B: x=" << _b.getX() << " y=" << _b.getY() << endl;
    cout << "C: x=" << _c.getX() << " y=" << _c.getY() << endl;
    cout << "D: x=" << _d.getX() << " y=" << _d.getY() << endl;
}

int Rectangle::nombreInstances()
{
    return compteur;
}
