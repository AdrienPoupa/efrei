#include "Polygone.h"

int Polygone::compteur = 0;

Polygone::Polygone()
{
    ++compteur;
}

Polygone::~Polygone()
{
    --compteur;
}

void Polygone::afficher()
{

}

void Polygone::zoomer()
{

}

void Polygone::translation()
{

}

void Polygone::rotation()
{

}

int Polygone::nombreInstances()
{
    return compteur;
}
