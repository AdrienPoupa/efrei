#include "Point.h"

int Point::compteur = 0;

Point::Point()
{
    _x = 0;
    _y = 0;

    ++compteur;
}

Point::Point(int x, int y)
{
    _x = x;
    _y = y;

    ++compteur;
}

Point::~Point()
{

}

int Point::getX()
{
    return _x;
}

int Point::getY()
{
    return _y;
}

void Point::setX(int x)
{
    _x = x;
}

void Point::setY(int y)
{
    _y = y;
}

int Point::nombreInstances()
{
    return compteur;
}
