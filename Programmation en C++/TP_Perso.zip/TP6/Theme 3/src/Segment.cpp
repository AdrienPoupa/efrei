#include "Segment.h"

Segment::Segment()
{
    _debut = Point();
    _fin = Point();
}

Segment::Segment(Point debut, Point fin)
{
    _debut = debut;
    _fin = fin;
}

Segment::~Segment()
{
    //dtor
}

void Segment::setDebut(Point debut)
{
    _debut = debut;
}

void Segment::setFin(Point fin)
{
    _fin = fin;
}

Point Segment::getDebut()
{
    return _debut;
}

Point Segment::getFin()
{
    return _fin;
}
