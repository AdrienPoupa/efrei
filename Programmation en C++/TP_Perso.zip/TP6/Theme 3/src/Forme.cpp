#include "Forme.h"

int Forme::compteur = 0;

Forme::Forme()
{
    ++compteur;
}

Forme::~Forme()
{
    --compteur;
}

void Forme::afficher()
{

}

void Forme::zoomer()
{

}

void Forme::translation()
{

}

void Forme::rotation()
{

}

int Forme::getNombrePoints()
{
    return _nombrePoints;
}

int Forme::nombreInstances()
{
    return compteur;
}
