#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "Polygone.h"

class Rectangle : public Polygone
{
    public:
        Rectangle();
        Rectangle(Point a, Point b, Point c, Point d);
        virtual ~Rectangle();
        void afficher();
        void zoomer();
        void rotation();
        void translation();
        static int nombreInstances();
    protected:
        Point _a, _b, _c, _d;
    private:
        static int compteur;
};

#endif // RECTANGLE_H
