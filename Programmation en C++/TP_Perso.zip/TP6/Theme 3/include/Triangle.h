#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Polygone.h"
#include "Point.h"

class Triangle : public Polygone
{
    public:
        Triangle();
        Triangle(Point a, Point b, Point c);
        virtual ~Triangle();
        void afficher();
        void zoomer();
        void rotation();
        void translation();
        static int nombreInstances();
    protected:
        Point _a, _b, _c;
    private:
        static int compteur;
};

#endif // TRIANGLE_H
