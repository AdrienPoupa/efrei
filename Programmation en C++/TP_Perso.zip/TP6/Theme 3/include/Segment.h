#ifndef SEGMENT_H
#define SEGMENT_H

#include "Point.h"

class Segment
{
    public:
        Segment();
        Segment(Point debut, Point fin);
        virtual ~Segment();
        void setDebut(Point debut);
        void setFin(Point fin);
        Point getDebut();
        Point getFin();
    protected:
        Point _debut, _fin;
    private:
};

#endif // SEGMENT_H
