#ifndef POLYGONE_H
#define POLYGONE_H

#include "Forme.h"

class Polygone : public Forme
{
    public:
        Polygone();
        virtual ~Polygone();
        virtual void afficher();
        virtual void zoomer();
        virtual void rotation();
        virtual void translation();
        static int nombreInstances();
    protected:
    private:
        static int compteur;
};

#endif // POLYGONE_H
