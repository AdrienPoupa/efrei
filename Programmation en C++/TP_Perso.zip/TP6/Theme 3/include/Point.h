#ifndef POINT_H
#define POINT_H


class Point
{
    public:
        Point();
        Point(int x, int y);
        int getX();
        void setX(int x);
        int getY();
        void setY(int y);
        virtual ~Point();
        static int nombreInstances();
    protected:
        int _x, _y;
    private:
        static int compteur;
};

#endif // POINT_H
