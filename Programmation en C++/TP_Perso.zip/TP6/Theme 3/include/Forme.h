#ifndef FORME_H
#define FORME_H

#include "Point.h"

class Forme
{
    public:
        Forme();
        virtual ~Forme();
        virtual void afficher();
        virtual void zoomer();
        virtual void rotation();
        virtual void translation();
        int getNombrePoints();
        static int nombreInstances();
    protected:
        int _nombrePoints, _nombreSegments;
        Point _centre;
    private:
        static int compteur;
};

#endif // FORME_H
