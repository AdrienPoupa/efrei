#ifndef CERCLE_H
#define CERCLE_H

#include "Forme.h"
#include "Point.h"

class Cercle : public Forme
{
    public:
        Cercle();
        Cercle(Point centre, int rayon);
        virtual ~Cercle();
        void afficher();
        void zoomer();
        void rotation();
        void translation();
        static int nombreInstances();
    protected:
        Point _centre;
        int _rayon;
    private:
        static int compteur;
};

#endif // CERCLE_H
