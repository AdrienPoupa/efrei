#ifndef ELLIPSE_H
#define ELLIPSE_H

#include "Forme.h"
#include "Point.h"

class Ellipse : public Forme
{
    public:
        Ellipse();
        Ellipse(Point centre, int demiGrandAxe, int demiPetitAxe);
        virtual ~Ellipse();
        void afficher();
        void zoomer();
        void rotation();
        void translation();
        static int nombreInstances();
    protected:
        Point _centre;
        int _demiGrandAxe, _demiPetitAxe;
    private:
        static int compteur;
};

#endif // ELLIPSE_H
