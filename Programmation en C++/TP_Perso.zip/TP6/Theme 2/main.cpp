#include <iostream>

#include "Etudiant.h"

using namespace std;

int main()
{
    Etudiant e("Gilbert");
    cout << e.getNom() << endl; // Sans h�ritage, affiche: "Classe etudiant: Gilbert" et non "Classe personne: Gilbert"
    // Impossible de faire appel � une m�thode de Personne depuis un objet Etudiant sans h�ritage

    Etudiant e2(e); // Copie de Gilbert dans e2: le constructeur de copie est h�rit� dans Etudiant
    cout << e2.getNom() << endl;

    Etudiant e3;
    e3 = e2; // Surcharge du =, h�rit� dans Etudiant
    cout << e3.getNom() << endl;

    Etudiant e4;
    e4.setAge(25); // Age de base = 25 ans
    e4 = e4 + 2; // On ajoute 2 ans
    // !! Plante si + est d�fini dans Personne seulement : pas d'h�ritage de fonction amie !!
    cout << e4.getAge() << " ans" << endl; // Affiche 27 ans!

    return 0;
}
