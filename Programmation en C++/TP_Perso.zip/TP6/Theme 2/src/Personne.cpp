#include "Personne.h"

Personne::Personne(const char *nom)
{
    _nom = nom;
}

Personne::Personne()
{
    _nom = "Sans nom";
    _age = 0;
}

Personne::Personne(const Personne &p)
{
    std::cout << "Constructeur de copie de Personne herite par Etudiant" << std::endl;
    _nom = p._nom;
    _age = p._age;
}

Personne::~Personne()
{
    //dtor
}

char *Personne::getNom()
{
    std::cout << "Classe personne: ";
    // _nom est un Nstring; pour l'affichage on se sert de la m�thode d�di�e de la classe Nstring
    return _nom.getTexte();
}

void Personne::setNom(const Nstring &nom)
{
    _nom = nom;
}

int Personne::getAge()
{
    return _age;
}

void Personne::setAge(int age)
{
    _age = age;
}

Personne& Personne::operator= (const Personne& p) {
    std::cout << "Surcharge de = dans Personne herite par Etudiant" << std::endl;
    if (&p != this) {
        _nom = p._nom;
        _age = p._age;
    }
    return *this;
}

Personne operator+(Personne p, int ajout) {
    Personne resultat;

    resultat._age = p._age + ajout;

    return resultat;
}
