#include "Etudiant.h"

Etudiant::Etudiant(const char *nom)
{
    _nom = nom;
}

Etudiant::~Etudiant()
{
    _nom = "Sans nom";
    _age = 0;
}

Etudiant::Etudiant()
{
    //dtor
}

char *Etudiant::getNom()
{
    std::cout << "Classe etudiant: ";
    // _nom est un Nstring; pour l'affichage on se sert de la m�thode d�di�e de la classe Nstring
    return _nom.getTexte();
}

void Etudiant::setNom(const Nstring &nom)
{
    _nom = nom;
}

int Etudiant::getAge()
{
    return _age;
}

void Etudiant::setAge(int age)
{
    _age = age;
}

Etudiant operator+(Etudiant p, int ajout) {
    Etudiant resultat;

    resultat._age = p._age + ajout;

    return resultat;
}
