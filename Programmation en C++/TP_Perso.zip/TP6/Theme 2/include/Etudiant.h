#ifndef ETUDIANT_H
#define ETUDIANT_H

#include "Nstring.h"
#include "Personne.h"

class Etudiant : public Personne
{
    public:
        Etudiant(const char *chaine);
        Etudiant();
        void setNom(const Nstring &nom);
        virtual ~Etudiant();
        char * getNom();
        int getAge();
        void setAge(int age);
        friend Etudiant operator+(Etudiant e1, int ajout);
    protected:
        Nstring _nom;
        int _age;
    private:
};

#endif // ETUDIANT_H
