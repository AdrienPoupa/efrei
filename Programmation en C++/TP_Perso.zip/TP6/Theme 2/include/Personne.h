#ifndef PERSONNE_H
#define PERSONNE_H

#include "Nstring.h"

class Personne
{
    public:
        Personne(const char *nom);
        Personne(const Personne &p);
        Personne();
        Personne& operator= (const Personne& p);
        void setNom(const Nstring &nom);
        virtual ~Personne();
        char *getNom();
        int getAge();
        void setAge(int age);
        friend Personne operator+(Personne p1, int ajout);
    protected:
        Nstring _nom;
        int _age;
    private:
};

#endif // PERSONNE_H
