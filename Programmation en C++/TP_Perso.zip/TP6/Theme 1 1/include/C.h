#ifndef C_H
#define C_H

#include "A.h"
#include "B.h"


class C : public B // H�ritage de B
{
    public:
        C();
        virtual ~C();
    protected:
    private:
        A instanceDeA; // Instanciation d'un objet de A
};

#endif // C_H
