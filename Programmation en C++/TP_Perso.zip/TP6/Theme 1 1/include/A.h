#ifndef A_H
#define A_H


class A
{
    public:
        A();
        virtual ~A();
    protected:
    private:
};

#endif // A_H
