#ifndef B_H
#define B_H


class B
{
    public:
        B();
        virtual ~B();
    protected:
    private:
};

#endif // B_H
