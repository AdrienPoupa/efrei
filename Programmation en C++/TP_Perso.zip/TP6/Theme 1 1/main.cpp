#include <iostream>
#include "C.h"

using namespace std;

int main()
{
    C instanceDeC; // Cr�ation de l'instance de C

    /*
        Dans l'ordre:
            Constructeur de B - h�ritage
            Constructeur de A - attribut
            Constructeur de C - instance cr��e
            Destructeur de C - instance cr��e
            Destructeur de A - attribut
            Destructeur de B - h�ritage
    */

    return 0;
}
