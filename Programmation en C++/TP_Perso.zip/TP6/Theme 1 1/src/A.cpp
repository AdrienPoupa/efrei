#include "A.h"

#include <iostream>

using namespace std;

A::A()
{
    cout << "Constructeur de A" << endl;
}

A::~A()
{
    cout << "Destructeur de A" << endl;
}
