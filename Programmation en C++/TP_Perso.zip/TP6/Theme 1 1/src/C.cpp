#include "C.h"

#include <iostream>

using namespace std;

C::C()
{
    cout << "Constructeur de C" << endl;
}

C::~C()
{
    cout << "Destructeur de C" << endl;
}
