#include "B.h"

#include <iostream>

using namespace std;

B::B()
{
    cout << "Constructeur de B" << endl;
}

B::~B()
{
    cout << "Destructeur de B" << endl;
}
