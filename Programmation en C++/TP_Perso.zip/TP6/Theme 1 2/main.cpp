#include <iostream>

#include "Voiture.h"
#include "Velo.h"

using namespace std;

/*
    H�ritages:
        Voiture est un V�hiculeRoulant
        V�lo est un V�hiculeRoulant

    Compositions:
        V�hiculeRoulant a une roue
        V�hiculeRoulant a un moteur
        V�hiculeRoulant a un volant
*/

int main()
{
    Voiture maVoiture;
    Velo monVelo;

    maVoiture.setMarque("Ferrari");
    maVoiture.afficher(); // Affiche "Je suis une voiture"

    cout << endl;

    monVelo.setMarque("Giant");
    monVelo.afficher(); // Affiche "Je suis un v�lo"

    return 0;
}
