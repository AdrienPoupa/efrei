#ifndef VOLANT_H
#define VOLANT_H

#include <string>

using namespace std;

class Volant
{
    public:
        Volant();
        virtual ~Volant();
        void setVolant(string type);
        string getVolant() const;
    protected:
        string _type;
    private:
};

#endif // VOLANT_H
