#ifndef ROUE_H
#define ROUE_H


class Roue
{
    public:
        Roue(int nombreRoues);
        virtual ~Roue();
        void afficherNombreRoues() const;
    protected:
        int _nombreRoues;
    private:
};

#endif // ROUE_H
