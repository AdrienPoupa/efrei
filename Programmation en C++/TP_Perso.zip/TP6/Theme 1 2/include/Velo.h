#ifndef VELO_H
#define VELO_H

#include "VehiculeRoulant.h"
#include "Roue.h"
#include "Moteur.h"
#include "Volant.h"

class Velo : public VehiculeRoulant
{
    public:
        Velo();
        virtual ~Velo();
        void afficher() const;
    protected:
        Roue rouesVelo;
        Moteur moteurVelo;
        Volant volantVelo;
    private:
};

#endif // VELO_H
