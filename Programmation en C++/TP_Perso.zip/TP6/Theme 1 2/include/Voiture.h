#ifndef VOITURE_H
#define VOITURE_H

#include "VehiculeRoulant.h"
#include "Roue.h"
#include "Moteur.h"
#include "Volant.h"

class Voiture : public VehiculeRoulant
{
    public:
        Voiture();
        virtual ~Voiture();
        void afficher() const;
    protected:
        Roue rouesVoiture;
        Moteur moteurVoiture;
        Volant volantVoiture;
    private:
};

#endif // VOITURE_H
