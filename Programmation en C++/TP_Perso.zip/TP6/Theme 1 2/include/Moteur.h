#ifndef MOTEUR_H
#define MOTEUR_H


class Moteur
{
    public:
        Moteur(bool aUnMoteur, int chevaux = 0);
        virtual ~Moteur();
        bool aUnMoteur() const;
        int getChevaux() const;
    protected:
        bool _aUnMoteur;
        int _chevaux;
    private:
};

#endif // MOTEUR_H
