#ifndef VEHICULEROULANT_H
#define VEHICULEROULANT_H

#include <string>

using namespace std;

class VehiculeRoulant
{
    public:
        VehiculeRoulant();
        virtual ~VehiculeRoulant();
        void afficherMarque() const; // Cette fonction sera appel�e depuis les classes filles
        void affichageMoteur(bool aUnMoteur, int chevaux = 0) const; // Cette fonction sera appel�e depuis les classes filles
        void setMarque(string marque);
        string getMarque() const;
    protected:
        string _marque;
    private:
};

#endif // VEHICULEROULANT_H
