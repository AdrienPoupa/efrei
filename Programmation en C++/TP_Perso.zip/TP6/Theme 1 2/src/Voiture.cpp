#include "Voiture.h"

#include <iostream>

using namespace std;


Voiture::Voiture() : rouesVoiture(4), moteurVoiture(true, 110)
{
    volantVoiture.setVolant("volant");
}

Voiture::~Voiture()
{
    //dtor
}

void Voiture::afficher() const
{
    cout << "Je suis une voiture" << endl;
    VehiculeRoulant::afficherMarque();  // Affichage de la marque depuis la classe m�re
    rouesVoiture.afficherNombreRoues(); // Affichage du nombre de roues depuis la classe Roue
    affichageMoteur(moteurVoiture.aUnMoteur(), moteurVoiture.getChevaux());
    cout << "J'ai un " << volantVoiture.getVolant() << endl;
}
