#include "VehiculeRoulant.h"

#include <iostream>

using namespace std;

VehiculeRoulant::VehiculeRoulant()
{

}

VehiculeRoulant::~VehiculeRoulant()
{
    //dtor
}

void VehiculeRoulant::affichageMoteur(bool aUnMoteur, int chevaux) const
{
    if (aUnMoteur == true)
    {
        cout << "J'ai un moteur de " << chevaux << " chevaux" << endl;
    }
    else
    {
        cout << "Je suis ecolo, je ne pollue pas car je n'ai pas de moteur!" << endl;
    }
}

void VehiculeRoulant::setMarque(string marque)
{
    _marque = marque;
}

string VehiculeRoulant::getMarque() const
{
    return _marque;
}

void VehiculeRoulant::afficherMarque() const
{
    cout << "Je suis de marque " << _marque << endl;
}
