#include "Velo.h"

#include <iostream>

using namespace std;

Velo::Velo() : rouesVelo(2), moteurVelo(false)
{
    volantVelo.setVolant("guidon");
}

Velo::~Velo()
{
    //dtor
}

void Velo::afficher() const
{
    cout << "Je suis un velo" << endl;
    VehiculeRoulant::afficherMarque(); // Affichage de la marque depuis la classe m�re
    rouesVelo.afficherNombreRoues(); // Affichage du nombre de roues depuis la classe Roue
    cout << "J'ai un " << volantVelo.getVolant() << endl;
}
