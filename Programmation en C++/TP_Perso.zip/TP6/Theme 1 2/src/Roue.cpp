#include "Roue.h"

#include <iostream>

using namespace std;

Roue::Roue(int nombreRoues)
{
    _nombreRoues = nombreRoues;
}

Roue::~Roue()
{
    //dtor
}

void Roue::afficherNombreRoues() const
{
    cout << "J'ai " << _nombreRoues << " roues" << endl;
}
