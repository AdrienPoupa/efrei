#include "Volant.h"

Volant::Volant()
{
    //ctor
}

Volant::~Volant()
{
    //dtor
}

void Volant::setVolant(string type)
{
    _type = type;
}

string Volant::getVolant() const
{
    return _type;
}
