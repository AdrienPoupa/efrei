#include "Moteur.h"

Moteur::Moteur(bool aUnMoteur, int chevaux)
{
    _aUnMoteur = aUnMoteur;
    _chevaux = chevaux;
}

Moteur::~Moteur()
{
    //dtor
}

bool Moteur::aUnMoteur() const
{
    return _aUnMoteur;
}

int Moteur::getChevaux() const
{
    return _chevaux;
}
