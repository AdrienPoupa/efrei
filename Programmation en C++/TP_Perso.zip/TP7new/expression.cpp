#include <iostream>
#include <sstream>
#include <string>
#include <math.h>
#include <map>
#include <set>

using namespace std;

#include "expression.h"

set<Expression*> Expression::_pool = :set<Expression*>();
