#ifndef CONDITIONNEL_H_INCLUDED
#define CONDITIONNEL_H_INCLUDED

#include "variable.h"

class Conditionnel : public Expression {
    Binaire *_cond;
    Expression *_op1, *_op2;
    public:
        //Conditionnel(Binaire* cond, Expression* op1, Expression* op2) : Expression(cond->str()), _cond(cond), _op1(op1), _op2(op2) {}
        Conditionnel(Binaire* cond, Expression* op1, Expression* op2) : Expression("?"), _cond(cond), _op1(op1), _op2(op2) {}
        //double eval() const { return ((_cond->eval()) ? _op1->eval() : _op2->eval()); }
        double eval() const { return (((bool)_cond->eval()) ? _op1->eval() : _op2->eval()); }
};

#endif
