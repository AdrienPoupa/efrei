#include <iostream>

using namespace std;

class Arme {
    const string _nom = "AK47";

    public:
        string getName() {
            return _nom;
        }
};

class Personnage {
    string _name = "test";
    int pdv;

/*  Arme *monArme;
    monArme = new Arme;*/

    Arme *monArme = new Arme;

    public:

        void test();
        Personnage setName(const string name);
        void getName();

        void setPdv(const int pdvToSet) {
            // On met les points de vie
            pdv = pdvToSet;
        }

        int getPdv() {
            // On recupere les points de vie
            return pdv;
        }

    private:
        void privateFunction() {
            cout << "Je suis une fonction privee et je ne peux etre appelee que depuis la classe" << endl;
        }
};

void Personnage::test() {
            cout << "C'est un test" << endl;
            this->privateFunction();
            string testArme = monArme->getName();
            cout << testArme << endl;
}

Personnage Personnage::setName(string name) {
            _name = name;
            return *this;
}

void Personnage::getName() {
            cout << "Nom : " << _name << endl;
}

int main()
{
    Personnage *jack = new Personnage;
    jack->test();
    jack->setPdv(55);
    //jack->setName("jack")->getName();
    jack->setName("jack");
    jack->getName();
    int pdv = jack->getPdv();
    //jack.privateFunction();
    cout << "Points de vie: " << pdv << endl;

    Personnage *joe = new Personnage;
    joe->setName("joe");
    joe->getName();

    delete jack;
    delete joe;

    return 0;
}
