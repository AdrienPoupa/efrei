#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <iostream>
#include "Nstring.h"
#include "List.h"

const int TAILLE = 12;

class Hashtable
{
    List *liste;
    public:
        Hashtable();
        Hashtable(Nstring);
        ~Hashtable();
        int hashCode(Nstring key);
        void put();
        void put(Nstring key, Nstring value);
        Cell* get(Nstring key);
        friend std::ostream& operator<<(std::ostream &, const Hashtable &);
};

#endif // HASHTABLE_H
