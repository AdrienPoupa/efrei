#include "Hashtable.h"
#include <stdio.h>
#include <string.h>

Hashtable::Hashtable()
{
    liste = new List[TAILLE];
}

Hashtable::Hashtable(Nstring s) // TODO
{
    liste = new List[TAILLE];
}

void Hashtable::put(Nstring key, Nstring value)
{
    int hash = hashCode(key);
    liste[hash] = Cell(key, value);
}

void Hashtable::put()
{

}

Cell* Hashtable::get(Nstring key)
{
    int hash = hashCode(key);
    return liste[hash].get(key);
}

Hashtable::~Hashtable()
{
    delete [] liste;
}

int Hashtable::hashCode(Nstring key)
{
    int value = 0;
    char *_key = key.getTexte();
    int keyl = strlen(_key);
    for (int i = 0; i < keyl; i++) {
        value += _key[i];
    }
    return (value * keyl) % TAILLE;
}

std::ostream& operator<<(std::ostream &out, const Hashtable &h)
{
    return out;
}
