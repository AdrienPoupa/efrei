#include <iostream>
#include <cmath>
#include "Complex.h"

using namespace std;

int main()
{
    Complex c1(3, 4);
    c1.afficher();

    Complex c2(4, 5);
    c2.afficher();

    return 0;
}
