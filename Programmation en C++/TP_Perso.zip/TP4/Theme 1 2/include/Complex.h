#ifndef COMPLEX_H
#define COMPLEX_H


class Complex {
    double _reel, _im;

    public:
        Complex(double reel = 0, double im = 0);
        ~Complex();
        void afficher();
        double getReel();
        void setReel(double reel);
        double getIm();
        void setIm(double im);
};

#endif // COMPLEX_H
