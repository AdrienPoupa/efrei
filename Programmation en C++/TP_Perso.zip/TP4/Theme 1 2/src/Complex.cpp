#include "Complex.h"
#include <iostream>

using namespace std;

Complex::Complex(double reel, double im) {
    cout << "Entree dans le constructeur" << endl;
    _reel = reel;
    _im = im;
}

Complex::~Complex() {
    cout << "Entree dans le destructeur" << endl;
}

double Complex::getReel() {
    return _reel;
}

void Complex::setReel(double reel) {
    _reel = reel;
}

void Complex::setIm(double im) {
    _im = im;
}

double Complex::getIm() {
    return _im;
}

void Complex::afficher() {
    cout << "Complex: " << getReel() << " + " << getIm() << " i" << endl;
}
