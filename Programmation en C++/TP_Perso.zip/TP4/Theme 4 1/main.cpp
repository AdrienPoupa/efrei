#include <iostream>
#include "Complex.h"

using namespace std;

int main()
{
    Complex c1;
    cin >> c1;
    cout << c1;

    Complex c2;
    cin >> c2;
    cout << c2;

    Complex resultat;

    cout << "Addition du premier et second complexe" << endl;
    resultat = c1 + c2;
    cout << resultat;

    cout << "Soustraction du premier et second complexe" << endl;
    resultat = c1 - c2;
    cout << resultat;

    cout << "Multiplication du premier et second complexe" << endl;
    resultat = c1 * c2;
    cout << resultat;

    cout << "Division du premier et second complexe" << endl;
    resultat = c1 / c2;
    cout << resultat;

    cout << "Module du premier complexe" << endl;
    cout << c1.module() << endl;

    cout << "Module du second complexe" << endl;
    cout << c2.module() << endl;

    return 0;
}
