#ifndef COMPLEX_H
#define COMPLEX_H

#include <iostream>

using namespace std;


class Complex {
    double _reel, _im;

    public:
        Complex(double reel = 0, double im = 0);
        Complex(Complex const& complexCopie); // Constructeur de copie
        ~Complex();
        double module();
        double getReel() const;
        void setReel(double reel);
        double getIm() const;
        void setIm(double im);
        friend istream& operator>>(istream& is, Complex& c1);
        friend ostream& operator<<(ostream& os, const Complex& c1);
        Complex& operator= (const Complex& c);
        friend Complex operator+(Complex c1, Complex c2);
        friend Complex operator-(Complex c1, Complex c2);
        friend Complex operator*(Complex c1, Complex c2);
        friend Complex operator/(Complex c1, Complex c2);
};

#endif // COMPLEX_H
