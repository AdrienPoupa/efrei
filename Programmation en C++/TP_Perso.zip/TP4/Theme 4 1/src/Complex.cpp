#include "Complex.h"
#include <iostream>
#include <cmath>

using namespace std;

Complex::Complex(Complex const& copie) :_reel(copie._reel), _im(copie._im) {
    // Le constructeur de copie est utilis� m�me si on ne s'en sert pas directement
    cout << "Entree dans le constructeur de copie" << endl;
}

Complex::Complex(double reel, double im) {
    cout << "Entree dans le constructeur" << endl;
    _reel = reel;
    _im = im;
}

Complex::~Complex() {
    cout << "Entree dans le destructeur" << endl;
}

double Complex::getReel() const {
    return _reel;
}

void Complex::setReel(double reel) {
    _reel = reel;
}

void Complex::setIm(double im) {
    _im = im;
}

double Complex::getIm() const {
    return _im;
}

Complex operator+(Complex c1, Complex c2) {
    Complex resultat;

    resultat.setReel(c1.getReel() + c2.getReel());
    resultat.setIm(c1.getIm() + c2.getIm());

    return resultat;
}

Complex operator-(Complex c1, Complex c2) {
    Complex resultat;

    resultat.setReel(c1.getReel() - c2.getReel());
    resultat.setIm(c1.getIm() - c2.getIm());

    return resultat;
}

Complex operator*(Complex c1, Complex c2) {
    Complex resultat;

    resultat.setReel(c1.getReel() * c2.getReel());
    resultat.setIm(c1.getIm() * c2.getIm());

    return resultat;
}

Complex operator/(Complex c1, Complex c2) {
    Complex resultat;

    resultat.setReel(c1.getReel() / c2.getReel());
    resultat.setIm(c1.getIm() / c2.getIm());

    return resultat;
}

ostream& operator<<(ostream& os, const Complex& c1) {
    os << "Complex: " << c1.getReel() << " + " << c1.getIm() << " i" << endl;

    return os;
}

istream& operator>>(istream& is, Complex& c1) {
    cout << "Rentrez la partie reelle puis la partie imaginaire" << endl;
    is >> c1._reel >> c1._im;

    return is;
}

Complex& Complex::operator= (const Complex& c) {
    if (&c != this) {
        _reel = c.getReel();
        _im = c.getIm();
    }
    return *this;
}

double Complex::module() {
    return sqrt(getReel()*getReel() + getIm()*getIm());
}
