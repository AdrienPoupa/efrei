#include "Complex.h"
#include <iostream>
#include <cmath>

using namespace std;

Complex::Complex(Complex const& copie) :_reel(copie._reel), _im(copie._im) {
    // Le constructeur de copie est utilis� m�me si on ne s'en sert pas directement
    cout << "Entree dans le constructeur de copie" << endl;
}

Complex::Complex(double reel, double im) {
    cout << "Entree dans le constructeur" << endl;
    _reel = reel;
    _im = im;
}

Complex::~Complex() {
    cout << "Entree dans le destructeur" << endl;
}

double Complex::getReel() {
    return _reel;
}

void Complex::setReel(double reel) {
    _reel = reel;
}

void Complex::setIm(double im) {
    _im = im;
}

double Complex::getIm() {
    return _im;
}

void Complex::afficher() {
    cout << "Complex: " << getReel() << " + " << getIm() << " i" << endl;
}

void Complex::addition(Complex c1, Complex c2) {
    cout << "c1 reel " << c1.getReel() << endl;
    setIm(c1.getIm() + c2.getIm());
    setReel(c1.getReel() + c2.getReel());
}

void Complex::soustraction(Complex c1, Complex c2) {
    setIm(c1.getIm() - c2.getIm());
    setReel(c1.getReel() - c2.getReel());
}

void Complex::multiplication(Complex c1, Complex c2) {
    setIm(c1.getIm() * c2.getIm());
    setReel(c1.getReel() * c2.getReel());
}

void Complex::division(Complex c1, Complex c2) {
    setIm(c1.getIm() / c2.getIm());
    setReel(c1.getReel() / c2.getReel());
}

double Complex::module() {
    return sqrt(getReel()*getReel() + getIm()*getIm());
}

void Complex::saisie() {
    double reel, im;
    cout << "Rentrez la partie reelle puis la partie imaginaire" << endl;
    cin >> reel >> im;
    cin.ignore();

    setReel(reel);
    setIm(im);
}
