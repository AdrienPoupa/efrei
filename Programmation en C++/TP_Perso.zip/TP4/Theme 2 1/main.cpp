#include <iostream>
#include <cmath>
#include "Complex.h"

using namespace std;

int main()
{
    Complex c1;
    c1.saisie();
    c1.afficher();

    Complex c2;
    c2.saisie();
    c2.afficher();

    Complex c3;
    cout << "Addition du premier et second complexe" << endl;
    cout << "c1 reel " << c1.getReel() << endl;
    c3.addition(c1, c2);
    c3.afficher();

    Complex c4;
    cout << "Soustraction du premier et second complexe" << endl;
    c4.soustraction(c1, c2);
    c4.afficher();

    Complex c5;
    cout << "Multiplication du premier et second complexe" << endl;
    c5.multiplication(c1, c2);
    c5.afficher();

    Complex c6;
    cout << "Division du premier et second complexe" << endl;
    c6.division(c1, c2);
    c6.afficher();

    cout << "Module du premier complexe" << endl;
    cout << c1.module() << endl;

    cout << "Module du second complexe" << endl;
    cout << c2.module() << endl;

    return 0;
}
