#ifndef COMPLEX_H
#define COMPLEX_H


class Complex {
    double _reel, _im;

    public:
        Complex(double reel = 0, double im = 0);
        Complex(Complex const& copie); // Constructeur de copie
        ~Complex();
        void afficher();
        void addition(Complex c1, Complex c2);
        void soustraction(Complex c1, Complex c2);
        void division(Complex c1, Complex c2);
        double module();
        void multiplication(Complex c1, Complex c2);
        double getReel();
        void setReel(double reel);
        double getIm();
        void setIm(double im);
        void saisie();
};

#endif // COMPLEX_H
