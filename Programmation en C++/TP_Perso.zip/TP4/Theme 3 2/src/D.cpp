#include <iostream>
#include "D.h"

using namespace std;

D::D()
{
    cout << "Constructeur : " << this << endl;
    tableau = new int[4];
}

D::D(const D & copie){
    cout << "Constructeur de copie : " << this << endl;
    tableau = new int[4];
    for (int i = 0; i < 4; i++) {
        tableau[i] = copie.tableau[i];
    }
}

D::~D(){
    cout << "Destructeur : " << this << endl;
    delete tableau;
}
