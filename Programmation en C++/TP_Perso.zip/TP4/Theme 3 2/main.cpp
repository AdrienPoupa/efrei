#include <iostream>
#include "D.h"

using namespace std;

int main()
{
    D a;
    D b = a;

    D *test;

    cout << "pointeur sur objet : " << test << endl;

    delete test; // le pointeur sur objet est supprim� en premier
    // puis suppression de b et a

    // Il y a 3 destructions pour 3 objets cr��s

    return 0;
}

