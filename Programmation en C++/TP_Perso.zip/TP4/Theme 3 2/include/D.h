#ifndef D_H
#define D_H


class D
{
    int *tableau;

    public :
        D();
        D(const D & copie);
        ~D();
};

#endif // D_H
