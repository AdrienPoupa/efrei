#ifndef A_H
#define A_H


class A {
    int _inutile;

    public:
        A(int inutile = 0);
};

#endif // A_H
