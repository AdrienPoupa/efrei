#ifndef B_H
#define B_H

#include "A.h"


class B {
    A *a, *a2; // On peut cr�er des instances de A en pointeurs ou non
    A a3, a4, a5;
    public:
        B();
        ~B();
};

#endif // B_H
