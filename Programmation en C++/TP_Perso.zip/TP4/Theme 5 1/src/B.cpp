#include "B.h"

B::B() {
    A *a = new A;
    A *a2 = new A();
    A a3();
    A a4;
}

B::~B() {
    delete a;
    delete a2;
}
