#include "A.h"

A::A(int inutile) {
    _inutile = inutile;
}
