#include <iostream>
#include "A.h"
#include "B.h"

using namespace std;

int main()
{
    B b;
    return 0;
}
