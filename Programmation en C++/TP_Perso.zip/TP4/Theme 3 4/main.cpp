#include <iostream>
#include "Y.h"

using namespace std;

int main()
{
    Y *a = new Y;
    delete a;

    void *b = new Y; // Le constructeur de copie n'est pas appel�
    delete b; // Le destructeur de Y n'est pas appel� dans le cas d'un void* !!

    return 0;
}
