#include "Y.h"
#include <iostream>

using namespace std;

Y::Y(Y const& b) {
    tableau = new double[3];
    for (int i = 0; i<3; i++) {
        tableau[i] = b.tableau[i];
    }
    cout << "Entree dans le constructeur de copie" << endl;
}

Y::Y() {
    cout << "Entree dans le constructeur" << endl;
    tableau = new double[3];
    for (int i = 0; i<3; i++) {
        tableau[i] = 2*i;
    }
}

Y::~Y() {
    cout << "Entree dans le destructeur" << endl;
    delete tableau;
}
