#ifndef SESS_H
#define SESS_H


// inspir� par http://stackoverflow.com/questions/14831480/how-to-generate-a-unique-id-for-each-instance-within-a-class-in-c

class Sess
{
    private:
        static int compteur;
    protected:
        static int id;
    public:
        Sess();
        ~Sess();
        static int nombreInstances();
        int instances;
};

#endif // SESS_H
