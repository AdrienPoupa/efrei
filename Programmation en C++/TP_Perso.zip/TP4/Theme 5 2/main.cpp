#include <iostream>
#include "Sess.h"

using namespace std;

int main()
{
    Sess s1, s2, s3, s4, s5, s6, s7, s8, s9, s10; // Cr�ation de 10 instances
    return 0;
}
