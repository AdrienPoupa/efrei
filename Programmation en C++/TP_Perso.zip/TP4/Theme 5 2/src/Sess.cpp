#include "Sess.h"
#include <iostream>

using namespace std;

int Sess::compteur = 0;

Sess::Sess() {
    ++compteur;
    cout << "Nombre d'instances: " << Sess::nombreInstances() << endl;
}

Sess::~Sess() {
    --compteur;
    cout << "Nombre d'instances: " << Sess::nombreInstances() << endl;
}

int Sess::nombreInstances()
{
    return compteur;
}
