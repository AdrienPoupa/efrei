#include <iostream>
#include "Y.h"

using namespace std;

int main()
{
    Y e;
    e.affichage();

    Y f = e; // Le constructeur de copie est utilis�
    f.affichage();

    f.setValue(); // Modification du tableau de b: tableau[Y] passe de i � 2i

    f.affichage(); // Affiche le tableau 2i
    e.affichage(); // Affiche tableau i: la modification ci-dessus l'affecte aussi!!!
                   // C'est normal, on a d�sormais affaire � des pointeurs...

    return 0;
}
