#ifndef Y_H
#define Y_H


class Y {
    double *tableau;

    public:
        Y();
        Y(Y const& b); // Constructeur de copie
        ~Y();
        void affichage();
        void setValue();
};

#endif // Y_H
