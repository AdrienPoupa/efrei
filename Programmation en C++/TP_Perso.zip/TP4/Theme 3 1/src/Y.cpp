#include "Y.h"
#include <iostream>
#include <cmath>

using namespace std;

Y::Y(Y const& b) {
    tableau = new double[3];
    for (int i = 0; i<3; i++) {
        tableau[i] = b.tableau[i];
    }
    cout << "Entree dans le constructeur de copie" << endl;
}

Y::Y() {
    cout << "Entree dans le constructeur" << endl;
    tableau = new double[3];
    for (int i = 0; i<3; i++) {
        tableau[i] = 2*i;
    }
}

Y::~Y() {
    cout << "Entree dans le destructeur" << endl;
    delete [] tableau;
}

void Y::affichage() {
    for (int i = 0; i<3; i++) {
        cout << "tableau[" << i << "] = " << tableau[i] << endl;
    }
}

void Y::setValue() {
    cout << "Modification du tableau f" << endl;
    for (int i = 0; i<3; i++) {
        tableau[i] = 2*i;
    }
}
