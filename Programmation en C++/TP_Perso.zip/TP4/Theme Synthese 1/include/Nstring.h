#ifndef NSTRING_H
#define NSTRING_H

#include <iostream>

class Nstring
{
    char *texte;
    long length;

    public:
        Nstring();
        Nstring(const char *chaine);
        Nstring(const Nstring &chaine);
        ~Nstring();
        int longueur(const char *chaine);
        char *copie(const char *chaine);
        void afficher();
        Nstring operator=(const char *chaine);
        Nstring operator=(const Nstring &chaine);
        int estEgal(Nstring const& b) const;
        friend std::ostream &operator<<( std::ostream &out, Nstring &chaine );
        friend std::istream &operator>>( std::istream &in, Nstring &chaine );
        friend int operator==(const Nstring &a, const Nstring &b);
        char *getTexte();
        void setCarAt(int position, char remplacement);
};

#endif // NSTRING_H
