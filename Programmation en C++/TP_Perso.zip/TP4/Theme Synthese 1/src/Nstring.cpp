#include <iostream>
#include "Nstring.h"

using namespace std;

/*
    Constructeurs
*/

Nstring::Nstring()
{
    // Initialisation du texte, vide par d�faut
    texte = "[vide]";
    length = 6;
}

Nstring::Nstring(const char *chaine)
{
    texte = copie(chaine);
    length = longueur(chaine);
}

Nstring::Nstring(const Nstring &chaine)
{
    texte = copie(chaine.texte);
    length = chaine.length;
}

/*
    Op�rateurs
*/
Nstring Nstring::operator=(const Nstring &chaine)
{
    if (this != &chaine){
        delete[] texte;
        texte = copie(chaine.texte);
        length = chaine.length;
    }
    return *this;
}

Nstring Nstring::operator=(const char *chaine)
{
    delete[] texte;
    texte = copie(chaine);
    length = longueur(chaine);

    return *this;
}

int operator==(const Nstring &a, const Nstring &b)
{
    return a.estEgal(b);
}

int Nstring::estEgal(Nstring const& b) const
{
    // Si la longeur est diff�rente, pas besoin d'aller plus loin
    if (b.length != length) {
        return 0;
    }

    // On s'arr�te d�s qu'un caract�re est diff�rent
    for (int i = 0 ; i < length; i++) {
        if (texte[i] != b.texte[i]) {
            return 0;
        }
    }

    // Sinon c'est identique!
    return 1;
}

ostream &operator<<(ostream &out, Nstring &chaine)
{
    out << chaine.getTexte();
    return out;
}

istream &operator>>(istream &in, Nstring &chaine)
{
    char input[100];
    in >> input;
    chaine.texte = chaine.copie(input);
    return in;
}

char *Nstring::getTexte()
{
    return texte;
}

void Nstring::afficher()
{
    cout << texte << endl;
}

int Nstring::longueur(const char *chaine)
{
    int i = 0;

    // On parcourt toute la cha�ne jusqu'� la fin en incr�mentant un compteur...
    while (chaine[i] != '\0') {
        i++;
    }

    return i;
}

// Copie de la cha�ne
char *Nstring::copie(const char *chaine)
{
    int taille;

    taille = longueur(chaine);

    char *chaineCopie = new char[taille + 1];

    for (int i = 0 ; i < taille ; i++) {
        chaineCopie[i] = chaine[i];
    }

    chaineCopie[taille] = '\0';
    length = taille;

    return chaineCopie;
}

// Remplace le caract�re en position "position" par un autre de remplacement
void Nstring::setCarAt(int position, char remplacement) {

    // On s'arr�te si la position est invalide
    if (position > length || position < 0) {
        return;
    }

    for (int i = 0 ; i < length ; i++) {
        if (i == position) {
            texte[i] = remplacement;
        }
    }
}

Nstring::~Nstring()
{
    delete[] texte;
}
