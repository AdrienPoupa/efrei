#ifndef VECTOR_H
#define VECTOR_H

#include <cmath>
#include <string.h>
#include <iostream>

using namespace std;

class Vector {
    int *tableau;

    public:
        Vector(int a = 0, int b = 0, int c = 0);
        ~Vector();
        void fillTableau(int v[]);
        void setTableau(int newTableau[]);
        friend istream& operator>>(istream& is, Vector& v1);
        friend ostream& operator<<(ostream& os, const Vector& v1);
        Vector& operator= (const Vector& v);
        friend Vector operator+(Vector v1, Vector v2);
        friend Vector operator-(Vector v1, Vector v2);
        friend Vector operator*(Vector v1, Vector v2);
};

#endif // VECTOR_H
