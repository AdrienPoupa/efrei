#ifndef U_H
#define U_H


class U
{
    protected:
        static int id;
    public:
        U();
        ~U();
};

#endif // U_H
