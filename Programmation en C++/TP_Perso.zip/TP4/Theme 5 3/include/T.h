#ifndef T_H
#define T_H


class T
{
    U *instanceDeU;
    public:
        T();
        ~T();
};

#endif // T_H
