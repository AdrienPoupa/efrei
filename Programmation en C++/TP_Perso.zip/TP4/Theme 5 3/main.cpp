#include <iostream>
#include "U.h"
#include "T.h"

using namespace std;

int main()
{
    T s1, s2; // Cr�ation de 10 instances
    return 0;
}
