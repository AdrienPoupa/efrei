#include <iostream>
#include "U.h"
#include "T.h"

using namespace std;

T::T() {
    cout << "Creation de l'instance T " << endl;
    instanceDeU = new U;
}

T::~T() {
    cout << "Destruction de l'instance T " << endl;
    delete instanceDeU;
}
