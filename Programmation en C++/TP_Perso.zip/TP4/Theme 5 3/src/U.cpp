#include <iostream>
#include "U.h"

using namespace std;

U::U() {
    cout << "Creation de l'instance U " << endl;
}

U::~U() {
    cout << "Destruction de l'instance U " << endl;
}
