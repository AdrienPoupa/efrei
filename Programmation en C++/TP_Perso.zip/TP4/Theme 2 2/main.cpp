#include <iostream>
#include "X.h"

using namespace std;

int main()
{
    X a;
    a.affichage();

    X b = a; // Le constructeur de copie est utilis�
    b.affichage();

    b.setValue(); // Modification du tableau de b: tableau[x] passe de i � 2i

    b.affichage(); // Affiche le tableau 2i
    a.affichage(); // Affiche tableau i: a n'est pas modifi�

    return 0;
}
