#ifndef X_H
#define X_H


class X {
    int tableau[3];

    public:
        X();
        X(X const& b); // Constructeur de copie
        ~X();
        void affichage();
        void setValue();
};

#endif // X_H
