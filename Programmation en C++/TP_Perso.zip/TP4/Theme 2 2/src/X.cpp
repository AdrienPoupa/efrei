#include "X.h"
#include <iostream>

using namespace std;

X::X(X const& b) {
    for (int i = 0; i<3; i++) {
        tableau[i] = b.tableau[i];
    }
    cout << "Entree dans le constructeur de copie" << endl;
}

X::X() {
    for (int i = 0; i<3; i++) {
        tableau[i] = i;
    }
    cout << "Entree dans le constructeur" << endl;
}

X::~X() {
    cout << "Entree dans le destructeur" << endl;
}

void X::affichage() {
    for (int i = 0; i<3; i++) {
        cout << "tableau[" << i << "] = " << tableau[i] << endl;
    }
}

void X::setValue() {
    cout << "Modification du tableau b" << endl;
    for (int i = 0; i<3; i++) {
        tableau[i] = 2*i;
    }
}
