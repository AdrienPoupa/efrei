#ifndef CELL_H
#define CELL_H

#include <iostream>
#include "Nstring.h"


class Cell {
    Nstring _key, _value;
    Cell *_next;
    public:
        Cell();
        Cell(Nstring, Nstring);
        Cell(const Cell &);
        ~Cell();
        Nstring getKey() const;
        Nstring getValue() const;
        Cell *getNext() const;
        void setNext(Cell *);
        void setKey(const Nstring &);
        void setValue(const Nstring &);
        friend std::ostream &operator<<(std::ostream &out, const Cell &cell);
        bool operator==(const Cell &);
        Cell & operator=(const Cell &);
};

#endif // CELL_H
