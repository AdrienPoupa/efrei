#ifndef LIST_H
#define LIST_H

#include <iostream>
#include "Cell.h"


class List {
    Cell *_tete, *_queue;
    public:
        List();
        List(const Cell &);
        List(const List &);
        ~List();
        friend std::ostream &operator<<(std::ostream &out, const List &chaine);
        void chaineTete(Cell &);
        void chaineQueue(Cell &);
        bool contains(const Cell &) const;
        bool isEmpty() const;
        Cell *get(const Nstring) const;
        Cell *getHead() const;
};

#endif // LIST_H
