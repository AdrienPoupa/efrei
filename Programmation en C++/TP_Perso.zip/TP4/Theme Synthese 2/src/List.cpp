#include <iostream>
#include "List.h"

using namespace std;

List::List() {
    _tete = NULL;
    _queue = NULL;
}

List::List(const Cell &c) {
    *_tete = c;
    _queue = NULL;
}

List::List(const List &c) {
    _tete = c._tete;
    _queue = c._queue;
}

void List::chaineTete(Cell &t) {
    *_tete = t;
}

void List::chaineQueue(Cell &q) {
    *_queue = q;
}

ostream &operator<<(ostream &out, const List &chaine) {
    Cell *current = chaine._tete;

    while ((current->getValue() == NULL) == 0) {
        cout << current->getValue().getTexte() << endl;
        current = current->getNext();
    }

    return out;
}

Cell *List::get(const Nstring test) const {
    // Recherche de la cellule contenant Nstring et retour

    Cell *current = this->getHead();

    // On a impl�ment� le == pour les Nstring, retournant 0 ou 1
    // On doit donc v�rifier qu'on n'a pas de "test", c'est � dire tant qu'on a 0 en retour
    while ((current->getValue() == test) == 0) {
        if (current->getValue() == test) {
            return current;
        }
        current = current->getNext();
    }

    return new Cell();
}

Cell* List::getHead() const {
    return _tete;
}

bool List::isEmpty() const {
    if (_tete == NULL && _queue == NULL) {
        return true;
    }
    else {
        return false;
    }
}

bool List::contains(const Cell &c) const {
    Cell *current = this->getHead();

    // On a impl�ment� le == pour les Nstring, retournant 0 ou 1
    // On doit donc v�rifier qu'on n'a pas de NULL, c'est � dire tant qu'on a 0 en retour
    while ((current->getValue() == NULL) == 0) {
        if (current->getValue() == c.getValue()) {
            return true;
        }
        current = current->getNext();
    }

    return false;
}

List::~List() {
    if (_tete != NULL) {
        _tete = NULL;
    }

    if (_queue != NULL) {
        _queue = NULL;
    }
}
