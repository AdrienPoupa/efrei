#include <iostream>
#include "Cell.h"

using namespace std;

bool Cell::operator==(const Cell &c) {
    if (_key == c.getKey()) {
        return true;
    }
    else {
        return false;
    }
}

Cell & Cell::operator=(const Cell &c) {
    if (&c != this) {
        _key = c.getKey();
        _value = c.getValue();
        _next = c.getNext();
    }
    return *this;
}

Cell::Cell(const Cell &cellCopie) {
    _key = cellCopie.getKey();
    _value = cellCopie.getValue();
    _next = new Cell;
}

Nstring Cell::getKey() const {
    return _key;
}

Nstring Cell::getValue() const {
    return _value;
}

Cell* Cell::getNext() const {
    return _next;
}

void Cell::setNext(Cell *next) {
    _next = next;
}

void Cell::setKey(const Nstring &key) {
    _key = key;
}

void Cell::setValue(const Nstring &value) {
    _value = value;
}

Cell::Cell() {
    _key = NULL;
    _value = NULL;
    _next = new Cell;
}

Cell::Cell(Nstring key, Nstring value) {
    _key = key;
    _value = value;
    _next = new Cell;
}

Cell::~Cell() {
    delete _next;
}

ostream &operator<<(ostream &out, const Cell &cell) {
    cout << "Valeur " << cell.getValue().getTexte() << endl;

    return out;
}
