#ifndef O_H
#define O_H


class O {
    public :
        O();
        ~O();
};

#endif // O_H
