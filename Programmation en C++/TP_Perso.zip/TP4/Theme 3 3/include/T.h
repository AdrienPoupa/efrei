#ifndef T_H
#define T_H

#include "O.h"


class T {
    O **tableau2d; // ** car tableau � deux dimensions
    int _ligne, _colonne;

    public:
        T(int ligne = 0, int colonne = 0);
        ~T();
};

#endif // T_H
