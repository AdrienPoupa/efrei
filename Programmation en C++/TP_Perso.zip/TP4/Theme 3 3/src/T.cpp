#include "T.h"
#include <iostream>

using namespace std;

T::T(int ligne, int colonne) {
    _ligne = ligne;
    _colonne = colonne;

    cout << "constructeur de T " << this << endl;

    tableau2d = new O*[_ligne]; // premier appel au constructeur de O

    for (int i = 0; i < _ligne; i++) {
        tableau2d[i] = new O[_colonne]; // appels suivants au constructeur de O
    }
}

T::~T() {
    cout << "destructeur de T " << this << endl;

    for (int i = 0; i < _ligne; i++) {
        delete [] tableau2d[i]; // destruction de O
        // On ajoute [] pour tout supprimer
    }
    delete [] tableau2d;
}
