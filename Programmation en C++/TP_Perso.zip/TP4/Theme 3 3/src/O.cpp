#include "O.h"
#include <iostream>

using namespace std;

O::~O()
{
    cout << "destructeur de O " << this << endl;
}

O::O()
{
    cout << "constructeur de O " << this << endl;
}
