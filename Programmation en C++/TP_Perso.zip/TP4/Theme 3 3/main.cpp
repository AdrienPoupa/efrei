#include <iostream>
#include "O.h"
#include "T.h"

using namespace std;

int main() {
    T t(2, 2);
    return 0;
}
