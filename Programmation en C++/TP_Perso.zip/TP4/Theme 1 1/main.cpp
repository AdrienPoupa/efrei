#include <iostream>

using namespace std;

class testStatus {
    string testMember;
};

int main()
{
    testStatus instance;
    cout << instance.testMember << endl; // error: 'std::string testStatus::testMember' is private donc private par d�faut
    return 0;
}
