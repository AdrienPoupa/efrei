#ifndef BOUCLE_H
#define BOUCLE_H


#include "Variable.h"


class Pour : public Expression {
    protected:
        Expression *_init, *_condition, *_incremente, *_calcul;
    public:
        Pour(Expression *init, Expression *cond, Expression *inc, Expression *calc);
        double eval() const;
        string str() const;
};

#endif // BOUCLE_H
