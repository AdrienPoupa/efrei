#ifndef CONDITIONNEL_H_INCLUDED
#define CONDITIONNEL_H_INCLUDED

#include "Variable.h"

class Conditionnel : public Expression {
    Binaire *_cond;
    Expression *_op1, *_op2;
    public:
        Conditionnel(Binaire* cond, Expression* op1, Expression* op2);
        double eval() const;
};

#endif
