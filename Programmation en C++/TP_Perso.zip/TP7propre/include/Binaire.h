#ifndef BINAIRE_H_INCLUDED
#define BINAIRE_H_INCLUDED

#include "expression.h"

class Binaire : public Expression {
    protected:
    Expression *_opleft, *_opright;
    public:
        Binaire(const string& nom, Expression* left, Expression* right);
        virtual double eval() const = 0;
        virtual string str() const;
};

class Somme : public Binaire {
    public:
        Somme(Expression* left, Expression* right);
        double eval() const;
};

class Difference : public Binaire {
    public:
        Difference(Expression* left, Expression* right);
        double eval() const;
};

class Superieur : public Binaire {
    public:
        Superieur(Expression* left, Expression* right);
        double eval() const;
};

class Produit : public Binaire {
    public:
        Produit(Expression* left, Expression* right);
        double eval() const;
};

class InferieurEgal : public Binaire {
    public:
        InferieurEgal(Expression* left, Expression* right);
        double eval() const;
};

#endif // BINAIRE_H_INCLUDED

