#include "Conditionnel.h"

Conditionnel::Conditionnel(Binaire* cond, Expression* op1, Expression* op2) : Expression("("+cond->str()+") ? "+op1->str()+" : "+op2->str()+")"), _cond(cond), _op1(op1), _op2(op2) {}

double Conditionnel::eval() const { return ((_cond->eval()) ? _op1->eval() : _op2->eval()); }
