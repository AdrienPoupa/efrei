#include "Boucle.h"

Pour::Pour(Expression *init, Expression *cond, Expression *inc, Expression *calc) :
        Expression("for"), _init(init), _condition(cond), _incremente(inc), _calcul(calc) {}

double Pour::eval() const {
    double res = 0.0; // = 0.0 rajout�
    _init->eval();
    while (_condition->eval() != 0.0) {
        res = _calcul->eval();
    }
    return res;
}

string Pour::str() const {
    return _nom + " (" + _init->str() + " ; " + _condition->str() + " ; "
    + _incremente->str() + ") { " + _calcul->str() + " }";
}
