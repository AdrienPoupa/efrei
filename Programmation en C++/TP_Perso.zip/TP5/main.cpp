#include <iostream>
#include <Personne.h>
#include <Date.h>

using namespace std;

// On doit passer les personnes par adresse &
void Marier(Personne &a, Personne &b)
{
    a.epouse(b);
    b.epouse(a);
}

int main()
{
    Personne phil( "Philippe Durant" ) ;
    std::string nom = phil.getNom() ;
    cout << "Saisissez un nouveau nom pour " << nom << ": " ;
    std::string nouveauNom = "";
    cin >> nouveauNom;
    phil.setNom( nouveauNom ) ;
    cout << "Nouveau nom de Philippe: " << phil.getNom() << endl;

    // L'attribut utilis� pour repr�senter le nom est supprim� lors de la destruction de phil

    // Nouvelle personne : Philippe Durant, n� le 10/01/1979
    Personne phil2("Philippe Durant", 10, 1, 1979);
    int age = phil2.getAge(); // r�cup�re l��ge de philippe
    cout << phil2.getNom() << " a " << age << " ans. " << endl;

    /*phil2.setConjoint(phil);
    cout << phil2.getConjoint()->getNom() << endl;*/

    Personne phil_mari( "Philippe Durant", 10, 2, 1978 );
    Personne elo_femme( "�lodie Dupond", 2, 5, 1979 );
    Marier(phil_mari,elo_femme);

    cout << "Nom du conjoint de Phil" << endl;
    cout << phil_mari.getConjoint()->getNom() << endl;

    // Ici on a besoin du constructeur de copie
    Personne philippe( "Philippe Durant", 10, 2, 1977 ) ;
    // Philippe Durant n� le 10/2/1977
    Personne albert( "Albert Gontrand", 24, 8, 1907 ) ;
    // Albert Gontrand n� le 24/8/1907
    albert = philippe ; // on tente une r�incarnation

    cout << "Nom d'Albert apres albert=philippe" << endl;
    cout << albert.getNom() << endl;

    return 0;
}
