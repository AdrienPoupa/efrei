#ifndef DATE_H
#define DATE_H


class Date
{
    public:
        Date();
        Date(int jour, int mois, int annee);
        int getJour();
        int getMois();
        int getAnnee();
        void setJour(int jour);
        void setMois(int mois);
        void setAnnee(int annee);
        virtual ~Date();
    protected:
    private:
        int _jour, _mois, _annee;
};

#endif // DATE_H
