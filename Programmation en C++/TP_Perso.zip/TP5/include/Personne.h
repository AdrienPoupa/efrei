#ifndef PERSONNE_H
#define PERSONNE_H

#include <sstream>
#include <string>
#include <Date.h>

class Personne
{
    public:
        Personne();
        Personne(std::string nom);
        Personne(std::string nom, int jour, int mois, int annee);
        Personne(const Personne &p);
        virtual ~Personne();
        std::string getNom();
        void setNom(std::string nom);
        int getAge();
        void setConjoint(Personne &conjoint);
        void setConjoint();
        Personne* getConjoint();
        void epouse(Personne p);
    protected:
    private:
        std::string _nom, _prenom;
        Date dateNaissance;
        Personne *_conjoint;
};

#endif // PERSONNE_H
