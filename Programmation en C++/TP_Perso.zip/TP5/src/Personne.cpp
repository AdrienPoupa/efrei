#include "Personne.h"

using namespace std;

Personne::Personne(string nom)
{
    istringstream s(nom);

    getline(s, this->_prenom, ' ');
    getline(s, this->_nom, ' ');

    _conjoint = NULL;
}

Personne::Personne()
{
    _prenom = ' ';
    _nom = ' ';
    _conjoint = NULL;
}

Personne::Personne(string nom, int jour, int mois, int annee)
{
    istringstream s(nom);

    getline(s, this->_prenom, ' ');
    getline(s, this->_nom, ' ');

    dateNaissance.setJour(jour);
    dateNaissance.setMois(mois);
    dateNaissance.setAnnee(annee);

    _conjoint = NULL;
}

Personne::Personne(const Personne &p)
{
    // Constructeur de copie
    _nom = p._nom;
    _prenom = p._prenom;
    dateNaissance = p.dateNaissance;
    _conjoint = p._conjoint;
}

Personne::~Personne()
{
    if (_conjoint != NULL) {
        _conjoint = NULL;
    }
}

string Personne::getNom() {
    return _nom;
}

void Personne::setNom(string nom) {
    _nom = nom;
}

int Personne::getAge() {
    return 2015 - dateNaissance.getAnnee();
}

void Personne::setConjoint(Personne &conjoint) {
    _conjoint = new Personne(conjoint);
}

void Personne::setConjoint() {
    _conjoint = NULL;
}

Personne* Personne::getConjoint() {
    return _conjoint;
}

void Personne::epouse(Personne p) {
    setConjoint(p);
}
