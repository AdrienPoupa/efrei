#include "Date.h"
#include "time.h"

Date::Date()
{
    time_t rawtime;
    struct tm * timeinfo;
    time ( &rawtime );
    timeinfo = localtime ( &rawtime );
    this->_jour = timeinfo->tm_mday;
    this->_mois = timeinfo->tm_mon + 1;
    this->_annee = timeinfo->tm_year + 1900;
}

Date::Date(int jour, int mois, int annee)
{
    _jour = jour;
    _mois = mois;
    _annee = annee;
}

Date::~Date() {
}

void Date::setJour(int jour) {
    _jour = jour;
}

void Date::setMois(int mois) {
    _mois = mois;
}

void Date::setAnnee(int annee) {
    _annee = annee;
}

int Date:: getJour() {
    return _jour;
}

int Date:: getMois() {
    return _mois;
}

int Date:: getAnnee() {
    return _annee;
}
