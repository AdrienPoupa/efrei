//
//  MammifereMarin.cpp
//  Séance 4
//
//  Created by Nicolas Sicard on 23/10/2015.
//  Copyright © 2015 Efrei. All rights reserved.
//

#include "MammifereMarin.hpp"

MammifereMarin::MammifereMarin(const string& nom, bool aDesDents) : Mammifere(nom)
{
    _aDesDents = aDesDents;
}

void MammifereMarin::se_deplace() {
    Mammifere::se_deplace();
    cout << " en nageant..." << endl;
}

void MammifereMarin::print() const {
    Mammifere::print();
    cout << "A des dents : " << ((_aDesDents)? "oui":"non") << endl;
}

ostream& operator<<(ostream& os, const MammifereMarin& m)
{
    os << "Mon nom est " << m.getNom() << ((m._aDesDents)? " et j'ai des dents !!":" et je ne mords pas...");
    return os;
}