//
//  main.cpp
//  Séance 4
//
//  Created by Nicolas Sicard on 16/10/2015.
//  Copyright © 2015 Efrei. All rights reserved.
//

#include <iostream>

#include "MammifereMarin.hpp"

using namespace std;

int main(int argc, const char * argv[]) {
    // insert code here...
    cout << "Hello, World!\n";
    
    MammifereMarin mm("Flipper", true);
    Mammifere m("M");

    //mm.print();
    
    cout << mm << endl;

    //mm.se_deplace();
    
    return 0;
}
