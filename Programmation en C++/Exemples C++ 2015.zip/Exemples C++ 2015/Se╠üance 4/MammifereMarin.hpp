//
//  MammifereMarin.hpp
//  Séance 4
//
//  Created by Nicolas Sicard on 23/10/2015.
//  Copyright © 2015 Efrei. All rights reserved.
//

#ifndef MammifereMarin_hpp
#define MammifereMarin_hpp

#include <stdio.h>
#include <iostream>
#include "Mammifere.hpp"

using namespace std;

class MammifereMarin : public Mammifere {
    bool    _aDesDents;
public:
    MammifereMarin(const string& nom, bool aDesDents);
    
    void se_deplace();
    void print() const;
    friend ostream& operator<<(ostream& os, const MammifereMarin& m);
};

#endif /* MammifereMarin_hpp */
