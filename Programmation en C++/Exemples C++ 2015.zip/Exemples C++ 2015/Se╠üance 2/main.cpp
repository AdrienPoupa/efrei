//
//  main.cpp
//  Séance 2
//
//  Created by Nicolas Sicard on 16/09/2015.
//  Copyright (c) 2015 Efrei. All rights reserved.
//

#include <iostream>

using namespace std;

void echanger_copie(double p, double q)
{
    double tmp = p;
    p = q;
    q = tmp;
}

void echanger(double *p, double *q)
{
    double tmp = *p;
    *p = *q;
    *q = tmp;
}

void echanger(double& p, double& q)
{
    double tmp = p;
    p = q;
    q = tmp;
}

void afficher(double& r)
{
    cout << "r = " << r << endl;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";

    const double c = 8.2;
    
//    const double& triche = c;
    
    double  a, b;
    a = 7.8;
    b = -4.2;

    echanger(a, b);
    
    afficher(c);
    
    cout << "a = " << a << " b = " << b << endl;
    
    return 0;
}
