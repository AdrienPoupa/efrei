//
//  main.cpp
//  Seance 5
//
//  Created by Nicolas Sicard on 23/10/2015.
//  Copyright © 2015 Efrei. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
