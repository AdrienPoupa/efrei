//
//  main.cpp
//  Seance3
//
//  Created by Nicolas Sicard on 23/09/2015.
//  Copyright © 2015 Efrei. All rights reserved.
//

#include <iostream>
#include "Complexe.hpp"

using namespace std;


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";

    Complexe c1(8.6,-2.0), c2;

    Complexe c;
    Complexe *pc = new Complexe;
    pc->setRe(1.0);
    
    cout << "c2 = ";
    c2.print();
    
    c = c1.somme(c2);
    
    cout << "c1 + c2 = ";
    c.print();
    
    delete pc;
    
    return 0;
}
