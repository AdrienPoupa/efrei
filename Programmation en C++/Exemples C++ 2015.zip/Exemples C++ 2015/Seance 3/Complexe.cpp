//
//  Complexe.cpp
//  Seance3
//
//  Created by Nicolas Sicard on 23/09/2015.
//  Copyright © 2015 Efrei. All rights reserved.
//

#include "Complexe.hpp"

#include <iostream>

using namespace std;

Complexe::Complexe(const double re, const double im)
{
    _re = re;
    _im = im;
    cout << "Complexe créé et initialisé" << endl;
}

Complexe::~Complexe()
{
    cout << "Complexe détruit" << endl;
}

void Complexe::setRe(const double re) {
    _re = re;
}

void Complexe::setIm(const double im) {
    _im = im;
}

void Complexe::print() const
{
    cout << _re << " + i" << _im << endl;
}

Complexe  Complexe::somme(const Complexe& c) const {
    Complexe res;
    res.setRe(_re + c._re);
    res.setIm(_im + c._im);
    return res;
}
