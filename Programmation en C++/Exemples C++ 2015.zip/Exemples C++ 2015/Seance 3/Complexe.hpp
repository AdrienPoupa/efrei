//
//  Complexe.hpp
//  Seance3
//
//  Created by Nicolas Sicard on 23/09/2015.
//  Copyright © 2015 Efrei. All rights reserved.
//

#ifndef Complexe_hpp
#define Complexe_hpp

#include <stdio.h>

class Complexe {
    double  _re, _im;
public:
    Complexe(const double re=0.0, const double im=0.0);
    ~Complexe();
    void setRe(const double re);
    void setIm(const double im);

    void print() const;

    Complexe    somme(const Complexe& c) const;
};

#endif /* Complexe_hpp */
