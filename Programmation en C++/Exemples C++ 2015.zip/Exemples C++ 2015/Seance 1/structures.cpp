//
//  structures.cpp
//  
//
//  Created by Nicolas Sicard on 14/09/2015.
//
//

#include "structures.h"

