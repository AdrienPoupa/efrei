//
//  structures.h
//  
//
//  Created by Nicolas Sicard on 14/09/2015.
//
//

#ifndef ____structures__
#define ____structures__

#include <stdio.h>

#define MAX 64

typedef struct {
    unsigned    jour, mois, annee;
} date_t;

typedef struct {
    unsigned    numero;
    char        type_voie[MAX];
    char        nom_voie[MAX];
    unsigned    code_postal;
    char        ville[MAX];
} adresse_t ;

typedef struct {
    char        nom[MAX];
    char        prenom[MAX];
    date_t      ddn;
    adresse_t   adresse;
} etudiant_t;


#endif /* defined(____structures__) */
