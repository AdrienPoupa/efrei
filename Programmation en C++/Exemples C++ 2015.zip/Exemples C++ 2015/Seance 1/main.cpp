//
//  main.cpp
//  Seance 1
//
//  Created by Nicolas Sicard on 14/09/2015.
//  Copyright (c) 2015 Efrei. All rights reserved.
//

#include <iostream>
#include "structures.h"

using namespace std;

typedef struct {
    double  re;
    double  im;
} complexe_t;

void somme_complexe(double r1, double i1, double r2, double i2, double *pr, double *pi)
{
    double r, i;
    r = r1 + r2;
    i = i1 + i2;
    
    *pr = r;
    *pi = i;
}

/* Cette fonction prend trois tableaux de deux réels en paramètre */
void somme_complexe_t(double *c1, double *c2, double *res)
{
    res[0] = c1[0]+c2[0];
    res[1] = c1[1]+c2[1];
}

void somme_complexe_st(complexe_t c1, complexe_t c2, complexe_t *pres)
{
    (*pres).re = c1.re + c2.re;
    (*pres).im = c1.im + c2.im;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    cout << "Hello, World!\n";
    
    double re, im;
    somme_complexe(4.7, -3.0, 1.0, 0.0, &re, &im);
    cout << re << " +i " << im << endl;

    double ct1[2], ct2[2], rest[2];
    ct1[0] = 2.3; ct1[1] = 3.1;
    ct2[0] = -0.3; ct2[1] = 1.4;
    somme_complexe_t(ct1, ct2, rest);
    cout << rest[0] << " +i " << rest[1] << endl;
    
    complexe_t cs1, cs2, csr;
    cs1.re = 4.7;
    cs1.im = -3.0;
    cs2.re = -9.8;
    cs2.im = 3.5;

    somme_complexe_st(cs1, cs2, &csr);
    
    cout << csr.re << " +i " << csr.im << endl;
    
    etudiant_t  diant;
    
    return 0;
}
