package exercise1;

/**
 * @author Salim
 */

public class Transf {

	public static void main(String[] args) {
		try {
			System.out.println("début");
			Parser parseur = new Parser();

			// String filename = ".\\bib.xml";
			String filename = "bib.xml";

			parseur.parse(filename);
			System.out.println("fin");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
