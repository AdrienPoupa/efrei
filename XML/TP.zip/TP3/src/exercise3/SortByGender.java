package exercise3;

public class SortByGender {

	/**
	 * On prend en entrée un document XML du type de gender.xml, qui contient
	 * une liste de personnes (avec leur sexe) et pour chaque personne la liste
	 * de ses enfants. On veut obtenir en sortie un document du type
	 * gender-sorted.xml dans lequel on sépare clairement les garçons des
	 * filles. Ecrivez un programme Java utilisant DOM pour réaliser cette
	 * transformation.
	 */
	public static void main(String[] args) {
		// TODO
		
	}

}
