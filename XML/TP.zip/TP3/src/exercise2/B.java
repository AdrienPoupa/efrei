package exercise2;

public class B {

	public static void main(String[] args) {
		// TODO �crire le programme Java-DOM qui permettrait de lire sur la
		// console le nom d�un �l�ment (nom de balise) et de l�effacer du
		// fichier xml donn� ci-dessus.

	}

}