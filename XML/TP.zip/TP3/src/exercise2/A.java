package exercise2;

public class A {

	public static void main(String[] args) {
		// TODO Ecrire le code Java-DOM qui permettrait de lire sur la console
		// le nom d�un �l�ment (nom de balise) et d�afficher son contenu.
		
	}

}
