﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class AskResource
    {
        private SystemResource _resource;
        private int _time;
        private Int64 _currentTimestamp;
        private Int64 _endTimestamp;

        public AskResource()
        {
            _resource = null;
            _time = 0;
            _currentTimestamp = 0;
            _endTimestamp = 0;
        }

        public SystemResource resource
        {
            get { return _resource; }
            set { _resource = value; }
        }

        public int time
        {
            get { return _time; }
            set { _time = value; }
        }

        public void acquireResource(SystemResource resource, int time)
        {
            _currentTimestamp = GetTimestamp(DateTime.Now);

            if (_resource != null && _currentTimestamp < _endTimestamp)
            {
                Console.WriteLine("Cannot acquire " + resource.name + ": resource not available");
                //return;
            }
            else
            {
                _resource = resource;
                _time = time;
                _endTimestamp = _currentTimestamp + time;

                Console.WriteLine("Acquiring resource " + resource.name);
                Console.WriteLine("Holding " + resource.name + " for " + time + " seconds...");
            }
        }

        public void freeResource()
        {
            Console.WriteLine("Freeing resource " + resource.name);

            _resource = null;
            _time = 0;
            _currentTimestamp = 0;
            _endTimestamp = 0;
        }

        public static Int64 GetTimestamp(DateTime value)
        {
            return Int64.Parse(value.ToString("yyyyMMddHHmmss"));
        }
    }
}
