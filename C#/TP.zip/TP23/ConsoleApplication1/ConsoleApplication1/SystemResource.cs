﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class SystemResource
    {
        private string _name; // printer, disk...

        public SystemResource(string name)
        {
            _name = name;
        }

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }
    }
}
