﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleApplication1
{
    class Program
    {
        public static SystemResource Printer = new SystemResource("printer");
        public static SystemResource Ram = new SystemResource("ram");
        public static SystemResource Disk = new SystemResource("disk");
        public static SystemResource Scanner = new SystemResource("scanner");

        static void Main(string[] args)
        {
            HashSet<SystemResource> resources = new HashSet<SystemResource>();
            SystemResource printer = new SystemResource("printer");
            SystemResource ram = new SystemResource("ram");
            SystemResource disk = new SystemResource("disk");

            resources.Add(printer);
            resources.Add(ram);
            resources.Add(disk);

            AskResource ask = new AskResource();
            AskResource ask2 = new AskResource();
            AskResource ask3 = new AskResource();

            while (true)
            {
                ask.acquireResource(printer, 5);
                ask.acquireResource(ram, 1);
                ask.acquireResource(disk, 2);
                ask2.acquireResource(printer, 5);
                ask2.acquireResource(ram, 15);
                ask2.acquireResource(disk, 5);
                ask3.acquireResource(printer, 1);
                ask3.acquireResource(ram, 2);
                ask3.acquireResource(disk, 3);
                System.Threading.Thread.Sleep(1000);
            }

            Thread TA = new Thread(new ThreadStart(ThA));
            Thread TB = new Thread(new ThreadStart(ThB));
            Thread TC = new Thread(new ThreadStart(ThC));
            TA.Start();
            TB.Start();
            TC.Start();
            System.Console.Read();
        }

        public static void ThA()
        {
            AskResource PrintJob = new AskResource();
            PrintJob.acquireResource(Disk, 2);
            PrintJob.acquireResource(Ram, 1);
            PrintJob.acquireResource(Printer, 8);
        }

        public static void ThB()
        {
            AskResource TestPrinter = new AskResource();
            TestPrinter.acquireResource(Ram, 1);
            TestPrinter.acquireResource(Printer, 3);
        }

        public static void ThC()
        {
            AskResource ScanJob = new AskResource();
            ScanJob.acquireResource(Scanner, 2);
            ScanJob.acquireResource(Ram, 1);
            ScanJob.acquireResource(Scanner, 2);
            ScanJob.acquireResource(Ram, 1);
            ScanJob.acquireResource(Scanner, 2);
            ScanJob.acquireResource(Ram, 1);
            ScanJob.acquireResource(Scanner, 2);
            ScanJob.acquireResource(Ram, 1);
            ScanJob.acquireResource(Ram, 3);
            ScanJob.acquireResource(Disk, 5);
        }
    }
}
