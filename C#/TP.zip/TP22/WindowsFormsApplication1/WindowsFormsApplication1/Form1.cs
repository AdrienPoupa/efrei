﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create the thread object. This does not start the thread.
            Worker workerObjectA = new Worker("A", textBox1);
            Thread workerThreadA = new Thread(workerObjectA.DoWork);

            // Start the worker thread.
            workerThreadA.Start();

            // Create the thread object. This does not start the thread.
            Worker workerObjectB = new Worker("B", textBox1);
            Thread workerThreadB = new Thread(workerObjectB.DoWork);

            // Start the worker thread.
            workerThreadB.Start();

            // Create the thread object. This does not start the thread.
            Worker workerObjectC = new Worker("C", textBox1);
            Thread workerThreadC = new Thread(workerObjectC.DoWork);

            // Start the worker thread.
            workerThreadC.Start();

            // Create the thread object. This does not start the thread.
            Worker workerObjectD = new Worker("D", textBox1);
            Thread workerThreadD = new Thread(workerObjectD.DoWork);

            // Start the worker thread.
            workerThreadD.Start();

            // Create the thread object. This does not start the thread.
            Worker workerObjectE = new Worker("E", textBox1);
            Thread workerThreadE = new Thread(workerObjectE.DoWork);

            // Start the worker thread.
            workerThreadE.Start();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
