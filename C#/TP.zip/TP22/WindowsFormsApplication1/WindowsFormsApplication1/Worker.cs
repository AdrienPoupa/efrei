﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public class Worker
    {
        private string _letter;
        private TextBox _textBox;

        public Worker(string letter, TextBox textBox)
        {
            _letter = letter;
            _textBox = textBox;
        }
        // This method will be called when the thread is started.
        public void DoWork()
        {
            while (!_shouldStop)
            {
                // thread safe text appending source: http://stackoverflow.com/a/10804951
                // multi line appending source: http://stackoverflow.com/questions/8536958/how-to-add-a-line-to-a-multiline-textbox
                _textBox.Invoke((MethodInvoker)(() =>
                {
                    if (_textBox.Text.Length == 0)
                        _textBox.Text = _letter;
                    else
                        _textBox.AppendText("\r\n" + _letter);
                }));
            }
            //Console.WriteLine("worker thread: terminating gracefully.");
        }
        public void RequestStop()
        {
            _shouldStop = true;
        }
        // Volatile is used as hint to the compiler that this data
        // member will be accessed by multiple threads.
        private volatile bool _shouldStop;
    }
}
