﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2
{
    public class PrimeEventArgs : System.EventArgs
    {
        private long _prime;

        public long Prime
        {
            get { return _prime; }
        }

        public PrimeEventArgs(long p) : base()
        {
            _prime = p;
        }
    }

}
