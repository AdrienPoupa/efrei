﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2
{
    class PrimeSender
    {
        public event PrimeEventHandler handler;

        protected virtual void onPrime(object sender, PrimeEventArgs e)
        {
            if (handler != null)
            {
                handler(this, e);
            }
        }

        public void raiseEvent(long prime)
        {
            PrimeEventArgs e = new PrimeEventArgs(prime);
            onPrime(this, e);
        }

        /**
         * Calcul de nombre premier
         * Source: http://stackoverflow.com/a/1510196
         */
        public void calculatePrimes(long limit)
        {
            // bool isPrime = true;
            for (long i = 0; i <= limit; i++)
            {
                bool isPrime = true; // Move initialization to here
                for (long j = 2; j < i; j++) // you actually only need to check up to sqrt(i)
                {
                    if (i % j == 0) // you don't need the first condition
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime)
                {
                    raiseEvent(i);
                }
       
            }
        }
    }
}
