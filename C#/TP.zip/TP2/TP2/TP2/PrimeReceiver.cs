﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2
{
    class PrimeReceiver
    {
        public void action(object sender, PrimeEventArgs pe)
        {
            Console.WriteLine("Nombre premier: "+pe.Prime);
        }

        public void action2(object sender, PrimeEventArgs pe)
        {
            Console.WriteLine("bonjour");
        }

        public void action3(object sender, PrimeEventArgs pe)
        {
            Console.WriteLine("bonsoir");
        }


    }
}
