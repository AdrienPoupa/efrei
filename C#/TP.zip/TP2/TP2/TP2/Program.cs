﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2
{
    class Program
    {
        static void Main(string[] args)
        {
            PrimeSender t = new PrimeSender();
            PrimeReceiver r = new PrimeReceiver();
            // subscription
            t.handler += new PrimeEventHandler(r.action);
            t.handler += r.action2;
            t.handler += r.action3;
            t.handler -= r.action2;
            // to be continued

            // …
            t.raiseEvent(15); //
                              // r.action is called by the delegate

            t.calculatePrimes(100);
            Console.Read(); // pause
        }
    }
}
