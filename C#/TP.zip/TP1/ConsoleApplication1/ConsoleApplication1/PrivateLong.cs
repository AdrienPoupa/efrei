﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class PrivateLong
    {
        private long _privateLongAttribute;
        private long _min;
        private long _max;

        public PrivateLong()
        {
            _min = 0;
            _max = 100;
        }

        public long privateLongAttribute
        {
            get
            {
                return _privateLongAttribute;
            }
            set
            {
                // Mise à jour de l'attribut s'il est > 0
                if (value > 0)
                {
                    _privateLongAttribute = value;
                }
            }
        }

        public long min
        {
            get
            {
                return _min;
            }
            set
            {
                // Mise à jour de l'attribut min s'il est <= au max
                if (value <= max)
                {
                    _min = value;
                }
            }
        }

        public long max
        {
            get
            {
                return _max;
            }
            set
            {
                _max = value;
            }
        }
    }
}
