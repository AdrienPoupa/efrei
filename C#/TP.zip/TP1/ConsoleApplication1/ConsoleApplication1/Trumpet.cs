﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Trumpet : Brass
    {
        public Trumpet()
        {
            P.rintln("Creating a trumpet");
        }

        public override string play()
        {
            P.rintln(blow());
            return "playing the trumpet";
        }

        protected string blow()
        {
            return "blowing the trumpet";
        }
    }
}
