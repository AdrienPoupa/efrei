﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    abstract class Instrument
    {
        public Instrument()
        {
            P.rintln("Creating an instrument");
        }

        public abstract string play();
    }
}
