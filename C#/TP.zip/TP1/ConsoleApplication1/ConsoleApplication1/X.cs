﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class X
    {
        static int counter = 0;
        private int instanceId;

        public X()
        {
            Interlocked.Increment(ref counter);
            instanceId = counter;
        }

        ~X()
        {
            Interlocked.Decrement(ref counter);
        }

        public override string ToString()
        {
            return "Object from class X (number " + instanceId + ")";
        }

    }
}
