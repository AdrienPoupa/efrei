﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    abstract class Brass : Instrument
    {
        public Brass()
        {
            P.rintln("Creating a brass");
        }

        protected virtual string blow()
        {
            return "blowing the brass...";
        }
    }
}
