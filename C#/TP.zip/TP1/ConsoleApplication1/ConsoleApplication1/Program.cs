﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ConsoleApplication1;

public class HelloWorld
{
    static void Main(string[] args)
    {
        /* Exercice 1
         * P.rint("Hello, World!");
        P.ause();
        System.Console.Read();
        */

        /* Exercice 2
         * 
        X obj1, obj2;

        obj1 = new X();
        obj2 = new X();

        Console.WriteLine(obj1);
        Console.WriteLine(obj2);
        P.ause();
        */

        /* Exercice 3
         * PrivateLong obj1;
        obj1 = new PrivateLong();
        obj1.privateLongAttribute = 1;
        P.rintln(obj1.privateLongAttribute); // retourne 1
        obj1.privateLongAttribute = -1;
        P.rint(obj1.privateLongAttribute); // retourne 1 aussi car -1 < 0 !

        P.rintln(obj1.min);
        P.rintln(obj1.max);
        obj1.min = 50;
        obj1.max = 150;
        P.rintln(obj1.min);
        P.rintln(obj1.max);
        obj1.min = 200;
        obj1.max = 150;
        P.rintln(obj1.min); // le min ne change pas car > max !
        P.rintln(obj1.max);

        P.ause();
        */

        /* Exercice 4
         * Instrument trumpet;
        trumpet = new Trumpet();
        P.rintln(trumpet.play());
        P.ause();
        */

        // Create the thread object. This does not start the thread.
        Worker workerObjectA = new Worker("A");
        Thread workerThreadA = new Thread(workerObjectA.DoWork);

        // Start the worker thread.
        workerThreadA.Start();

        // Create the thread object. This does not start the thread.
        Worker workerObjectB = new Worker("B");
        Thread workerThreadB = new Thread(workerObjectB.DoWork);

        // Start the worker thread.
        workerThreadB.Start();

        // Create the thread object. This does not start the thread.
        Worker workerObjectC = new Worker("C");
        Thread workerThreadC = new Thread(workerObjectC.DoWork);

        // Start the worker thread.
        workerThreadC.Start();

        // Create the thread object. This does not start the thread.
        Worker workerObjectD = new Worker("D");
        Thread workerThreadD = new Thread(workerObjectD.DoWork);

        // Start the worker thread.
        workerThreadD.Start();

        // Create the thread object. This does not start the thread.
        Worker workerObjectE = new Worker("E");
        Thread workerThreadE = new Thread(workerObjectE.DoWork);

        // Start the worker thread.
        workerThreadE.Start();
        

        P.ause();
    }
}