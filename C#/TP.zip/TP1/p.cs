public class P
{
	public static void ause()
	{
		System.Console.Read();
	}

	public static void rint(object o)
	{
			System.Console.Write(o.ToString());
	}

	public static void rintln(object o)
	{
			System.Console.WriteLine(o.ToString());
	}

	public static string scan()
	{
			return System.Console.ReadLine();
	}
}