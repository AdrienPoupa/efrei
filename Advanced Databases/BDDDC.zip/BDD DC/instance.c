/*
 * instance.c
 *
 *  Created on: 12 août 2016
 *      Author: Andy
 */

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

#include "../Headers/dbwr.h"
#include "../Headers/parser.h"
#include "../Headers/instance.h"


void readQuery(pthread_t t)
{
	char *query;


	char str[400];

	char *c = malloc(sizeof(char));


	while(1)
	{
		*c = '\0';
		query = calloc(sizeof(char), 400);
		printf("bdd");
		while(*c != ';')
		{
			printf(">");
			fgets(str, sizeof(str), stdin);
			query[strlen(query)] = ' ';
			query[strlen(query)+1] = '\0';
			strcat(query, str);
			*c = query[strlen(query)-2];
		}

		//query[strlen(query)-2] = '\0';

		while(query[0] == ' ')
			query++;

		if(memcmp(query, "exit", strlen("exit")) == 0)
		{
			scan();
			printf("Stopping database\n");
			pthread_cancel(t);
			break;
		}

		query[strlen(query)-2] = '\0';

		replace(query, '\n', ' ');

		sql(query);
		//free(query);
	}

}

/*
 * Fonction utilitaire pour retirer les \n de la requête sql
 */
void replace(char *s, char ch, char repl) {

	//Retire les \n de la requete sql
	for(int i=0;i<(int)strlen(s);i++)
	{
		if(s[i] == (char)ch)
			s[i] = repl;
	}

	//Retire les espaces présents à la fin de la requête si il y en a
	while(s[strlen(s)-1] == ' ')
	{
		s[strlen(s)-1] = '\0';
	}

}

void startDb()
{
	printf("Starting database\n");

	//DBWR Thread
	pthread_t threadDbwr;
	pthread_t threadLecture;

	//Création du thread
	pthread_create(&threadDbwr, NULL, (void *)*startDbwr, NULL);
	pthread_create(&threadLecture, NULL, (void *)*readQuery, threadDbwr);

	pthread_join(threadDbwr, NULL);
	pthread_join(threadLecture, NULL);
}
