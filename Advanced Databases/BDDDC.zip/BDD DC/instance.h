/*
 * instance.h
 *
 *  Created on: 12 août 2016
 *      Author: Andy
 */

#ifndef HEADERS_INSTANCE_H_
#define HEADERS_INSTANCE_H_

void readQuery(pthread_t t);
void replace(char *s, char ch, char repl);
void startDb();

#endif /* HEADERS_INSTANCE_H_ */
