/*
 * test.c
 *
 *  Created on: 9 juil. 2016
 *      Author: Andy
 */

//Includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>


#include "../Headers/tableOperations.h"
#include "../Headers/LRUCache.h"
#include "../Headers/parser.h"
#include "../Headers/dbwr.h"
#include "../Headers/instance.h"




//Main
int main (void)
{

	file = creerFile(6000);
	hash = creerHash(300);

	char *t = "create table bruh (age int)";
	//sql(t);

	startDb();

	return 0;

}

