/*************************************************************/
/***  L'3 - SDD - TP 1 - Listes cha�n�es                   ***/
/*************************************************************/

#include <iostream>
#include <sstream>
#include <string>
#include <stdlib.h>

using namespace std;


/******************************************************************************
 DEFINITION D'UNE LISTE D'ENTIERS
 ******************************************************************************/

typedef struct maillon {
	int info;
	struct maillon* succ;
	struct maillon* pred;
} maillon;

typedef maillon* liste;

#define NUTIL ((maillon*)(-1))

/******************************************************************************
 FONCTIONS UTILITAIRES ET EXEMPLE
 ******************************************************************************/

/**
 * Convertit un tableau d'entiers en une liste simplement ou doublement
 * cha�n�e, lin�aire ou circulaire.
 *
 * Param�tre n : le nombre d'�l�ments de t.
 * Param�tre t : tableau d'entiers � convertir.
 * Param�tre d : vrai si la liste doit �tre doublement cha�n�e; d�faut : faux.
 * Param�tre c : vrai si la liste doit �tre circulaire; d�faut : faux.
 *
 * Retourne : la liste �quivalente � t.
 */
liste listet(int n, const int t[], bool d = false, bool c = false) {
	if (t == NULL || n == 0) {
		return NULL;
	}
	maillon* m = new maillon;
	m->info = t[0];
	liste l = m;
	for (int i = 1; i < n; i++) {
		m->succ = new maillon;
		m->succ->info = t[i];
		m->succ->pred = (d ? m : NUTIL);
		m = m->succ;
	}
	m->succ = (c ? l : NULL);
	l->pred = (d ? (c ? m : NULL) : NUTIL);
	return l;
}

/**
 * Repr�sente une liste sous forme d'une cha�ne de caract�res. La liste peut
 * �tre simplement ou doublement cha�n�e, lin�aire ou circulaire.
 *
 * Param�tre l : liste � repr�senter.
 *
 * Retourne : la cha�ne repr�sentant l.
 */
string chainel(liste l) {
	if (l == NULL) {
		return ".";
	}
	ostringstream r;
	if (l->pred != NUTIL) {
	    r << (l->pred == NULL ? "|" : "<");
	}
	maillon* c = l;
	do {
		r << "[" << c->info << "]";
		if (c->succ == NULL || c->succ == l) {
		    break;
		}
        if (c->succ->pred != NUTIL) {
            r << (c->succ->pred == c ? "<" : "?");
		}
		r << "->";
		c = c->succ;
	} while (true);
	r << (c->succ == NULL ? "|" : ">");
	return r.str();
}

/**
 * D�termine la longueur d'une liste lin�aire ou circulaire.
 *
 * Param�tre l : liste � examiner.
 *
 * Retourne : la longueur de l.
 */
int longueur(liste l) {
	if (l == NULL) {
		return 0;
	}
	int n = 0;
	maillon* m = l;
	do {
		n += 1;
		m = m->succ;
	} while (m != NULL && m != l);
	return n;
}


/******************************************************************************
 1- FONCTIONS A DEVELOPPER - Parcours de listes
 ******************************************************************************/

/**
 * D�termine le nombre d'occurrences d'un �l�ment dans une liste lin�aire.
 *
 * La fonction doit �tre impl�ment�e en it�ratif et en r�cursif.
 *
 * Param�tre l : liste � examiner.
 * Param�tre e : �l�ment � compter.
 *
 * Retourne : le nombre d'occurrences de e dans l.
 */
int occurrences(liste l, int e) {
	throw "non traite";
}

int occurrences_rec(liste l, int e) {
	throw "non traite";
}

/**
 * D�termine la position de la premi�re occurrence d'un �l�ment dans une liste
 * lin�aire. La position du maillon de t�te est 1.
 *
 * La fonction doit �tre impl�ment�e en it�ratif et en r�cursif.
 *
 * Param�tre l : liste � examiner.
 * Param�tre e : �l�ment � trouver.
 *
 * Retourne : la position de la premi�re occurrence de e dans l ou 0 si e n'est
 * pas dans l.
 */
int position(liste l, int e) {
	throw "non traite";
}

int position_rec(liste l, int e) {
	throw "non traite";
}

/**
 * D�termine si une liste simplement cha�n�e lin�aire est tri�e par ordre
 * croissant de ses �l�ments.
 *
 * La fonction doit �tre impl�ment�e en it�ratif et en r�cursif.
 *
 * Param�tre l : liste � examiner.
 *
 * Retourne : 1 si la liste est tri�e par ordre croissant de ses �l�ments et
 * 0 sinon.
 */
int estTriee(liste l) {
	throw "non traite";
}

int estTriee_rec(liste l) {
	throw "non traite";
}


/******************************************************************************
 2- FONCTIONS A DEVELOPPER - Modifications de listes
 ******************************************************************************/

/**
 * Ins�re un �l�ment dans une liste doublement cha�n�e lin�aire apr�s une
 * position donn�e. Si la position sp�cifi�e est 0, l'insertion se fait en
 * t�te de liste.
 *
 * Param�tre l : liste � modifier.
 * Param�tre p : position apr�s laquelle Ins�rer.
 * Param�tre e : �l�ment � Ins�rer.
 *
 * Retourne : 1 si succ�s ou 0 sinon (un param�tre est incorrect).
 */
int inserer(liste* l, int p, int e) {
	throw "non traite";
}

/**
 * Supprime d'une liste doublement cha�n�e lin�aire l'�l�ment situ� � une
 * position donn�e. Si la position est sup�rieure � la longueur de la liste,
 * le dernier maillon est supprim�.
 *
 * Param�tre l : liste � modifier.
 * Param�tre p : position de l'�l�ment � supprimer.
 *
 * Retourne : 1 si succ�s ou 0 sinon (un param�tre est incorrect).
 */
int supprimer(liste* l, int p) {
	throw "non traite";
}

/**
 * Supprime toutes les occurrences d'un �l�ment dans une liste simplement
 * cha�n�e lin�aire.
 *
 * La fonction doit �tre impl�ment�e en it�ratif et en r�cursif.
 *
 * Param�tre l : liste dans laquelle supprimer e.
 * Param�tre e : �l�ment � supprimer dans l.
 *
 * Retourne : 1 si succ�s ou 0 sinon (un param�tre est incorrect).
 */
int supprimero(liste* l, int e) {
	throw "non traite";
}

int supprimero_rec(liste* l, int e) {
	throw "non traite";
}

/**
 * Inverse l'ordre des �l�ments d'une liste simplement cha�n�e lin�aire.
 * L'inversion se fait en place, sans recopie des maillons de la liste.
 *
 * La fonction doit �tre impl�ment�e en it�ratif et en r�cursif.
 *
 * Param�tre l : liste � inverser.
 *
 * Retourne : 1 si succ�s ou 0 sinon (un param�tre est incorrect).
 */
int inverser(liste* l) {
	throw "non traite";
}

int inverser_rec(liste* l) {
	throw "non traite";
}

/**
 * Cr�e une liste doublement cha�n�e lin�aire, copie invers�e d'une liste
 * simplement cha�n�e lin�aire. La liste initiale n'est pas modifi�e.
 *
 * Param�tre l : liste � inverser.
 *
 * Retourne : la liste doublement cha�n�e lin�aire copie invers�e de l.
 */
liste copierInverser(liste l) {
	throw "non traite";
}

/**
 * Concat�ne deux listes simplement cha�n�es lin�aires entre elles.
 *
 * Param�tre l1 : liste � laquelle concatener l2.
 * Param�tre l2 : liste � concatener � l1.
 *
 * Retourne : 1 si succ�s ou 0 sinon (un param�tre est incorrect).
 */
int concatener(liste* l1, liste l2) {
	throw "non traite";
}

/**
 * D�truit une liste cha�n�e lin�aire. L'ensemble de ses maillons est lib�r�.
 *
 * La fonction doit �tre impl�ment�e en it�ratif et en r�cursif.
 *
 * Param�tre l : liste � d�truire.
 *
 * Retourne : 1 si succ�s ou 0 sinon (un param�tre est incorrect).
 */
int detruire(liste* l) {
	throw "non traite";
}

int detruire_rec(liste* l) {
	throw "non traite";
}


/******************************************************************************
 PROGRAMME DE TEST - Tester ici chaque fonction developp�e
 ******************************************************************************/

int main(int argc, char* argv[]) {

	// AUTEURS (� compl�ter)
	cout << "AUTEURS : Nom1, Nom2 \n" <<endl;

	// TEST longueur (exemple)
	cout << "TEST longueur" << endl;
	liste l = listet(0, NULL);
	cout << "longueur( " << chainel(l) << " ) = " << longueur(l) << endl;
	l = listet(1, (const int[]) {1});
	cout << "longueur( " << chainel(l) << " ) = " << longueur(l) << endl;
	l = listet(3, (const int[]) {1, 2, 3});
	cout << "longueur( " << chainel(l) << " ) = " << longueur(l) << endl;
	l = listet(1, (const int[]) {1}, false, true);
	cout << "longueur( " << chainel(l) << " ) = " << longueur(l) << endl;
	l = listet(3, (const int[]) {1, 2, 3}, false, true);
	cout << "longueur( " << chainel(l) << " ) = " << longueur(l) << endl;

	// TEST occurrences


	// TEST occurrence_rec


	// ...

	return 0;
}
