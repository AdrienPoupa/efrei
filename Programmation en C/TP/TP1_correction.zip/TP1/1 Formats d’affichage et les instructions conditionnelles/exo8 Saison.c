#include <stdio.h>

int main()
{
    char a;

    printf("Quelle saison ?\n");
    scanf(" %c",&a);

    if (a == 'p')
        printf("Printemps\n");
    else if (a == 'e')
        printf("Ete\n");
    else if (a == 'a')
        printf("Automne\n");
    else if (a == 'h')
        printf("Hiver\n");
    else
        printf("Ceci n'est pas une saison\n");

    return 0;
}
