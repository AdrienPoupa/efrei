#include <stdio.h>

int main()
{
    float n1, n2, n3, n4, a1, a2, a3, a4;
    float moyenne = 0;
    int compteur;

    printf("Saisie des notes ponderees\n");
    compteur = 1;

    /** on ne peut plus v�rifier que la somme des 4 coefficients vaut 1
        car 3 coefficients seulement, correspondant aux 3 meilleures notes, seront retenus.
        Mais on ne sait pas encore lesquels!
    */
    printf("Note %d : ", compteur);
    scanf("%f", &n1),
    printf("Coefficient %d : ", compteur++);
    scanf("%f", &a1);

    printf("Note %d : ", compteur);
    scanf("%f", &n2),
    printf("Coefficient %d : ", compteur++);
    scanf("%f", &a2);

    printf("Note %d : ", compteur);
    scanf("%f", &n3),
    printf("Coefficient %d : ", compteur++);
    scanf("%f", &a3);

    printf("Note %d : ", compteur);
    scanf("%f", &n4),
    printf("Coefficient %d : ", compteur);
    scanf("%f", &a4);

    if ((a1 < a2) && (a1 < a3) && (a1 < a4)) /** a1 est le minimum */
        moyenne = a2 * n2 + a3 * n3 + a4 * n4;
    else if ((a2 < a1) && (a2 < a3) && (a2 < a4)) /** a2 est le minimum */
        moyenne = a1 * n1 + a3 * n3 + a4 * n4;
    else if ((a3 < a1) && (a3 < a2) && (a3 < a4)) /** a3 est le minimum */
        moyenne = a1 * n1 + a2 * n2 + a4 * n4;
    else /** a4 est le minimum */
        moyenne = a1 * n1 + a2 * n2 + a3 * n3;

    if (moyenne < 10)
        printf("Non recu avec une moyenne de %.2f\n", moyenne);
    else
        printf("Admissible avec une moyenne de %.2f\n", moyenne);

    return 0;
}
