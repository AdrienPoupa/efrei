#include <stdio.h>

int main()
{
    int c, d;
    float a, b;

    /** Première partie */
    c = 15;
    d = 2;
    printf(" Somme : %d \n Difference : %d \n Produit : %d \n Quotient : %d\n",c + d, c - d, c * d, c / d);


    /** Deuxième partie */
    a = 15.14;
    b = 2.9;
    printf(" Somme : %d \n Difference : %d \n Produit : %d \n Quotient : %d\n",c + d, c - d, c * d, c / d);


    /** Troisième partie */
    printf("Entrez a et b\n");
    scanf("%f %f",&a, &b);

    printf(" Somme : %d \n Difference : %d \n Produit : %d \n",c + d, c - d, c * d);
    if (b == 0)
        printf("Impossible de diviser par zero\n");
    else
        printf("Quotient : %f\n", a / b);

    return 0;
}
