#include <stdio.h>


int main()
{
    int n;
    float prix;

    printf("nombre de pommes : ");
    scanf("%d", &n);

    printf("prix d'une pomme : ");
    scanf("%f", &prix);

    if (n > 5)
        prix = 0.95 * prix;
    else if ((n >= 3) && (n <= 5))
        prix = 0.97 * prix;

    printf ("Les %d pommes coutent %.2f \n", n, n * prix);

    return 0;
}
