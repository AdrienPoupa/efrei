#include <stdio.h>

int main()
{
    float n1, n2, n3, a1, a2, a3;
    float moyenne = 0;
    int compteur;

    do
    {
        printf("Saisie des notes ponderees (la somme des ooefficients doit valoir 1\n");
        compteur = 1;

        printf("Note %d : ", compteur);
        scanf("%f", &n1),
        printf("Coefficient %d : ", compteur++);
        scanf("%f", &a1);

        printf("Note %d : ", compteur);
        scanf("%f", &n2),
        printf("Coefficient %d : ", compteur++);
        scanf("%f", &a2);

        printf("Note %d : ", compteur);
        scanf("%f", &n3),
        printf("Coefficient %d : ", compteur);
        scanf("%f", &a3);
    }
    while ((a1 + a2 + a3 - 1.0) < 1E-18);

    moyenne = a1 * n1 + a2 * n2 + a3 * n3;

    if (moyenne < 10)
        printf("Non recu avec une moyenne de %.2f\n", moyenne);
    else
        printf("Admissible avec une moyenne de %.2f\n", moyenne);

    return 0;
}
