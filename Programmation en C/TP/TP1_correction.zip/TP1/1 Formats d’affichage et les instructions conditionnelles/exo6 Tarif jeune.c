#include <stdio.h>

int main()
{
    int a;

    printf("Quel est votre age ?\n");
    scanf("%d", &a);

    if (a < 26)
        printf("Tarif jeune\n");
    else
        printf("Tarif normal\n");

    return 0;
}
