#include <stdio.h>

int main()
{
    char sexe, marie;

    printf("Quel est votre sexe (h/f) ?\n");
    scanf(" %c", &sexe);

    if (sexe == 'h')
        printf("Bonjour Monsieur\n");
    else if (sexe == 'f')
    {
        printf("Etes-vous mariee (o/n) ?\n");
        scanf(" %c", &marie);
        if (marie == 'o')
            printf("Bonjour Madame\n");
        else if (marie == 'n')
            printf("Bonjour Mademoiselle\n");
        else
            printf("Bonjour gente dame de statut marital indetermine\n");
    }
    else
        printf("Bonjour anomalie de l'evolution\n");

    return 0;
}
