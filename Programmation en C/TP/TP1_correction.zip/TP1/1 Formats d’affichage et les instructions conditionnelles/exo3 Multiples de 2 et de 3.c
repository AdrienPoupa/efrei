#include <stdio.h>

int main()
{
    int a, b;

    printf("Entrez a et b\n");
    scanf("%d %d",&a, &b);

    if (a < 10)
        printf("0");
    if (a < 100)
        printf("0");
    printf("%d  ", a);

    if ((a%2 == 0) && (a%3 == 0))
        printf("est divisible par 2 et 3.\n");
    else if (a%2 == 0)
        printf("est divisible par 2.\n");
    else if (a%3 == 0)
        printf("est divisible par 3.\n");
    else
        printf("n'est divisible ni par 2 ni par 3.\n");

    if (b < 10)
        printf("0");
    if (b < 100)
        printf("0");
    printf("%d  ",b);

    if ((b%2 == 0) && (b%3 == 0))
        printf("est divisible par 2 et 3.\n");
    else if (b%3 == 0)
        printf("est divisible par 3.\n");
    else
        printf("n'est divisible ni par 2 ni par 3.\n");

    printf("La somme est ");
    if (a + b < 10)
        printf("0");
    if (a + b < 100)
        printf("0");
    printf("%d  et ", a + b);

    if ((a+b)%2 == 0 && (a+b)%3 == 0)
        printf("est divisible par 2 et 3.\n");
    else if ((a + b)%2 == 0)
        printf("est divisible par 2.\n");
    else if ((a+b)%3 == 0)
        printf("est divisible par 3.\n");
    else
        printf("n'est divisible ni par 2 ni par 3.\n");

    return 0;
}
