#include <stdio.h>

int main()
{
    int n, siecle, annee, mois, semaine, jours;

    printf("Combien de jours ?\n");
    scanf("%d", &n);

    siecle = n/36000;
    jours = n%36000;
    annee = jours/360;
    jours = jours%360;
    mois = jours/30;
    jours = jours%30;
    semaine = jours/7;
    jours = jours%7;

    printf("%d jours = %d siecle", n, siecle);
    if (siecle > 1)
        printf("s");
    printf(", %d annee", annee);
    if (annee > 1)
        printf("s");
    printf(", %d mois, %d semaine", mois, semaine);
    if (semaine > 1)
        printf("s");
    printf(", %d jour", jours);
    if (jours > 1)
        printf("s");
    printf(".\n");

    return 0;
}
