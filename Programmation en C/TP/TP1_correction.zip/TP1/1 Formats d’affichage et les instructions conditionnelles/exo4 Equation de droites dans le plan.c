#include <stdio.h>

int main()
{
    /** Première partie */
    float a1, a2, b1, b2;

    printf("Premier point :\n");
    scanf("%f %f",&a1, &a2);
    printf("Deuxieme point :\n");
    scanf("%f %f",&b1, &b2);

    if (a1 == b1)
    {
        if (a2 == b2)
            printf("Il y a un seul point !\n");
        else
            printf("L'equation de la droite passant par ces deux points est x = %.2f\n", a1);
    }
    else
        printf("L'equation de la droite passant par ces deux points est y = %.2fx + %.2f\n",(a2-b2)/(a1-b1), a2 - a1*((a2-b2)/(a1-b1)));


    /** Deuxième partie */
    printf("Premiere droite :\n");
    scanf("%f %f",&a1, &a2);
    printf("Deuxieme droite :\n");
    scanf("%f %f",&b1, &b2);

    if (a1 == b1)
    {
        if (a2 == b2)
            printf("Il y a une seule droite !\n");
        else
            printf("Ces deux droites sont paralleles !\n");
    }
    else
        printf("Le point d'intersection de ces deux droites est (%.2f,%.2f)\n",(b2-a2)/(a1-b1), a1 * ((b2-a2)/(a1-b1)) + a2);

    return 0;
}

