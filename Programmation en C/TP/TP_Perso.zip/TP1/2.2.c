#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float A = 4.2;
    int B = 4;

    printf("A + B = %f\n", A+B);
    printf("A - B = %f\n", A-B);
    printf("A * B = %f\n", A*B);
    printf("A / B = %f\n", A/B);
}
