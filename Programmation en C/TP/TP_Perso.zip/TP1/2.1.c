#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int A = 4;
    int B = 4;

    printf("A + B = %d\n", A+B);
    printf("A - B = %d\n", A-B);
    printf("A * B = %d\n", A*B);
    printf("A / B = %d\n", A/B);
}
