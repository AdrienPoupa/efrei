#include <iostream>

using namespace std;

int main()
{
    int i;

    cout << "Carre des 25 premiers nombres entiers" << endl;
    for (i = 0; i < 25; i++)
    {
        cout << i * i << endl;
    }
    return 0;
}


